include("shared.lua")

function ENT:Draw()
    
    if(EyePos():Distance(self.Entity:GetPos())<1000)then self:DrawModel()end 
end
