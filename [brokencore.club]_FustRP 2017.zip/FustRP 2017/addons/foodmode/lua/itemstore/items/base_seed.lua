ITEM.Name = "Hlife Seed"
ITEM.Description = ""
ITEM.Model = "models/error.mdl"
ITEM.Base = "base_entity"
ITEM.Stackable = false

function ITEM:CanPickup( pl, ent )
	return ent:GetDTInt(1) == 0
end

function ITEM:GetName()
	return self:GetData( "SeedTabel" )[1]
end

function ITEM:GetModel()
	return self:GetData( "Model" )
end

function ITEM:GetDescription()
	local t = self:GetData( "SeedTabel" )
	local text = t[8][1] .. " зацветаний\nОт " .. t[7][1] .. " до " .. t[7][2] .. " плодов"
	return text
end

function ITEM:SaveData( ent )
	self:SetData( "SeedTabel", ent:GetSeedBaseTabel())
	self:SetData( "Model", ent:GetModel())
end

function ITEM:LoadData( ent )
	ent:SetSeedBaseTabel( self:GetData( "SeedTabel" ) )
end