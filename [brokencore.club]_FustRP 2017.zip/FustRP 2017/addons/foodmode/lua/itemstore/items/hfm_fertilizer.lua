ITEM.Name = "Hlife Fertilizer"
ITEM.Description = "Ускоряет зацветания в 2 раза"
ITEM.Model = "models/error.mdl"
ITEM.Base = "base_entity"
ITEM.Stackable = false

function ITEM:GetName()
	return self:GetData( "Name" )
end

function ITEM:GetModel()
	return self:GetData( "Model" )
end

function ITEM:SaveData( ent )
	self:SetData( "Name", ent.PrintName)
	self:SetData( "Model", ent:GetModel())
end