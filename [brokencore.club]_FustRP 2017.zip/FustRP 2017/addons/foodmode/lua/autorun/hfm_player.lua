local meta = FindMetaTable("Player")

function meta:CanCookFood(luaname)
	local FTB = HFMGetTable(luaname)
	for k,v in pairs(FTB.Ingredients or {}) do
		if self:HFM_AmountItem(k) < v then
			 return false
		end
	end
	return true
end

function meta:HFM_AmountItem(luaname)
	local count = 0
	for k, v in pairs( self:GetInventory().Items ) do
		if v:GetData("UniqueName") == luaname then
			count = count + ( v.Stackable and ( v:GetData( "Amount" ) or 1 ) or 1 )
		end
	end
	return count
end