local GraMAT = Material("gui/gradient")


hook.Add("HUDPaint", "HFMHUD", function()
	local Min = HFM_Config.HUDDangerMin
	local ply = LocalPlayer()
	if (ply:HFMGetVar("HFM_Hunger") <= Min or ply:HFMGetVar("HFM_Thirsty") <= Min) and ply:Alive() then
		local Lower = math.min(ply:HFMGetVar("HFM_Hunger"), ply:HFMGetVar("HFM_Thirsty"))
		local Per = 1 - (Lower/Min)
		
		local col = Color(200, 150, 0, Per * 200)
		if ply:HFMGetVar("HFM_Hunger") > ply:HFMGetVar("HFM_Thirsty") then
			col = Color(200, 200, 0, Per * 200)
		end
		
		local Size = 40 + math.Round(math.sin(CurTime())*30)*2
		surface.SetMaterial(GraMAT)
		surface.SetDrawColor(col)
		surface.DrawTexturedRectRotated(ScrW()/2,Size/2,Size,ScrW(),270)
		surface.DrawTexturedRectRotated(ScrW()/2,ScrH() - Size/2,Size,ScrW(),90)
		
		surface.DrawTexturedRectRotated(Size/2,Size/2,Size,ScrH()*2,0)
		surface.DrawTexturedRectRotated(ScrW() - Size/2,Size/2,Size,ScrH()*2,180)
	end
end)
