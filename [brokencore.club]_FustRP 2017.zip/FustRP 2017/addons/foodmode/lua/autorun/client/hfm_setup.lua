if !FM_CMODEL_MASTER_MS then
	FM_CMODEL_MASTER_MS = ClientsideModel("models/props_c17/furnitureStove001a.mdl",RENDER_GROUP_VIEW_MODEL_OPAQUE)	
	FM_CMODEL_MASTER_MS:SetNoDraw(true)
end

if !FM_CMODEL_MASTER_KSKMD_MS then
	FM_CMODEL_MASTER_KSKMD_MS = ClientsideModel("models/props_c17/furnitureStove001a.mdl",RENDER_GROUP_VIEW_MODEL_OPAQUE)	
	FM_CMODEL_MASTER_KSKMD_MS:SetNoDraw(true)
end