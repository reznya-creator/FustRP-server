local Main = "Arial"

surface.CreateFont( "FM2_15",{font = Main,size = 15,weight = 5,antialias = true})
surface.CreateFont( "FM2_17",{font = Main,size = 17,weight = 5,antialias = true})
surface.CreateFont( "FM2_20",{font = Main,size = 20,weight = 5,antialias = true})
surface.CreateFont( "FM2_22",{font = Main,size = 22,weight = 5,antialias = true})
surface.CreateFont( "FM2_25",{font = Main,size = 25,weight = 5,antialias = true})
surface.CreateFont( "FM2_30",{font = Main,size = 30,weight = 5,antialias = true})
surface.CreateFont( "FM2_40",{font = Main,size = 40,weight = 5,antialias = true})
surface.CreateFont( "FM2_60",{font = Main,size = 60,weight = 5,antialias = true})


surface.CreateFont( "FM2B_20",{font = Main,size = 20,weight = 400,blursize=2,antialias=true})
surface.CreateFont( "FM2B_25",{font = Main,size = 25,weight = 400,blursize=2,antialias=true})
surface.CreateFont( "FM2B_30",{font = Main,size = 30,weight = 400,blursize=2,antialias=true})