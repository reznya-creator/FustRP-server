AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )
include( 'shared.lua' )

function ENT:Initialize()
	self:SetModel( "models/props_interiors/pot02a.mdl" )
	self.Entity:PhysicsInit(SOLID_VPHYSICS)
	self.Entity:SetMoveType(MOVETYPE_VPHYSICS)
	self.Entity:SetSolid(SOLID_VPHYSICS)
	self.Entity:DrawShadow(false)
	self.Entity:SetCollisionGroup( COLLISION_GROUP_DEBRIS )
end

function ENT:SetFood(luaname)
	local FTB = HFMGetTable(luaname)
	if !FTB then self:Remove() return end
	self.Food = luaname
end
