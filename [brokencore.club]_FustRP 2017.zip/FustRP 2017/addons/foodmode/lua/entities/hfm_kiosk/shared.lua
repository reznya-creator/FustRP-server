ENT.Type = "anim"
ENT.RenderGroup = RENDERGROUP_TRANSLUCENT

ENT.PrintName = "Киоск"
ENT.Category = "Food mode"

ENT.Spawnable = true
ENT.AdminOnly = false

ENT.IsShop = true

function ENT:SetupDataTables()
	self:NetworkVar( "Entity",	0, "ShopOwner" )
	self:NetworkVar( "String",	0, "ShopName" )
	self:NetworkVar( "Int", 	0, "ConID" )
end