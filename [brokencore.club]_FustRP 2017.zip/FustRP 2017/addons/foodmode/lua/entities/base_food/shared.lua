ENT.Base = "base_gmodentity" 
ENT.Type = "anim" 

ENT.PrintName		= "Base food" 
ENT.Category 		= "Food mode - foods" 
ENT.Author			= "HLIFE" 

ENT.Spawnable			= false 
ENT.AdminSpawnable		= false 