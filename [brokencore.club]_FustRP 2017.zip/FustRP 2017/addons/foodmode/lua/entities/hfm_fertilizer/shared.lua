ENT.Base = "base_gmodentity" 
ENT.Type = "anim" 

ENT.PrintName		= HFM_Config.Fertilizer.Name
ENT.Category 		= "Food mode - seeds" 
ENT.Author			= "HLIFE" 

ENT.Spawnable			= false 
ENT.AdminSpawnable		= false 