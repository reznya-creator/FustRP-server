ITEM.Name = "Wood" 
ITEM.Description = "There's a hilarious penis joke to be made here."
ITEM.Model = "models/props_phx/construct/wood/wood_boardx1.mdl"
ITEM.Base = "base_entity" 
ITEM.Stackable = true