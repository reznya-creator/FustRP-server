ITEM.Name = "Spring" 
ITEM.Description = "Like a slinky but boring."
ITEM.Model = "models/props_c17/TrapPropeller_Lever.mdl"
ITEM.Base = "base_entity" 
ITEM.Stackable = true