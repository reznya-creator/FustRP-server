ITEM.Name = "PCP"
ITEM.Description = "oh fuck what is happening"
ITEM.Model = "models/marioragdoll/Super Mario Galaxy/star/star.mdl"
ITEM.Base = "base_darkrp"
ITEM.Stackable = true