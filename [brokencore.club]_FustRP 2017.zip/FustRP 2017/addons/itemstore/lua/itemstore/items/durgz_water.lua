ITEM.Name = "Water"
ITEM.Description = "The most dangerous drug of all."
ITEM.Model = "models/drug_mod/the_bottle_of_water.mdl"
ITEM.Base = "base_darkrp"
ITEM.Stackable = true