ITEM.Name = "Iron Bar" 
ITEM.Description = "A bar of iron." 
ITEM.Model = "models/Items/CrossbowRounds.mdl"
ITEM.Base = "base_entity" 
ITEM.Stackable = true