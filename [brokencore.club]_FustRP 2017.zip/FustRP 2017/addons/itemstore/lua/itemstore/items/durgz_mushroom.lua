ITEM.Name = "Mushrooms"
ITEM.Description = "Just like Mario."
ITEM.Model = "models/ipha/mushroom_small.mdl"
ITEM.Base = "base_darkrp"
ITEM.Stackable = true