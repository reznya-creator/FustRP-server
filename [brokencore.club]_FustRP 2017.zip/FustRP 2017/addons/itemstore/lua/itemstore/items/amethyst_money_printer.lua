ITEM.Name = "Amethyst Money Printer"
ITEM.Base = "base_gemprinter"
ITEM.Colour = Color( 153, 102, 204, 255 )