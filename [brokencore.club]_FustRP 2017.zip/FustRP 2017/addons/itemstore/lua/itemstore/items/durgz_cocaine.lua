ITEM.Name = "Cocaine"
ITEM.Description = "ohfuckohfuckohfuckohfUCKOHFUCKOHFUCK"
ITEM.Model = "models/cocn.mdl"
ITEM.Base = "base_darkrp"
ITEM.Stackable = true