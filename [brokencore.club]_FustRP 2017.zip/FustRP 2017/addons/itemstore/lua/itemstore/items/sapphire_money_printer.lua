ITEM.Name = "Sapphire Money Printer"
ITEM.Base = "base_gemprinter"
ITEM.Colour = Color( 15, 82, 186, 255 )