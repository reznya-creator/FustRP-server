ITEM.Name = "Weed"
ITEM.Description = "Duuuuude."
ITEM.Model = "models/katharsmodels/contraband/zak_wiet/zak_wiet.mdl"
ITEM.Base = "base_darkrp"
ITEM.Stackable = true