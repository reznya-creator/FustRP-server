ITEM.Name = "Cigarette"
ITEM.Description = "+10 to cool"
ITEM.Model = "models/boxopencigshib.mdl"
ITEM.Base = "base_darkrp"
ITEM.Stackable = true