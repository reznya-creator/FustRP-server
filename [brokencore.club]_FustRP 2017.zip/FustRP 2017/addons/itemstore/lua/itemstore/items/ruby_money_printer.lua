ITEM.Name = "Ruby Money Printer"
ITEM.Base = "base_gemprinter"
ITEM.Colour = Color( 224, 17, 95, 255 )