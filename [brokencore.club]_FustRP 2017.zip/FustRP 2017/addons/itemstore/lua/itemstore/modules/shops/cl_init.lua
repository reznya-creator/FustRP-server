include( "shared.lua" )

function itemstore.shops.ShowPriceDialog( entid, slot )
	local function AskForPrice()
		Derma_StringRequest( "Item Price", "Please enter the price of this item to be sold for.", 100, function( text ) local price = tonumber( text ) if ( price ) then RunConsoleCommand( "itemstore_priceitem", entid, slot, price ) else Derma_Query( "Invalid Price", "Please enter a number for the price.", "Retry", AskForPrice ) end end )
	end
	
	AskForPrice()
end