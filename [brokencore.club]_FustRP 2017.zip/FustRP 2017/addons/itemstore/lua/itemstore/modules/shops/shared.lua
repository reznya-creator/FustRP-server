itemstore.shops = {}

include( "config.lua" )
include( "darkrp.lua" )