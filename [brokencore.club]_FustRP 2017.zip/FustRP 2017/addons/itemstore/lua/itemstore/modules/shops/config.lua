-- Set this to false if you're using DarkRP 2.4
itemstore.config.DarkRP25 = true

-- The size of the shops in format { width, height }
itemstore.config.ShopSize = { 5, 3 }

-- Price of the automated shop
itemstore.config.ShopPrice = 200