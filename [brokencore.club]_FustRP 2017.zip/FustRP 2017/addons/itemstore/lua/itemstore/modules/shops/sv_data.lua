if not ( file.IsDir( "itemstore/shops", "DATA" ) ) then
	file.CreateDir( "itemstore/shops" )
end

concommand.Add( "itemstore_savenpcshops", function( pl, cmd, args )
	if ( pl:IsAdmin() ) then
		local save = {}
		
		for _, ent in ipairs( ents.FindByClass( "itemstore_npc_shop" ) ) do
			local data = {}
			
			data.Position = ent:GetPos()
			data.Angles = ent:GetAngles()
			data.Name = ent:GetShopName()
			data.Model = ent:GetModel()
			data.Teams = ent.Container.Teams
			
			data.Items = {}
			for k, v in pairs( ent.Container.Items ) do
				data.Items[ k ] = { Class = v.UniqueName, Data = v.Data, Price = v.ShopPrice }
			end
			
			table.insert( save, data )
		end
		
		local json = util.TableToJSON( save )
		file.Write( "itemstore/shops/" .. game.GetMap() .. ".txt", json )
		
		pl:PrintMessage( HUD_PRINTCONSOLE, "Shops saved" )
	end
end )

hook.Add( "InitPostEntity", "ItemStoreLoadShops", function()
	local path = "itemstore/shops/" .. game.GetMap() .. ".txt"
	
	if ( file.Exists( path, "DATA" ) ) then
		local shops = util.JSONToTable( file.Read( path, "DATA" ) )
		
		if ( shops ) then
			for _, shopdef in ipairs( shops ) do
				local shop = ents.Create( "itemstore_npc_shop" )
				shop:SetPos( shopdef.Position )
				shop:SetAngles( shopdef.Angles )
				shop:Spawn()
				
				if ( shopdef.Model ) then shop:SetModel( shopdef.Model ) shop:ResetSequence( 2 ) end
				shop:SetShopName( shopdef.Name )
				shop.Container.Teams = shopdef.Teams or {}
				for k, v in pairs( shopdef.Items ) do
					local item = itemstore.items.New( v.Class )
					item.ShopPrice = v.Price
					
					for datak, datav in pairs( v.Data ) do
						item:SetData( datak, datav )
					end
					
					shop.Container:SetItem( item, k )
				end
			end
		end
	end
end )