include( "shared.lua" )
include( "sv_resources.lua" )
include( "sv_data.lua" )

function itemstore.shops.PriceItem( shop, item, price )
	if ( IsValid( shop ) and item and shop.Container:HasItem( item ) ) then
		if ( price ) then
			item:SetData( "ExtraInfo", "$" .. tostring( price ) )
			item.ShopPrice = price
			
			shop.Container:Sync()
		else
			item:SetData( "ExtraInfo", "" )
			item.ShopPrice = nil
		end
	end
end

concommand.Add( "itemstore_priceitem", function( pl, cmd, args )
	local ent = Entity( tonumber( args[ 1 ] )  )
	local slot = tonumber( args[ 2 ] )
	local price = tonumber( args[ 3 ] )
	
	if ( IsValid( ent ) and slot and price and ent.IsShop and ( pl:IsAdmin() and pl.EditNPCShops or ent:GetShopOwner() == pl ) ) then
		if ( price < 1 ) then
			price = 1
		end
		
		itemstore.shops.PriceItem( ent, ent.Container:GetItem( math.floor( slot ) ), math.floor( price ) )
	end
end )

function itemstore.shops.CreateShopContainer( size )
	local con = itemstore.containers.New( size )
	con:SetCallback( "swap", function( con, pl, sourceslot, sourceitem, dest, destslot, destitem )
		if ( con:GetOwner():GetShopOwner() == pl ) then
			if ( destitem ) then
				-- :effort:
				pl:SendLua( "itemstore.shops.ShowPriceDialog( " .. con:GetOwner():EntIndex() .. ", " .. sourceslot .. " )" )
			end
			
			if ( sourceitem and con ~= dest ) then
				--remove price data
				sourceitem:SetData( "ExtraInfo", nil )
				sourceitem.ShopPrice = nil
			end
			
			return true
		else
			if ( not destitem ) then
				if ( con ~= dest and sourceitem ) then
					if ( sourceitem.ShopPrice ) then
						if ( itemstore.shops.CanAfford( pl, sourceitem.ShopPrice ) ) then
							itemstore.shops.AddMoney( pl, -sourceitem.ShopPrice )
							itemstore.shops.AddMoney( con:GetOwner():GetShopOwner(), sourceitem.ShopPrice )
							
							pl:PrintMessage( HUD_PRINTTALK, "You have purchased an item for $" .. tostring( sourceitem.ShopPrice ) .. "." )
							con:GetOwner():GetShopOwner():PrintMessage( HUD_PRINTTALK, "An item in one of your shops sold for $" .. tostring( sourceitem.ShopPrice ) .. "." )
							
							sourceitem:SetData( "ExtraInfo", nil )
							sourceitem.ShopPrice = nil
							
							return true
						else
							pl:PrintMessage( HUD_PRINTTALK, "You cannot afford that item" )
						end
					else
						pl:PrintMessage( HUD_PRINTTALK, "This item is not priced so you may not purchase it." )
					end
				end
			else
				pl:PrintMessage( HUD_PRINTTALK, "This is not your store so you may not add items." )
			end
			
			return false
		end
	end )
	
	local function no() return false end
	con:SetCallback( "use", no )
	con:SetCallback( "drop", no )
	con:SetCallback( "destroy", no )
	con:SetCallback( "merge", no )
	con:SetCallback( "split", no )
	
	return con
end

function itemstore.shops.CreateNPCShopContainer( size )
	local con = itemstore.containers.New( size )
	con.Teams = {}
	con:SetCallback( "swap", function( con, pl, sourceslot, sourceitem, dest, destslot, destitem )
		if ( pl:IsAdmin() and pl.EditNPCShops ) then
			if ( destitem ) then
				-- :effort:
				pl:SendLua( "itemstore.shops.ShowPriceDialog( " .. con:GetOwner():EntIndex() .. ", " .. sourceslot .. " )" )
			end
			
			if ( sourceitem and con ~= dest ) then
				--remove price data
				sourceitem:SetData( "ExtraInfo", nil )
				sourceitem.ShopPrice = nil
			end
			
			return true
		else
			if ( not destitem ) then
				if ( con ~= dest and sourceitem ) then
					if ( sourceitem.ShopPrice ) then
						if ( #con.Teams == 0 or table.HasValue( con.Teams, pl:Team() ) ) then
							if ( itemstore.shops.CanAfford( pl, sourceitem.ShopPrice ) ) then
								itemstore.shops.AddMoney( pl, -sourceitem.ShopPrice )
								pl:PrintMessage( HUD_PRINTTALK, "You have purchased an item for $" .. tostring( sourceitem.ShopPrice ) .. "." )
								local dupe = table.Copy( sourceitem )
								
								sourceitem:SetData( "ExtraInfo", nil )
								sourceitem.ShopPrice = nil
								
								-- dumb hack to work around my own systems, I'm a lazyass
								timer.Simple( 0, function()
									con:SetItem( dupe, sourceslot )
								end )
								
								return true
							else
								pl:PrintMessage( HUD_PRINTTALK, "You cannot afford that item" )
							end
						else
							pl:ChatPrint( "Your team cannot buy items from this NPC." )
						end
					else
						pl:PrintMessage( HUD_PRINTTALK, "This item is not priced so you may not purchase it." )
					end
				end
			else
				pl:PrintMessage( HUD_PRINTTALK, "This is not your store so you may not add items." )
			end
			
			return false
		end
	end )
	
	local function no() return false end
	con:SetCallback( "use", no )
	con:SetCallback( "drop", no )
	con:SetCallback( "destroy", no )
	con:SetCallback( "merge", no )
	con:SetCallback( "split", no )
	
	return con
end

concommand.Add( "itemstore_editnpcshops", function( pl )
	if ( pl:IsAdmin() ) then
		pl.EditNPCShops = not pl.EditNPCShops
		
		pl:PrintMessage( HUD_PRINTCONSOLE, "NPC Edit: " .. tostring( pl.EditNPCShops ) )
	end
end )

concommand.Add( "itemstore_nameshop", function( pl, cmd, args )
	local ent = pl:GetEyeTrace().Entity
	
	if ( IsValid( ent ) and ent.IsShop and ( ent.GetShopOwner and ent:GetShopOwner() == pl or pl:IsAdmin() ) ) then
		ent:SetShopName( table.concat( args, " " ) )
	end
end )

concommand.Add( "itemstore_getteams", function( pl )
	if ( IsValid( pl ) and pl:IsAdmin() ) then
		for team_id, team in pairs( team.GetAllTeams() ) do
			pl:PrintMessage( HUD_PRINTCONSOLE, team_id .. " - " .. team.Name )
		end
	end
end )

concommand.Add( "itemstore_setnpcshopteams", function( pl, cmd, args )
	if ( IsValid( pl ) and pl:IsAdmin() ) then
		local ent = pl:GetEyeTrace().Entity
		
		if ( IsValid( ent ) and ent:GetClass() == "itemstore_npc_shop" ) then
			local teams = {}
			
			for _, team in ipairs( args ) do
				if ( tonumber( team ) ) then
					table.insert( teams, tonumber( team ) )
				end
			end
			
			ent.Container.Teams = teams
		end
	end
end )

concommand.Add( "itemstore_setnpcshopmodel", function( pl, cmd, args )
	if ( #args >= 1 and IsValid( pl ) and pl:IsAdmin() ) then
		local ent = pl:GetEyeTrace().Entity
		
		if ( IsValid( ent ) and ent:GetClass() == "itemstore_npc_shop" ) then
			ent:SetModel( args[ 1 ] )
			ent:ResetSequence( 2 )
		end
	end
end )