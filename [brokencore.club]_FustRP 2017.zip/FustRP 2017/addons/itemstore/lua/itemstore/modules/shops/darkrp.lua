hook.Add( "PostGamemodeLoaded", "ItemStoreDarkRPShops", function()
	if ( itemstore.config.DarkRP25 ) then
		function itemstore.shops.GetMoney( pl )
			return pl:getDarkRPVar( "money" )
		end
		
		function itemstore.shops.SetMoney( pl, amount )
			pl:setDarkRPVar( "money", amount )
		end
		
		DarkRP.declareChatCommand( { command = "nameshop", description = "Names the shop in front of you.", delay = 2 } )
		if SERVER then
			DarkRP.defineChatCommand( "nameshop", function( pl, args )
				local ent = pl:GetEyeTrace().Entity
				
				if ( IsValid( ent ) and ent.IsShop and ( ent.GetShopOwner and ent:GetShopOwner() == pl or pl:IsAdmin() ) ) then
					ent:SetShopName( args )
				end
				
				return ""
			end )
		end
		
		--AddEntity( "Automated Shop", "itemstore_shop", "models/props_c17/TrapPropeller_Engine.mdl", itemstore.config.ShopPrice, 3, "buyshop" )
	else
		function itemstore.shops.GetMoney( pl )
			return pl:getDarkRPVar( "money" )
		end
		
		function itemstore.shops.SetMoney( pl, amount )
			pl:SetDarkRPVar( "money", amount )
		end
		
		if SERVER then
			AddChatCommand( "/nameshop", function( pl, args )
				local ent = pl:GetEyeTrace().Entity
				
				if ( IsValid( ent ) and ent.IsShop and ( ent.GetShopOwner and ent:GetShopOwner() == pl or pl:IsAdmin() ) ) then
					ent:SetShopName( args )
				end
				
				return ""
			end )
		end
		
		--AddEntity( "Automated Shop", "itemstore_shop", "models/props_c17/TrapPropeller_Engine.mdl", itemstore.config.ShopPrice, 3, "/buyshop" )
	end

	function itemstore.shops.AddMoney( pl, amount )
		itemstore.shops.SetMoney( pl, itemstore.shops.GetMoney( pl ) + amount )
	end

	function itemstore.shops.CanAfford( pl, amount )
		return itemstore.shops.GetMoney( pl ) >= amount
	end
end )