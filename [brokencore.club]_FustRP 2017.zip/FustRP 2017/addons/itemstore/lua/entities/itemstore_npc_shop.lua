ENT.Type = "anim"
ENT.RenderGroup = RENDERGROUP_TRANSLUCENT

ENT.PrintName = "NPC Shop"
ENT.Category = "ItemStore"

ENT.Spawnable = true
ENT.AdminOnly = true

ENT.AutomaticFrameAdvance = true 

ENT.IsShop = true

function ENT:SetupDataTables()
	self:NetworkVar( "String", 0, "ShopName" )
end

function ENT:Think()
	self:NextThink( CurTime() )
	return true
end

if SERVER then
	AddCSLuaFile()
	
	function ENT:Initialize()
		self:SetModel( "models/Humans/Group03/Female_01.mdl" )
		
		self:SetMoveType( MOVETYPE_NONE )
		self:SetSolid( SOLID_BBOX )
		self:SetUseType( SIMPLE_USE )
		--self:DropToFloor()
		
		local min, max = self:GetCollisionBounds()
		self:SetCollisionBounds( Vector( -13, -13, 0 ), max)
		self:ResetSequence( 2 )
		
		self:SetShopName( "NPC Trader" )
		
		self.Container = itemstore.shops.CreateNPCShopContainer( itemstore.config.ShopSize[ 1 ] * itemstore.config.ShopSize[ 2 ] )
		self.Container:SetOwner( self )
		
		local function PermissionsCallback( con, pl )
			if ( pl:GetPos():Distance( self:GetPos() ) < 250 ) then
				return true
			end
			
			return false
		end
		
		self.Container:SetCallback( "canread", PermissionsCallback )
		self.Container:SetCallback( "canwrite", PermissionsCallback )

		hook.Add( "CanTool", self, function( self, pl, tr, tool )
			if tr.Entity == self and self:Getowning_ent() == pl and tool == "remover" then
				return true end
		end )

		hook.Add( "CanProperty", self, function( self, pl, property, ent )
			if ent == self and property == "remover" and not pl:IsSuperAdmin() then
				return false end
		end )
	end
	
	function ENT:Use( pl )
		if ( #self.Container.Teams == 0 or table.HasValue( self.Container.Teams, pl:Team() ) ) then
			self.Container:Sync()
			itemstore.containers.Open( pl, self.Container, "Shop", itemstore.config.ShopSize[ 1 ], itemstore.config.ShopSize[ 2 ] )
		else
			pl:ChatPrint( "Ваша профессия не позволяет использовать этот NPC!" )
		end
	end
else 
	function ENT:DrawTranslucent()
		if(EyePos():Distance(self.Entity:GetPos())<2000) then self:DrawModel() end	
		local text = self:GetShopName()
		local font = "DermaLarge"
		
		surface.SetFont( font )
		local textw, texth = surface.GetTextSize( text )
		local w = 5 + textw + 5
		local h = 2 + texth + 2
		local x, y = -w / 2, -h / 2
		if(EyePos():Distance(self.Entity:GetPos())<500) then
			cam.Start3D2D( self:GetPos() + self:GetAngles():Up() * 80, Angle( 0, 0, 90 ), 0.25 )
				draw.SimpleTextOutlined( text, font, 0, 0, Color( 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0 ) )
			cam.End3D2D()
		end
	end
end
