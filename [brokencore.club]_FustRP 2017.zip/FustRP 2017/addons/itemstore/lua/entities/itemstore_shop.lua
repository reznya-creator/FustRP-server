ENT.Type = "anim"
ENT.RenderGroup = RENDERGROUP_TRANSLUCENT

ENT.PrintName = "Shop"
ENT.Category = "ItemStore"

ENT.Spawnable = true
ENT.AdminOnly = false

ENT.IsShop = true

function ENT:SetupDataTables()
	self:NetworkVar( "Entity", 0, "owning_ent" )
	self:NetworkVar( "String", 0, "ShopName" )
end

function ENT:GetShopOwner( ... )
	return self:Getowning_ent( ... )
end 

function ENT:SetShopOwner( ... )
	return self:Setowning_ent( ... )
end 

if SERVER then
	AddCSLuaFile()
	
	function ENT:Initialize()
		self:SetModel( "models/props_c17/TrapPropeller_Engine.mdl" )
		
		self:PhysicsInit( SOLID_VPHYSICS )
		self:SetMoveType( MOVETYPE_VPHYSICS )
		self:SetSolid( SOLID_VPHYSICS )
		self:SetUseType( SIMPLE_USE )
		
		self:GetPhysicsObject():Wake()
		
		self.Container = itemstore.shops.CreateShopContainer( itemstore.config.ShopSize[ 1 ] * itemstore.config.ShopSize[ 2 ] )
		self.Container:SetOwner( self )
		
		local name = IsValid( self:GetShopOwner() ) and self:GetShopOwner():Name() or "Unknown"
		self:SetShopName( name .. "'s Shop" )
		
		local function PermissionsCallback( con, pl )
			if ( pl:GetPos():Distance( self:GetPos() ) < 250 ) then
				return true
			end
			
			return false
		end
		
		self.Container:SetCallback( "canread", PermissionsCallback )
		self.Container:SetCallback( "canwrite", PermissionsCallback )
		
		self:SetHealth( 100 )

		hook.Add( "CanTool", self, function( self, pl, tr, tool )
			if tr.Entity == self and self:Getowning_ent() == pl and tool == "remover" then
				return true end
		end )

		hook.Add( "CanProperty", self, function( self, pl, property, ent )
			if ent == self and property == "remover" and not pl:IsSuperAdmin() then
				return false end
		end )
	end
	
	function ENT:SpawnFunction( pl, trace, class )
		local ent = ents.Create( class )
		ent:SetPos( trace.HitPos + trace.HitNormal * 16 )
		ent:SetShopOwner( pl )
		ent:Spawn()
		
		return ent
	end
	
	function ENT:Use( pl )
		--self.Container:SetPlayerPermissions( pl, true, true )
		self.Container:Sync()
		itemstore.containers.Open( pl, self.Container, "Shop", itemstore.config.ShopSize[ 1 ], itemstore.config.ShopSize[ 2 ] )
	end
	
	function ENT:Break()
		local effect = EffectData()
		effect:SetOrigin( self:GetPos() )
		util.Effect( "Explosion", effect, true, true )
		
		for _, item in pairs( self.Container.Items ) do
			itemstore.items.CreateEntity( item, self:GetPos() ):Spawn()
		end
		
		self:Remove()
	end
	
	function ENT:OnTakeDamage( dmg )
		if ( GetConVarNumber( "itemstore_box_breakable" ) == 1 ) then
			self:SetHealth( self:Health() - dmg:GetDamage() )
			
			if ( self:Health() <= 0 ) then
				self:Break()
			end
		end
	end
	
	function ENT:OnRemove()
		itemstore.containers.Remove( self.Container:GetID() )
	end
else
	function ENT:DrawTranslucent()
		self:DrawModel()
		
		local text = self:GetShopName()
		local font = "DermaLarge"
		
		surface.SetFont( font )
		local textw, texth = surface.GetTextSize( text )
		local w = 5 + textw + 5
		local h = 2 + texth + 2
		local x, y = -w / 2, -h / 2
		
		cam.Start3D2D( self:GetPos() + self:GetAngles():Up() * 30, Angle( 0, CurTime() * 45, 90 ), 0.35 )
			surface.SetDrawColor( Color( 0, 0, 0, 200 ) )
			surface.DrawRect( x, y, w, h )
			
			draw.SimpleTextOutlined( text, font, 0, 0, Color( 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0 ) )
		cam.End3D2D()
	end
end