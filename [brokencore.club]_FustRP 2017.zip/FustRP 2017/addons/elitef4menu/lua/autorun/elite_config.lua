ELITE = {}

ELITE.StaffListRanks = { "superadmin", "Admin", "AdminL1", "AdminL2", "AdminL3", "AdminL4", "OWNER", "PremAdmin", "Premium"} -- What ULX ranks to show on the "Staff Online" list.
ELITE.ShowFoodTab = true -- Make sure Hungermod is enabled, otherwise this will give you errors!

ELITE.VIPJobCheckbox = true -- Whether or not to show the "Show VIP Jobs" checkbox on the jobs tab. (The checkbox is based on the jobs that have a customCheck)

ELITE.OpenWebsiteInOverlay = false -- If this is true, the website will open in Steam overlay, if false, it will open in the F4 menu.

ELITE.WebsiteURL = "" -- Website that opens when clicking the "Website" button, make sure you include "http://"!

timer.Simple( 1, function() -- Don't screw with this timer, but you may change the tables inside.
    ELITE.AccessToCPCmds = { TEAM_POLICE, TEAM_CHIEF, TEAM_FBI, TEAM_SWAT, TEAM_SWATL, TEAM_SWATS }
    
    ELITE.AccessToMayorCmds = { TEAM_MAYOR }
end)



MONEYCMD_BUTTONS = {}
RPCMD_BUTTONS = {}
CPCMD_BUTTONS = {}
MAYORCMD_BUTTONS = {}
OTHERCMD_BUTTONS = {}

local function AddSidebarButton( n, f )
    table.insert(WEB_BUTTONS, { Title = n, Func = f } )
end
 
local function MenuAddMButton( n, f )
    table.insert(MONEYCMD_BUTTONS, { NAME = n, FUNC = f } )
end

local function MenuAddRPButton( n, f )
    table.insert(RPCMD_BUTTONS, { NAME = n, FUNC = f } )
end

local function MenuAddCPButton( n, f )
    table.insert(CPCMD_BUTTONS, { NAME = n, FUNC = f } )
end

local function MenuAddMayorButton( n, f )
    table.insert(MAYORCMD_BUTTONS, { NAME = n, FUNC = f } )
end

local function MenuAddOtherButton( n, f )
    table.insert(OTHERCMD_BUTTONS, { NAME = n, FUNC = f } )
end
