function OpenJobInfo( index )
	local jbg = vgui.Create( "DFrame" )
	jbg:SetSize( ScrW(), ScrH() )
	jbg:SetTitle( "" )
	jbg:ShowCloseButton( false )
	jbg:SetDraggable( false )
	jbg.Paint = function( self, w, h )
		draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0, 200 ) )
	end
	jbg:MakePopup()

	local jobInfo = vgui.Create( "DFrame", jbg )
	jobInfo:SetSize( 300, 400 )
	jobInfo:SetPos( -500, ScrH() / 2 - 200 )
	jobInfo:ShowCloseButton( false )
	jobInfo.Paint = function( self, w, h )
	--	draw.RoundedBox( 2, 0, 0, w, h, Color( 239, 239, 239 ) )
		draw.RoundedBox( 2, 1, 1, w - 2, h - 2, Color( 0, 0, 0, 200 ) )
		
		draw.SimpleText( string.upper(team.GetName( index )), "RP_SubFontThick", 24, 20, Color( 255, 255, 255 ) )
		
		surface.SetDrawColor( Color( 255, 255, 255 ) )
		surface.DrawLine( 24, 44, 182 - 26, 44 )
	end
	jobInfo:MoveTo( ScrW() / 2 - 150, ScrH() / 2 - 200, 0.5, 0, 0.05 )
	
	local BG_CLOSE = vgui.Create( "DButton", jobInfo )
	BG_CLOSE:SetSize( 32, 32 )
	BG_CLOSE:SetPos( jobInfo:GetWide() - 38,6 )
	BG_CLOSE:SetText( "r" )
	BG_CLOSE:SetFont( "marlett" )
	BG_CLOSE:SetTextColor( Color( 255, 0, 0 ) )
	BG_CLOSE.Paint = function()
		
	end
	BG_CLOSE.DoClick = function()
		jobInfo:Close()
		jbg:Remove()
	end
	
	local STAFF_LIST = vgui.Create( "DPanelList", jobInfo )
	STAFF_LIST:SetSize( 270, 400 - 74 )
	STAFF_LIST:SetPos( 24, 50 )
	STAFF_LIST:SetSpacing( 2 )
	STAFF_LIST:EnableVerticalScrollbar( true )
	STAFF_LIST.VBar.Paint = function( s, w, h )
		draw.RoundedBox( 0, 3, 13, 8, h-26, Color(0,0,0,200))
	end
	STAFF_LIST.VBar.btnUp.Paint = function( s, w, h ) end
	STAFF_LIST.VBar.btnDown.Paint = function( s, w, h ) end
	STAFF_LIST.VBar.btnGrip.Paint = function( s, w, h )
		draw.RoundedBox( 0, 5, 0, 4, h+22, Color(200,0,0,200))
	end
	
	for k, v in pairs( player.GetAll() ) do
		if v:Team() == index then
			local PLY_PANEL = vgui.Create( "Panel" )
			PLY_PANEL:SetSize( 132, 40 )
			PLY_PANEL.Paint = function( self, w, h )
				draw.SimpleText( string.upper(v:Nick()), "RP_SubFontThick", 40, 12 - 6, Color( 255, 255, 255 ) )
				draw.SimpleText( string.upper(v:SteamID()), "RP_SubFontThick", 40, 30 - 6, Color( 200, 0, 0, 200 ) )
			end
			
			local PLY_AVATAR = vgui.Create( "AvatarImage", PLY_PANEL )
			PLY_AVATAR:SetSize( 32, 32 )
			PLY_AVATAR:SetPos( 0, 6 )
			PLY_AVATAR:SetPlayer( v, 32 )
			
			STAFF_LIST:AddItem( PLY_PANEL )
		end
	end
end