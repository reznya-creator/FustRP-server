--[[
	Author: Koz
	Steam: http://steamcommunity.com/id/drunkenkoz
	Contact: mybbkoz@gmail.com

	License:
	You are free to use this software however you like; however,
	you cannot redistribute this code in any way without consent
	from the original author, Koz.
]]--

ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "Coffe"
ENT.Author = "miguel93041"
ENT.Category = "Machines mod"

ENT.Spawnable			= true
ENT.AdminOnly			= true