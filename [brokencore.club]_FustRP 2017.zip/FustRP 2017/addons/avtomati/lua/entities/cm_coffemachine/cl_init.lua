/*-----------------------------------------------------------------------------------------------
	Name of the addon: Machines mod
	email: miguelgrafe001@hotmail.com {Contact me if you have any problem}
	
	License: You can use this addon for your server, but never sell to others or leak it.
	
	Info: In this file you can edit the settings of the coffe machine.
	
	I´m sorry if i wrote something bad in English. (English isn´t my native language)
-----------------------------------------------------------------------------------------------*/
include("shared.lua")

surface.CreateFont( "principal", {
	font = "Arial",
	size = 30,
	weight = 1000,
	blursize = 0,
	scanlines = 0,
	antialias = true,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = true,
	additive = false,
	outline = false,
})

function ENT:Draw()
    self:DrawModel()

		local Pos = self:GetPos()
	    local Ang = self:GetAngles()
		
		Ang:RotateAroundAxis(Ang:Forward(), 90)
	    local TextAng = Ang

	    TextAng:RotateAroundAxis(TextAng:Right(), CurTime() * -90)
		
		cam.Start3D2D(Pos + Ang:Right() * -80, TextAng, 0.35)
			draw.SimpleTextOutlined( 'Кофе', "principal", 0, 25, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color(4, 0, 0, 255))
		cam.End3D2D()	
end