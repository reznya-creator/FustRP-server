/*-----------------------------------------------------------------------------------------------
	Name of the addon: Machines mod
	email: miguelgrafe001@hotmail.com {Contact me if you have any problem}
	
	License: You can use this addon for your server, but never sell to others or leak it.
	
	Info: In this file you can edit the settings of the coffe machine.
	
	I´m sorry if i wrote something bad in English. (English isn´t my native language)
-----------------------------------------------------------------------------------------------*/
cm = {} -- Do not edit this line.

-- Effects of the coffe.
cm.enablespeed		= true -- True = Coffe will heal you, False = Coffe will not heal you.

cm.enablehunger		= true -- True = Coffe will give food, False = Coffe will not give food.
-------------------------------------------------------------------------------------------------
cm.enablesounds		= true -- Enable or disable sounds.

cm.coffeprice		= 45 -- How much coffe will cost.

cm.coffeenergy		= 15 -- How much food will give (Hungermod Only)

cm.speedtimer		= 5 -- The amount of time the speed boost will last.

cm.speedmult		= 1.5 -- Speed multiplier.

-- Locations for coffe machines.
cm.mapspawn = {} -- Do not edit this line

/*--
	cm.mapspawn["map_name"] = {		-- Map that Coffe Machine spawns on.
		pos = Vector( 0, 0, 0 ),	-- The vector of the Coffe Machine.
		ang = Angle( 0, 0, 0 )		-- The angle of the Coffe Machine.
	}
--*/


cm.mapspawn["rp_downtown_v4c_v2a"] = {
	pos = Vector( -201, -780, -131),
	ang = Angle( 0, 0, 0 )
}
	
cm.mapspawn["rp_bangclaw"] = {
	pos = Vector( -1155, -528, 136 ),
	ang = Angle( 0, -90, 0 )
}
-------------------------------------------------------------------------------------------------

MsgC( Color( 0, 187, 255 ), "Machines mod." ) -- Do not edit this line.