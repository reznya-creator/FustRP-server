SafezonesConfig = {
["ProtectionDelay"] = 3, -- how long will they remain spawn protected after leaving a safezone box
["RemoveProps"] = true, -- do we want to delete props that enter the zones
["RemovePysobjects"] = false, -- do we want to mass delete anything that has a physics object? warning: may cause bugs
["RemoveVehicles"] = true, -- do we want to delete vehicles that enter the zones, be careful with this if you run an rp server with cars
["RemoveNPCs"] = false, -- do we want to delete npcs that enter the spawn area
["RecurringProtection"] = true, -- if you leave the spawn zone and re-enter it, should you be protected again?
}

-- the actual boxes, needs to be 2 vectors seperated by a comma as you can see below
-- you can type safezone_grablocation into console to grab the vector location of what your crosshair is pointing at, then copy paste it into this file

Safezones = {

	["gm_construct"] = {
		["AyyLmao"] = {Vector( 1023, -895, 0 ), Vector( 656, 783, -144 )},
	},

	["gm_flatgrass"] = {
		["Box1"] = {Vector( -886, 864, -12288 ), Vector( 857, -861, -11982 )},
	},

	["gm_cfgrass_deathminge_v1"] = {
		["Box1"] = {Vector(11975, 4788, -410), Vector(11594, 6594, -200)},
		["Box2"] = {Vector(6452, 11320, -410), Vector(7684, 12696, -250)},
	},

	["gm_freespace_13"] = {
		["Box1"] = {Vector( -2658, 505, -14584 ), Vector( -3410, -503, -14270 )},
	},

	["rp_bangclaw"] = {
		["Fountain"] = {Vector( -1776, -1396, 286 ), Vector( -1282, -994, -4.121819)},

	},
	
		["rp_downtown_v4c_v2a"] = {
		["Fountain"] = {Vector(  648, -606, -300 ), Vector(  1472, -359, -50 )},

	},

}


-- ========== DO NOT TOUCH ANYTHING BELOW THIS LINE UNLESS YOU KNOW WHAT YOU ARE DOING ==========


if CLIENT then

-- this is a duplicate of the serverside load function that runs on each client so they can see the boxes
local MapSZs = {}

local loadedmap = false
local function LoadMapSetup()
	local thismap = game.GetMap()
	for k, v in pairs(Safezones) do
		if k == thismap then
			MapSZs = v
			loadedmap = true
		end
	end

	if !loadedmap then 
		MsgC(Color(255,50,0, 100), "Simple Safezones: no config detected for this map! check addons/Simple Spawn Zones/sh_safezones.lua for more info\n")
	end

end
timer.Simple(1, function() LoadMapSetup() end)

local function DrawSpawnBoxes()
render.SetMaterial( Material("Models/effects/vol_light001") )
for k, v in pairs(MapSZs) do
render.DrawBox( v[2], Angle(0,0,0), Vector(0,0,0), v[1] - v[2], Color(255,0,0, 100), true )
end
end
hook.Add("PostDrawOpaqueRenderables", "ICanSeeYourDoodle", DrawSpawnBoxes)

local function SZHudIndicator()
if LocalPlayer():GetNWBool("SpawnProtected") then
	local w = ScrW()
	local h = ScrH()
	draw.SimpleTextOutlined("Безопасная зона", "TargetID",w/2,60,Color(50,220,50),1,1,1,color_black)
	--draw.SimpleTextOutlined("Вам не наносится урон","TargetID",w/2,90,Color(220,220,220),1,1,1,color_black)
end
end
hook.Add("HUDPaint", "szhudindicator", SZHudIndicator)

-- use this to easily grab locations for your spawn boxes
local function GrabLoc()
print("Vector( "..math.floor(LocalPlayer():GetEyeTrace().HitPos.x)..", "..math.floor(LocalPlayer():GetEyeTrace().HitPos.y)..", "..math.floor(LocalPlayer():GetEyeTrace().HitPos.z).." )")
end
concommand.Add("safezone_grablocation", GrabLoc)

end


