
-----------------------------------------------------
NLR_time = 30
function LaunchHelp()
	gui.OpenURL("https://www.google.ru/")
end
function IsPlayerDead()
	if !LocalPlayer():Alive() then
		hook.Call("OnPlayerDeath")
		hook.Remove("Think", "IsPlayerDead")
		hook.Add("Think", "IsPlayerAlive", IsPlayerAlive)
		DeathPos =  LocalPlayer():GetPos()
		IsDeadPoint = true 
		timer.Destroy("DrawDeadPoint")
		timer.Create("DrawDeadPoint", NLR_time, 1, function()
			IsDeadPoint = false 
		end)
	end
end
function IsPlayerAlive()
	if LocalPlayer():Alive() then
		hook.Call("OnPlayerSpawn")
		hook.Remove("Think", "IsPlayerAlive")
		hook.Add("Think", "IsPlayerDead", IsPlayerDead)
		--LaunchHelp()
	end
end
hook.Add("Think", "IsPlayerAlive", IsPlayerAlive)
surface.CreateFont( "Fonty_Shmonty", {
	font = "Default",
	size = 45,
})
hook.Remove("HUDPaint", "Draw_NLR_Circle")
hook.Add("HUDPaint", "Draw_NLR_Circle", function()
	local opacity
	if DeathPos and IsDeadPoint and LocalPlayer():Alive() then
		FOD = LocalPlayer():GetPos():Distance(DeathPos)
		if (FOD < 500) then
			if FOD > 200 then 
				opacity = 255 - (FOD-200)/1.17
			elseif FOD < 200 then
				opacity = 255
			end
			surface.SetDrawColor(0,0,0,opacity)
			surface.DrawRect(0,0,ScrW(), ScrH())
			local TextWidth, TextHeight = surface.GetTextSize("НАЗАД! СОБЛЮДАЙ NLR!", "Fonty_Shmonty")
			surface.DrawText("НАЗАД! СОБЛЮДАЙ NLR!", "Fonty_Shmonty", ScrW()/2-TextWidth/2, ScrH()/2-TextHeight, Color(255,0,0,opacity), Color(0,0,0,opacity), TEXT_ALIGN_LEFT)	
		end
	end
end)