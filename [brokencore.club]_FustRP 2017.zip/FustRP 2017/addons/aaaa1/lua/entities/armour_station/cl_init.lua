--[[---------------------------------------------------------------------------
This is an example of a custom entity.
---------------------------------------------------------------------------]]
AddCSLuaFile()
include("shared.lua")

function ENT:Draw()
	if(EyePos():Distance(self.Entity:GetPos())<2000)then self:DrawModel()end	

	local Pos = self:GetPos()
	local Ang = self:GetAngles()

	local owner = self:Getowning_ent()
	owner = (IsValid(owner) and owner:Nick()) or DarkRP.getPhrase("unknown")

	surface.SetFont("HUDNumber5")
	local text = "Бронечинилка"
	local capacity = "Заряд: "..self:GetNWInt("Armour_amount")
	local TextWidth = surface.GetTextSize(text)
	local CapacityWidth = surface.GetTextSize(capacity)

	Ang:RotateAroundAxis(Ang:Up(), 90)
	local TextAng = Ang

	if LocalPlayer():GetPos():Distance(self:GetPos()) < 200 then
		cam.Start3D2D(Pos+Ang:Up()*8, Ang, 0.1)
			draw.RoundedBox( 0, -TextWidth*0.5 -4, -60, TextWidth + 7, 30, Color(0,0,0,150) )
			draw.SimpleText( text, "HUDNumber5", -TextWidth*0.5, -60, Color(255,255,255,255), 0, 0, 1, Color(0,0,0) )
			
			draw.RoundedBox( 0, -CapacityWidth*0.5 -4, -25, CapacityWidth + 7, 30, Color(0,0,0,150) )
			draw.SimpleText( capacity, "HUDNumber5", -CapacityWidth*0.5, -25, Color(255,255,255,255), 0, 0, 1, Color(0,0,0) )
		cam.End3D2D()
	end
end
