﻿local money = 100
 
SWEP.PrintName  = "Ограбить" // Это название нашего оружия. 
SWEP.Instructions   = "Нажми ЛКМ и ты ограбишь человека!" // Это инструкция по аддону.
SWEP.Category = "DarkRP (Utility)"
 
SWEP.Spawnable = false;
SWEP.AdminSpawnable = true;
 
SWEP.Primary.ClipSize   = -1 // Это функция отвечает за количество патрон в магазине,если значение = -1 как в нашем случае,то патронов в магазине бесконечно.
SWEP.Primary.DefaultClip    = -1 // Количество патрон при получения оружия.
SWEP.Primary.Automatic  = false // Тип оружия автомат или винтовка.В нашем случае = true это автомат,при случае = false это винтовка.
SWEP.Primary.Ammo   = "none" // Тип патрон.
 
SWEP.Secondary.ClipSize = -1 // Вот тут всё то же самое как и в верхних
// функциях.
SWEP.Secondary.DefaultClip  = -1
SWEP.Secondary.Automatic    = false
SWEP.Secondary.Ammo = "none"
 
SWEP.Weight = 1 // Вес оружия.
SWEP.AutoSwitchTo   = false // Авто переключение оружия.
SWEP.AutoSwitchFrom = false
 
SWEP.Slot   = 1 // Слот оружия,если = 1,то наше оружие будет в первом слоте рядом с монтировкой.
SWEP.SlotPos    = 3 // Позиция оружия в слоте.
SWEP.DrawAmmo   = false // Скрытие количества патрон в hud'е,если = false,то патроны скрываются,если = true то патроны остаются.
SWEP.DrawCrosshair  = true // Скрытие прицела.
SWEP.HoldType   = "slam"
 
 
SWEP.ViewModel = Model("models/weapons/v_hands.mdl") // ВАЖНО:Тут прописываем путь к оружию.Это модель которую будет держать игрок.
SWEP.WorldModel = "models/props/cs_assault/Money.mdl" // ВАЖНО:Тут прописываем путь к оружию.Это модель которая будет лежать в не подобранном состоянии
 
function SWEP:Reload()
end
 
function SWEP:Think()
return false
end
 
if SERVER then
    util.AddNetworkString("Grabej")
    util.AddNetworkString("EndGrab")
    net.Receive("EndGrab",function (len, ply)
        if ply:IsValid() and ply:GetNWBool("Grabyat") == true and ply:GetNWEntity("GrabitKogo") == net.ReadEntity() then
            local target = ply:GetNWEntity("GrabitKogo")
            local procent = target:getDarkRPVar('money')*5/100
            target:addMoney(-procent)
            ply:addMoney(procent)
            DarkRP.notify(target,1,4,"Вас ограбили на "..tonumber(procent).."$")
            DarkRP.notify(ply,0,4,"Вы ограбили игрока "..target:Nick().." на "..tonumber(procent).."$")
            target.NextGrabTime = CurTime() + 120
        end
    end)
 
    function SWEP:PrimaryAttack() // ВАЖНО:Эта функция отвечает за свойства выстрела из левой кнопки мыши.
        local target = self.Owner:GetEyeTrace().Entity
        if target:IsPlayer() and self.Owner:GetPos():Distance(target:GetPos()) < 150 then
            if target.NextGrabTime == nil or target.NextGrabTime < CurTime() then
                local procent = target:getDarkRPVar('money')*5/100 -- Не забыть поменять на getDarkRPVar
                if target:canAfford(procent) then
                    self.Owner:SetNWBool("Grabyat",true)
                    self.Owner:SetNWEntity("GrabitKogo",target)
                    net.Start("Grabej")
                    net.Send(self.Owner)
                    print ("Send!")
 
                end
            else
                DarkRP.notify(self.Owner,1,4,"Его уже грабили. Оставь бедолагу в покое!")
            end
        end
    end
end
 
 
if CLIENT then
    tGrab = 1
    net.Receive("Grabej",function ()
        if LocalPlayer():GetNWBool("Grabyat") then
            LocalPlayer().HUDDraw = true
        end
    end)
 
    hook.Add("HUDPaint","GrabejHUD",function ()
        if LocalPlayer().HUDDraw == true then
            tGrab = tGrab + 1
            -- print (LocalPlayer():GetNWEntity("GrabitKogo"))
            if tGrab >= 350 then tGrab = 1 LocalPlayer().HUDDraw = false net.Start("EndGrab") net.WriteEntity(LocalPlayer():GetNWEntity("GrabitKogo")) net.SendToServer() return end
            if LocalPlayer():GetPos():Distance(LocalPlayer():GetEyeTrace().Entity:GetPos()) > 250 then LocalPlayer().HUDDraw = false tGrab = 1 LocalPlayer():SetNWBool("Grabyat", false) return end
            draw.RoundedBoxEx(0,ScrW()/2 - 170,ScrH()/2,350,40,Color(96,96,96,150),false,false,false,false)
            draw.RoundedBoxEx(0,ScrW()/2 - 170,ScrH()/2,tGrab,40,Color(9,100,255,255),false,false,false,false)
        end
    end)
 
end