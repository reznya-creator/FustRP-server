
include ("shared.lua")

SWEP.DrawCrosshair		= false
SWEP.ViewModelFOV		= 82
SWEP.ViewModelFlip		= true

SWEP.PrintName = "Viebat"
SWEP.Slot = 1
SWEP.SlotPos = 4;
SWEP.DrawAmmo = false;