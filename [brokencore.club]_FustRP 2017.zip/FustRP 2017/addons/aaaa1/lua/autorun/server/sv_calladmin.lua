CreateConVar( "call_reporturl", "", {FCVAR_ARCHIVE}, "The URL /calladmin will send a player to if no admins are connected" )
CreateConVar( "call_forcenoclip", 1, {FCVAR_ARCHIVE}, "Force noclip on admins responding to calls. This prevents falling off ledges etc." )
CreateConVar( "call_antispam", 15, {FCVAR_ARCHIVE}, "Minimum interval between calls. More frequent calls will be rejected automatically." )

util.AddNetworkString( "CA-ClientRequest" )
util.AddNetworkString( "CA-AcceptRequest" )
util.AddNetworkString( "CA-CallComplete" )
util.AddNetworkString( "CA-NoAdmins" )

local useULX = false

if ULib and ULib.ucl then
	ULib.ucl.registerAccess( "calladmin", ULib.ACCESS_ADMIN, "Allows response to Calladmin requests.", "Other" )
	useULX = true
end

-- Following functions credit to FPtje and/or the DarkRP github contributors
local function zapEffect( target )
	local effectdata = EffectData()
	effectdata:SetStart(target:GetShootPos())
	effectdata:SetOrigin(target:GetShootPos())
	effectdata:SetScale(1)
	effectdata:SetMagnitude(1)
	effectdata:SetScale(3)
	effectdata:SetRadius(1)
	effectdata:SetEntity(target)
	for i = 1, 100 do timer.Simple( 1/i, function() util.Effect( "TeslaHitBoxes", effectdata, true, true ) end ) end
	local Zap = math.random( 1, 9 )
	if Zap == 4 then Zap = 3 end
	target:EmitSound( "ambient/energy/zap"..Zap..".wav" )	
end

local function isEmpty(vector, ignore)
	ignore = ignore or {}

	local point = util.PointContents(vector)
	local a = point ~= CONTENTS_SOLID
		and point ~= CONTENTS_MOVEABLE
		and point ~= CONTENTS_LADDER
		and point ~= CONTENTS_PLAYERCLIP
		and point ~= CONTENTS_MONSTERCLIP

	local b = true

	for k,v in pairs(ents.FindInSphere(vector, 35)) do
		if (v:IsNPC() or v:IsPlayer() or v:GetClass() == "prop_physics") and not table.HasValue(ignore, v) then
			b = false
			break
		end
	end

	return a and b
end

local function findEmptyPos(pos, ignore, distance, step, area)
	if isEmpty(pos, ignore) and isEmpty(pos + area, ignore) then
		return pos
	end

	for j = step, distance, step do
		for i = -1, 1, 2 do -- alternate in direction
			local k = j * i

			-- Look North/South
			if isEmpty(pos + Vector(k, 0, 0), ignore) and isEmpty(pos + Vector(k, 0, 0) + area, ignore) then
				return pos + Vector(k, 0, 0)
			end

			-- Look East/West
			if isEmpty(pos + Vector(0, k, 0), ignore) and isEmpty(pos + Vector(0, k, 0) + area, ignore) then
				return pos + Vector(0, k, 0)
			end

			-- Look Up/Down
			if isEmpty(pos + Vector(0, 0, k), ignore) and isEmpty(pos + Vector(0, 0, k) + area, ignore) then
				return pos + Vector(0, 0, k)
			end
		end
	end

	return pos
end
--

net.Receive("CA-AcceptRequest", function( len, ply )

	if ( not useULX and not ply:IsAdmin() ) or ( useULX and not ULib.ucl.query( ply, "calladmin", true ) ) then
		return
	end
	
	local caller = net.ReadEntity()

	if not IsValid( caller ) then
		return 
	end

	local theAdmins = {}

	for k, v in pairs( player.GetAll() ) do
		if ( not useULX and v:IsAdmin() ) or ( useULX and ULib.ucl.query( v, "calladmin", true ) ) then
			theAdmins[ #theAdmins + 1 ] = v
		end
	end

	if #theAdmins > 0 then
		net.Start( "CA-CallComplete" )
		net.WriteEntity( ply )
		net.Send( theAdmins )
	end
	
	if not ply:Alive() then
		ply:Spawn()
	end
	
	ply:ExitVehicle()

	ply.recallPos = ply:GetPos()

	ply:SetPos( findEmptyPos( caller:GetPos(), {ply}, 600, 30, Vector(16, 16, 64) ) )
	ply:SetEyeAngles( ( caller:GetShootPos() - ply:GetShootPos() ):Angle() )

	if tobool( GetConVarNumber( "call_forcenoclip" ) ) then
		ply:ConCommand( "noclip" ) -- Force noclip, players on a ledge can result in the admin dying from fall damage
	end 

	zapEffect( ply )
	
end )

local function callAdmin( ply )

	if timer.Exists( "CA-" .. ply:SteamID() ) then
		ply:ChatPrint( "Вы слишком часто вызываете администрацию, подождите немного." )
		return		
	end

	timer.Create( "CA-" .. ply:SteamID(), GetConVarNumber( "call_antispam" ), 1, function() end)

	local theAdmins = {}

	for k, v in pairs( player.GetAll() ) do
		if ( not useULX and v:IsAdmin() ) or ( useULX and ULib.ucl.query( v, "calladmin", true ) ) then
			theAdmins[ #theAdmins + 1 ] = v
		end
	end

	if #theAdmins > 0 then
		ply:ChatPrint( "Администраторы увидят ваш запрос и примут его в ближайшее время." )
		net.Start( "CA-ClientRequest" )
		net.WriteEntity( ply )
		net.Send( theAdmins )	
	else
		ply:ChatPrint( "В данный момент нету администраторов в сети." )
		net.Start( "CA-NoAdmins" )
		net.WriteString( GetConVarString( "call_reporturl" ) )
		net.Send( ply )
	end

end

local function reCall( ply )

	if not ply.recallPos then
		return
	end
	
	ply:SetPos( findEmptyPos( ply.recallPos, {ply}, 600, 30, Vector( 16, 16, 64 ) ) )	
	zapEffect( ply )
	
	ply.recallPos = nil

end

hook.Add( "PlayerSay", "CA-ChatCommand", function( ply, text, team )

	if IsValid( ply ) and ply:IsPlayer() then -- Console can chat

		local text = string.lower( string.Left( text, 10 ) )

		if text == "/calladmin" then
			callAdmin( ply )
			return ""
		elseif string.Left( text, 7 ) == "/recall" then
			reCall( ply )
			return ""
		end

	end

end )