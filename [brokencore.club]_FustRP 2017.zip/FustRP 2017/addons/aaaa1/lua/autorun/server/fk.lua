if SERVER then
     local oldNetReadData = oldNetReadData or net.ReadData
        function net.ReadData(len)
        return oldNetReadData(math.Clamp(len,0,65533)) 
      end
end
