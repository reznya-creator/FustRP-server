hook.Add("PlayerShouldTakeDamage", "godmodeAdmin", function(ply, ent)
    if ply:Team() == TEAM_MODERATOR or ply:Team() == TEAM_ADMIN then
        return false
    end
end)

local JobWhiteListKill = {TEAM_MAYOR}
local JobWhiteListCanKill = {TEAM_GANG,TEAM_GANGVIP,TEAM_KILL,TEAM_NAIM}
hook.Add( "DoPlayerDeath", "DoPlayerDeathFix", function( ply, ent ,dmg )
	if table.HasValue( JobWhiteListKill, ply:Team()) and not table.HasValue( JobWhiteListCanKill, ent:Team())  then
		game.ConsoleCommand( "ulx ban "..ent:Name().." 1440 AvtoBan_RDM\n" )
	end
end)
