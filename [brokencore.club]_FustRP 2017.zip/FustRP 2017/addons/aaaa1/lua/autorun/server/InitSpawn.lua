util.AddNetworkString( 'ClearLagsDed' )


hook.Add( "PlayerInitialSpawn", "PlyInitSPawnHook", function( ply )
	timer.Simple( 240, function()  
		if IsValid( ply ) then
		ply:SetNWString("getfixdisconnect", 228) 
		--ply:ChatPrint("Автоконнект включает")
		end
	end )

	net.Start( "ClearLagsDed" )
	net.Send( ply )

end)
