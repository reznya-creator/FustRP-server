

local function blockPropsEffects( ply, mdl )
	local TextParammetes 
	for k, v in pairs(Props_1) do
		if v == mdl then 
			TextParammetes = false
		end 
	end
	for k, v in pairs(Props_3) do
		if v == mdl then 
			TextParammetes = false
		end 
	end
	for k, v in pairs(Props_4) do
		if v == mdl then 
			TextParammetes = false
		end 
	end
	if ply:GetUserGroup() != "superadmin" then 
		if TextParammetes == false then return true else return false end 
	end 
end
hook.Add( "PlayerSpawnProp", "blockProps", blockPropsEffects )
hook.Add( "PlayerSpawnEffect", "blockEffects", blockPropsEffects )