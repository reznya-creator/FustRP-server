﻿hook.Add("PlayerSpawnProp","ShapkaAntiPropSpam",function (ply, model)
	if ply.NextSpawnPropTime == nil or ply.NextSpawnPropTime < CurTime() then
		ply.NextSpawnPropTime = CurTime() + 1
		return true
	else
		DarkRP.notify(ply,1,4,"Вы не можете так часто спавнить пропы")
		return false
	end
end)
