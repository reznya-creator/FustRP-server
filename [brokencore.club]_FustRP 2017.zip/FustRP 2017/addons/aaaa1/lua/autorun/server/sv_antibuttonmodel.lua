hook.Add("CanTool","Button_different_model",function(ply, ent, tool)
	if tool == "button" then
		if not table.HasValue({"models/maxofs2d/button_01.mdl","models/maxofs2d/button_02.mdl","models/maxofs2d/button_03.mdl","models/maxofs2d/button_04.mdl","models/maxofs2d/button_05.mdl","models/maxofs2d/button_06.mdl","models/maxofs2d/button_slider.mdl"},ply:GetInfo("button_model")) then
			return false
		end
	end
end)
hook.Add("VehicleMove", "NoCollideVehicleVehicleMove", function(ply, vehicle)
	vehicle:SetCollisionGroup(7) 
end)