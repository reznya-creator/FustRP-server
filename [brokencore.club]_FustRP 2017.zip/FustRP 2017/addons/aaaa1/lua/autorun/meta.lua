local meta = FindMetaTable( "Player" )

-- donat users or admins

function meta:IsDonate()
 if self:GetUserGroup() != "user" then 
  return true
 else
  return false
 end
end


-- gun spawn
function meta:IsPwuser()
 if self:GetUserGroup()  == "st-admin" or self:GetUserGroup()  == "sadmind" or self:GetUserGroup()  == "operator" or self:IsSuperAdmin() then
  return true
 else
  return false
 end
end

-- cp
function meta:IsCppipi()
 if self:Team() == TEAM_POLICE or self:Team() == TEAM_CHIEF or self:Team() == TEAM_MAYOR or self:Team() == TEAM_FBI or self:Team() == TEAM_SWAT or self:Team() == TEAM_SWATM or self:Team() == TEAM_SWATS or self:Team() == TEAM_SWATL or self:Team() == TEAM_SWATH then
  return true
 else
  return false
 end
end

--admjob
function meta:IsAdmjob()
 if self:Team() == TEAM_ADMIN or self:Team() == TEAM_MODERATOR then
  return true
 else
  return false
 end
end

-- moneynotuser
function meta:Isnotuser()
 if self:IsAdmjob() or self:IsCppipi() then
  return true
 else
  return false
 end
end