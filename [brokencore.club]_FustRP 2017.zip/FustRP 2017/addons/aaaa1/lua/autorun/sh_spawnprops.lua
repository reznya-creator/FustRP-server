-----------------------------------------------------
-----------------------------------------------------
----------------------------
-- PROPS
----------------------------
Props_1 = {}
Props_1[1] = "models/hunter/plates/plate1x1.mdl"
Props_1[2] = "models/hunter/plates/plate1x2.mdl"
Props_1[3] = "models/hunter/plates/plate1x3.mdl"
Props_1[4] = "models/hunter/plates/plate1x4.mdl"
Props_1[5] = "models/hunter/plates/plate1x5.mdl"
Props_1[6] = "models/hunter/plates/plate1x6.mdl"
Props_1[7] = "models/hunter/plates/plate1x7.mdl"
Props_1[8] = "models/hunter/plates/plate1x8.mdl"
Props_1[9] = "models/hunter/plates/plate2x2.mdl"
Props_1[10] = "models/hunter/plates/plate2x4.mdl"
Props_1[11] = "models/hunter/plates/plate2x5.mdl"
Props_1[12] = "models/hunter/plates/plate2x6.mdl"
Props_1[13] = "models/hunter/plates/plate2x7.mdl"
Props_1[14] = "models/hunter/plates/plate2x8.mdl"
Props_1[15] = "models/hunter/plates/plate3x3.mdl"
Props_1[16] = "models/hunter/plates/plate3x4.mdl"
Props_1[17] = "models/hunter/plates/plate3x5.mdl"
Props_1[18] = "models/hunter/plates/plate3x6.mdl"
Props_1[19] = "models/hunter/plates/plate3x7.mdl"
Props_1[20] = "models/hunter/plates/plate3x8.mdl"
Props_1[21] = "models/hunter/plates/plate4x4.mdl"
Props_1[22] = "models/hunter/plates/plate4x5.mdl"
Props_1[23] = "models/hunter/plates/plate4x6.mdl"
Props_1[24] = "models/hunter/plates/plate4x8.mdl"
Props_1[25] = "models/hunter/plates/plate5x6.mdl"
Props_1[26] = "models/hunter/plates/plate5x7.mdl"
Props_1[27] = "models/hunter/plates/plate6x6.mdl"
Props_1[28] = "models/hunter/plates/plate6x7.mdl"
Props_1[29] = "models/hunter/plates/plate6x8.mdl"
Props_1[30] = "models/hunter/plates/plate7x7.mdl"
Props_1[31] = "models/hunter/plates/plate7x7.mdl"
Props_1[32] = "models/hunter/blocks/cube025x025x025.mdl"
Props_1[33] = "models/hunter/blocks/cube025x025x025.mdl"
Props_1[34] = "models/hunter/blocks/cube025x1x025.mdl"
Props_1[35] = "models/hunter/blocks/cube025x2x025.mdl"
Props_1[36] = "models/hunter/blocks/cube025x5x025.mdl"
Props_1[37] = "models/hunter/blocks/cube025x7x025.mdl"
Props_1[38] = "models/hunter/blocks/cube05x05x025.mdl"
Props_1[39] = "models/hunter/blocks/cube05x1x025.mdl"
Props_1[40] = "models/hunter/blocks/cube05x2x025.mdl"
Props_1[41] = "models/hunter/blocks/cube05x5x025.mdl"
Props_1[42] = "models/hunter/blocks/cube05x7x025.mdl"
Props_1[43] = "models/hunter/blocks/cube1x1x025.mdl"
Props_1[44] = "models/hunter/blocks/cube1x2x025.mdl"
Props_1[45] = "models/hunter/blocks/cube1x3x025.mdl"
Props_1[46] = "models/hunter/blocks/cube1x4x025.mdl"
Props_1[47] = "models/hunter/blocks/cube1x5x025.mdl"
Props_1[48] = "models/hunter/blocks/cube1x6x025.mdl"
Props_1[49] = "models/hunter/blocks/cube1x7x025.mdl"
Props_1[50] = "models/hunter/blocks/cube2x2x025.mdl"
Props_1[51] = "models/hunter/blocks/cube2x3x025.mdl"
Props_1[52] = "models/hunter/blocks/cube2x4x025.mdl"
Props_1[53] = "models/hunter/blocks/cube2x6x025.mdl"
Props_1[54] = "models/hunter/blocks/cube3x3x025.mdl"
Props_1[55] = "models/hunter/blocks/cube1x1x05.mdl"
Props_1[56] = "models/hunter/blocks/cube1x2x05.mdl"
Props_1[57] = "models/hunter/blocks/cube2x2x05.mdl"
Props_1[58] = "models/hunter/blocks/cube2x4x05.mdl"
Props_1[59] = "models/props_phx/construct/windows/window1x1.mdl"
Props_1[60] = "models/props_phx/construct/windows/window1x2.mdl"
Props_1[61] = "models/props_phx/construct/windows/window2x2.mdl"
Props_1[62] = "models/props_phx/construct/windows/window2x4.mdl"
Props_1[63] = "models/props_phx/construct/metal_tube.mdl"
Props_1[64] = "models/props_phx/construct/metal_tubex2.mdl"
Props_1[65] = "models/Mechanics/gears2/pinion_40t3.mdl"
Props_1[66] = "models/props_phx/rt_screen.mdl"
Props_1[67] = "models/props_phx/construct/metal_plate1x2.mdl"
Props_1[68] = "models/props_phx/construct/metal_plate1_tri.mdl"
Props_1[69] = "models/props_phx/construct/metal_plate2x2_tri.mdl"
Props_1[70] = "models/props_phx/construct/metal_plate2x4_tri.mdl"
Props_1[71] = "models/props_phx/construct/metal_plate4x4.mdl"
Props_1[72] = "models/props_phx/construct/metal_plate4x4_tri.mdl"
Props_1[73] = "models/props_phx/construct/windows/window1x2.mdl"
Props_1[74] = "models/props_phx/construct/windows/window1x1.mdl"
Props_1[75] = "models/hunter/blocks/cube075x2x025.mdl"
Props_1[76] = "models/hunter/blocks/cube1x2x025.mdl"
Props_1[77] = "models/hunter/blocks/cube05x105x05.mdl"
Props_1[78] = "models/hunter/blocks/cube05x2x05.mdl"
Props_1[79] = "models/hunter/tubes/circle2x2.mdl"
Props_1[80] = "models/hunter/triangles/025x025.mdl"
Props_1[81] = "models/hunter/triangles/2x2.mdl"
Props_1[82] = "models/hunter/triangles/4x4.mdl"
Props_1[83] = "models/hunter/plates/tri2x1.mdl"
Props_1[84] = "models/hunter/triangles/05x05x05.mdl"
Props_1[85] = "models/hunter/triangles/1x05x1.mdl"
Props_1[86] = "models/hunter/triangles/1x05x1.mdl"
Props_1[87] = "models/hunter/triangles/1x05x1.mdl"
Props_1[88] = "models/hunter/triangles/2x1x1.mdl"
Props_1[89] = "models/hunter/triangles/2x2x2.mdl"
Props_1[90] = "models/hunter/triangles/1x1x1carved.mdl"
Props_1[91] = "models/hunter/triangles/2x2x1carved.mdl"
Props_1[92] = "models/mechanics/solid_steel/crossbeam_8.mdl"
Props_1[93] = "models/mechanics/solid_steel/sheetmetal_box_4.mdl"
Props_1[94] = "models/mechanics/solid_steel/steel_beam45_4.mdl"
Props_1[95] = "models/Mechanics/robotics/stand.mdl"
Props_1[96] = "models/mechanics/roboticslarge/claw_hub_8.mdl"
Props_1[97] = "models/Mechanics/robotics/a3.mdl"
Props_1[98] = "models/Mechanics/robotics/m3.mdl"
Props_1[99] = "models/mechanics/wheels/wheel_spike_24.mdl"
Props_1[100] = "models/props_phx/smallwheel.mdl"
Props_1 [101] = "models/hunter/misc/shell2x2a.mdl"
Props_1 [102] = "models/props_phx/construct/metal_wire_angle180x1.mdl"
Props_1 [103] = "models/XQM/cylinderx1medium.mdl"










Props_3 = {}
Props_3[1] = "models/props_c17/FurnitureCouch002a.mdl"
Props_3[2] = "models/props_c17/FurnitureCouch001a.mdl"
Props_3[3] = "models/props_c17/FurnitureChair001a.mdl"
Props_3[4] = "models/props_c17/FurnitureDrawer001a.mdl"
Props_3[5] = "models/props_c17/FurnitureDrawer002a.mdl"
Props_3[6] = "models/props_c17/FurnitureFireplace001a.mdl"
Props_3[7] = "models/props_c17/FurnitureRadiator001a.mdl"
Props_3[8] = "models/props_c17/FurnitureShelf001a.mdl"
Props_3[9] = "models/props_c17/FurnitureShelf001b.mdl"
Props_3[10] = "models/props_c17/FurnitureSink001a.mdl"
Props_3[11] = "models/props_c17/FurnitureTable001a.mdl"
Props_3[12] = "models/props_c17/FurnitureTable002a.mdl"
Props_3[13] = "models/props_c17/lampShade001a.mdl"
Props_3[14] = "models/props_c17/FurnitureToilet001a.mdl"
Props_3[15] = "models/props_c17/gravestone002a.mdl"
Props_3[16] = "models/props_c17/gravestone_coffinpiece001a.mdl"
Props_3[17] = "models/props_junk/PlasticCrate01a.mdl"
Props_3[18] = "models/props_c17/Lockers001a.mdl"
Props_3[19] = "models/props_c17/metalladder001.mdl"
Props_3[20] = "models/props_c17/oildrum001.mdl"
Props_3[21] = "models/props_c17/shelfunit01a.mdl"
Props_3[22] = "models/props_combine/breenchair.mdl"
Props_3[23] = "models/props_combine/breendesk.mdl"
Props_3[24] = "models/props_interiors/BathTub01a.mdl"
Props_3[25] = "models/props_interiors/Furniture_chair01a.mdl"
Props_3[26] = "models/props_junk/MetalBucket01a.mdl"
Props_3[27] = "models/props_junk/MetalBucket02a.mdl"
Props_3[28] = "models/props_junk/PushCart01a.mdl"
Props_3[29] = "models/props_junk/metalgascan.mdl"
Props_3[30] = "models/props_junk/TrashBin01a.mdl"
Props_3[31] = "models/props_trainstation/trashcan_indoor001b.mdl"
Props_3[32] = "models/props_wasteland/barricade001a.mdl"
Props_3[33] = "models/props_wasteland/barricade002a.mdl"
Props_3[34] = "models/props_wasteland/controlroom_filecabinet002a.mdl"
Props_3[35] = "models/props_wasteland/kitchen_shelf001a.mdl"
Props_3[36] = "models/props_wasteland/interior_fence002e.mdl"
Props_3[37] = "models/props_wasteland/interior_fence002d.mdl"
Props_3[38] = "models/props_wasteland/controlroom_desk001b.mdl"
Props_3[39] = "models/props_trainstation/trainstation_post001.mdl"
Props_3[40] = "models/props_lab/blastdoor001a.mdl"
Props_3[41] = "models/props_c17/cashregister01a.mdl"
Props_3[42] = "models/props_c17/bench01a.mdl"
Props_3[43] = "models/props_c17/clock01.mdl"
Props_3[44] = "models/props_c17/chair_office01a.mdl"
Props_3[45] = "models/props_c17/computer01_keyboard.mdl"
Props_3[46] = "models/props_c17/FurnitureWashingmachine001a.mdl"
Props_3[47] = "models/props_combine/combine_monitorbay.mdl"
Props_3[48] = "models/props_lab/harddrive02.mdl"
Props_3[49] = "models/props_lab/huladoll.mdl"
Props_3[50] = "models/props_lab/monitor01a.mdl"
Props_3[51] = "models/props_trainstation/bench_indoor001a.mdl"
Props_3[52] = "models/props_interiors/Furniture_Lamp01a.mdl"
Props_3[53] = "models/props_interiors/pot02a.mdl"
Props_3[54] = "models/props_junk/garbage_plasticbottle002a.mdl"
Props_3[55] = "models/props_junk/garbage_plasticbottle001a.mdl"
Props_3[56] = "models/props_lab/desklamp01.mdl"
Props_3[57] = "models/props_interiors/VendingMachineSoda01a.mdl"
Props_3[58] = "models/props_junk/bicycle01a.mdl"
Props_3[59] = "models/props_c17/streetsign001c.mdl"
Props_3[60] = "models/props_c17/streetsign002b.mdl"
Props_3[61] = "models/props_c17/streetsign003b.mdl"
Props_3[62] = "models/props_c17/streetsign004e.mdl"
Props_3[63] = "models/props_c17/streetsign004f.mdl"
Props_3[64] = "models/props_c17/streetsign005b.mdl"
Props_3[65] = "models/props_c17/streetsign005c.mdl"
Props_3[66] = "models/props_c17/streetsign005d.mdl"
Props_3[67] = "models/props_c17/fence01a.mdl"
Props_3[68] = "models/props_c17/fence01b.mdl"
Props_3[69] = "models/props_c17/fence02a.mdl"
Props_3[70] = "models/props_c17/fence02b.mdl"
Props_3[71] = "models/props_c17/fence03a.mdl"
Props_3[72] = "models/props_borealis/mooring_cleat01.mdl"
Props_3[73] = "models/props_borealis/bluebarrel001.mdl"
Props_3[74] = "models/props_c17/canister02a.mdl"
Props_3[75] = "models/props_c17/canister_propane01a.mdl"
Props_3[76] = "models/props_c17/concrete_barrier001a.mdl"
Props_3[77] = "models/props_c17/FurnitureDrawer002a.mdl"
Props_3[78] = "models/props_c17/FurnitureTable003a.mdl"
Props_3[79] = "models/props_lab/frame002a.mdl"
Props_3[80] = "models/props_combine/breenclock.mdl"
Props_3[81] = "models/props_combine/breenglobe.mdl"
Props_3[82] = "models/props_combine/combine_interface001.mdl"
Props_3[83] = "models/props_combine/combine_intmonitor001.mdl"
Props_3[84] = "models/props_doors/door03_slotted_left.mdl"
Props_3[85] = "models/props_interiors/Furniture_Couch01a.mdl"
Props_3[86] = "models/props_interiors/BathTub01a.mdl"
Props_3[87] = "models/props_interiors/Furniture_Desk01a.mdl"
Props_3[88] = "models/props_interiors/Furniture_Vanity01a.mdl"
Props_3[89] = "models/props_c17/FurnitureFridge001a.mdl"
Props_3[90] = "models/props_interiors/SinkKitchen01a.mdl"
Props_3[91] = "models/props_wasteland/controlroom_filecabinet002a.mdl"
Props_3[92] = "models/props_trainstation/trainstation_clock001.mdl"
Props_3[93] = "models/props_junk/TrafficCone001a.mdl"
Props_3[94] = "models/props_junk/TrashBin01a.mdl"
Props_3[95] = "models/props_junk/TrashDumpster01a.mdl"
Props_3[96] = "models/props_junk/CinderBlock01a.mdl"
Props_3[97] = "models/props_docks/dock01_cleat01a.mdl"
Props_3[98] = "models/props_wasteland/cafeteria_bench001a.mdl"
Props_3[99] = "models/props_c17/TrapPropeller_Engine.mdl"
Props_3[100] = "models/props_c17/playground_jungle_gym01a.mdl"
Props_3[101] = "models/props_c17/playground_jungle_gym01b.mdl"
Props_3[102] = "models/props_c17/playgroundTick-tack-toe_post01.mdl"
Props_3[103] = "models/props_lab/binderbluelabel.mdl"
Props_3[104] = "models/props_lab/bewaredog.mdl"
Props_3[105] = "models/props_lab/cactus.mdl"
Props_3[106] = "models/props_trainstation/traincar_seats001.mdl"
Props_3[107] = "models/props_trainstation/payphone001a.mdl"
Props_3[108] = "models/props_trainstation/bench_indoor001a.mdl"
Props_3[109] = "models/props_junk/metalgascan.mdl"
Props_3[110] = "models/props_junk/PlasticCrate01a.mdl"
Props_3[111] = "models/props_c17/gate_door01a.mdl"
Props_3[112] = "models/props_wasteland/prison_celldoor001b.mdl"
Props_3[113] = "models/props_wasteland/prison_lamp001c.mdl"
Props_3[114] = "models/props_wasteland/prison_bedframe001b.mdl"
Props_3[115] = "models/props_c17/metalPot002a.mdl"
Props_3[116] = "models/props_c17/metalPot001a.mdl"
Props_3[117] = "models/props_c17/playgroundTick-tack-toe_post01.mdl"
Props_3[118] = "models/props_c17/SuitCase001a.mdl"
Props_3[119] = "models/props_junk/garbage_takeoutcarton001a.mdl"
Props_3[120] = "models/props_lab/plotter.mdl"
Props_3[121] = "models/props_lab/reciever01a.mdl"
Props_3[122] = "models/props_lab/reciever01b.mdl"
Props_3[123] = "models/props_lab/reciever01d.mdl"
Props_3[124] = "models/props_lab/reciever_cart.mdl"
Props_3[125] = "models/props_lab/securitybank.mdl"
Props_3[126] = "models/props_lab/kennel_physics.mdl"
Props_3[127] = "models/props_c17/doll01.mdl"
Props_3[128] = "models/props_c17/Frame002a.mdl"
Props_3[129] = "models/props_c17/gravestone001a.mdl"
Props_3[130] = "models/props_c17/gravestone003a.mdl"
Props_3[131] = "models/props_c17/playgroundTick-tack-toe_block01a.mdl"
Props_3[132] = "models/props_c17/tools_wrench01a.mdl"
Props_3[133] = "models/props_c17/TrapPropeller_Lever.mdl"
Props_3[134] = "models/Gibs/HGIBS.mdl"
Props_3[135] = "models/props_lab/clipboard.mdl"
Props_3[136] = "models/props_lab/crematorcase.mdl"
Props_3[137] = "models/props_interiors/pot01a.mdl"
Props_3[138] = "models/props_junk/metal_paintcan001a.mdl"
Props_3[139] = "models/props_trainstation/clock01.mdl"


Props_4 = {}
Props_4[1] = "models/props_junk/garbage128_composite001a.mdl"
Props_4[2] = "models/props_junk/garbage128_composite001b.mdl"
Props_4[3] = "models/props_junk/garbage128_composite001c.mdl"
Props_4[4] = "models/props_junk/garbage128_composite001d.mdl"
Props_4[5] = "models/props_junk/garbage256_composite001a.mdl"
Props_4[6] = "models/props_junk/garbage256_composite001b.mdl"
Props_4[7] = "models/props_junk/garbage256_composite002a.mdl"
Props_4[8] = "models/props_junk/garbage256_composite002b.mdl"
Props_4[9] = "models/props_junk/garbage_carboard002a.mdl"
Props_4[10] = "models/props_junk/garbage_bag001a.mdl"
Props_4[11] = "models/props_junk/garbage_glassbottle003a.mdl"
Props_4[12] = "models/props_junk/garbage_metalcan001a.mdl"
Props_4[13] = "models/props_junk/garbage_metalcan002a.mdl"
Props_4[14] = "models/props_junk/Shoe001a.mdl"
Props_4[15] = "models/props_lab/bewaredog.mdl"
Props_4[16] = "models/props_junk/wood_pallet001a.mdl"
Props_4[17] = "models/props_junk/TrashDumpster02b.mdl"
Props_4[18] = "models/props_junk/TrashDumpster02b.mdl"
Props_4[19] = "models/props_lab/blastdoor001b.mdl"
Props_4[20] = "models/props_lab/blastdoor001c.mdl"
Props_4[21] = "models/props_vehicles/tire001c_car.mdl"

if CLIENT then
    local CfgVars = {}
    local WEBSITE = {}
    CfgVars["EquipmentDecayTimer"] = 3
    CfgVars["WeaponDecayTimer"] = 3
    CfgVars["DrugDecayTimer"] = 3
    local buytable = {}
    buytable["1) Строительство:"] = {}
    buytable["1) Строительство:"].Model = Props_1
    buytable["1) Строительство:"].Data = Props_1
    buytable["2) Основное:"] = {}
    buytable["2) Основное:"].Model = Props_3
    buytable["2) Основное:"].Data = Props_3
    buytable["3) Для бомжей:"] = {}
    buytable["3) Для бомжей:"].Model = Props_4
    buytable["3) Для бомжей:"].Data = Props_4
    local PANEL = {}

    function PANEL:Init()
        self.PanelList = vgui.Create("DPanelList", self)
        self.PanelList:SetPadding(4)
        self.PanelList:SetSpacing(2)
        self.PanelList:EnableVerticalScrollbar(true)
        self:BuildList()
    end

    local function AddComma(n)
        local sn = tostring(n)
        sn = string.ToTable(sn)
        local tab = {}

        for i = 0, #sn - 1 do
            if i % 3 == #sn % 3 and not (i == 0) then
                table.insert(tab, ",")
            end

            table.insert(tab, sn[i + 1])
        end

        return string.Implode("", tab)
    end

    function PANEL:BuildList()
        self.PanelList:Clear()
        local Categorised = {}

        for k, v in pairs(buytable) do
            v.Category = k
            Categorised[v.Category] = Categorised[v.Category] or {}
            table.insert(Categorised[v.Category], v)
        end

        for CategoryName, v in SortedPairs(Categorised) do
            local Category = vgui.Create("DCollapsibleCategory", self)
            self.PanelList:AddItem(Category)
            Category:SetExpanded(false)
            Category:SetLabel(CategoryName)
            Category:SetCookieName("EntitySpawn." .. CategoryName)
            local Content = vgui.Create("DPanelList")
            Category:SetContents(Content)
            Content:EnableHorizontal(true)
            Content:SetDrawBackground(false)
            Content:SetSpacing(2)
            Content:SetPadding(2)
            Content:SetAutoSize(true)
            number = 1

            for k, v in pairs(buytable[CategoryName].Model) do
              
                local Icon = vgui.Create("SpawnIcon", self)
                local Model = buytable[CategoryName].Model[number]

                if (buytable[CategoryName].Model[number] ~= nil) then
                    Icon:SetModel(buytable[CategoryName].Model[number])
                else
                    Icon:SetModel("models/error.mdl")
                end

                Icon.DoClick = function()
                    RunConsoleCommand("gm_spawn", Model)
                end

                local lable = vgui.Create("DLabel", Icon)
                lable:SetFont("DebugFixedSmall")
                lable:SetTextColor(color_black)
                lable:SetText(Model)
                lable:SetContentAlignment(5)
                lable:SetWide(self:GetWide())
                lable:AlignBottom(-42)
                Content:AddItem(Icon)
                number = number + 1
            end
        end

        self.PanelList:InvalidateLayout()
    end

    function PANEL:PerformLayout()
        self.PanelList:StretchToParent(0, 0, 0, 0)
    end

    local CreationSheet = vgui.RegisterTable(PANEL, "Panel")

    local function CreateContentPanel()
        local ctrl = vgui.CreateFromTable(CreationSheet)

        return ctrl
    end

    local function RemoveSandboxTabs()
    	local AccsesGroup = {"superadmin","OWNER","sadmin-d"}
        local tabstoremove = {
	        	language.GetPhrase("spawnmenu.content_tab"), 
		        language.GetPhrase("spawnmenu.category.npcs"), 
		        language.GetPhrase("spawnmenu.category.entities"), 
		        language.GetPhrase("spawnmenu.category.weapons"), 
		        language.GetPhrase("spawnmenu.category.vehicles"), 
		        language.GetPhrase("spawnmenu.category.postprocess"), 
		        language.GetPhrase("spawnmenu.category.dupes"), 
		        language.GetPhrase("spawnmenu.category.saves")
    	}
    	
   		if !table.HasValue(AccsesGroup, LocalPlayer():GetUserGroup()) then 
	    	for k, v in pairs(g_SpawnMenu.CreateMenu.Items) do
	            if table.HasValue(tabstoremove, v.Tab:GetText()) then
	                g_SpawnMenu.CreateMenu:CloseTab(v.Tab, true)
	                RemoveSandboxTabs()
	            end
	        end
	    end
    end

    hook.Add("SpawnMenuOpen", "blockmenutabs", RemoveSandboxTabs)

    local function BunkMenu()
        return
    end

    spawnmenu.AddCreationTab("Разрешенные пропы", CreateContentPanel, "icon16/application_view_tile.png", 4)
end



--------------=====================================----------------------
--[[
Wep_1 = {}

Wep_1[1] = {"models/props_vehicles/tire001c_car.mdl","swb_357"}

if CLIENT then
    local CfgVars = {}
    local WEBSITE = {}
    CfgVars["EquipmentDecayTimer"] = 3
    CfgVars["WeaponDecayTimer"] = 3
    CfgVars["DrugDecayTimer"] = 3
    local buytableWep = {}
    buytableWep["1) Доступные Оружие:"] = {}
    buytableWep["1) Доступные Оружие:"].Model = Wep_1[]
    buytableWep["1) Доступные Оружие:"].ent = Wep_1
    local PANEL = {}

    function PANEL:Init()
        self.PanelList = vgui.Create("DPanelList", self)
        self.PanelList:SetPadding(4)
        self.PanelList:SetSpacing(2)
        self.PanelList:EnableVerticalScrollbar(true)
        self:BuildList()
    end

    local function AddComma(n)
        local sn = tostring(n)
        sn = string.ToTable(sn)
        local tab = {}

        for i = 0, #sn - 1 do
            if i % 3 == #sn % 3 and not (i == 0) then
                table.insert(tab, ",")
            end

            table.insert(tab, sn[i + 1])
        end

        return string.Implode("", tab)
    end

    function PANEL:BuildList()
        self.PanelList:Clear()
        local Categorised = {}

        for k, v in pairs(buytableWep) do
            v.Category = k
            Categorised[v.Category] = Categorised[v.Category] or {}
            table.insert(Categorised[v.Category], v)
        end

        for CategoryName, v in SortedPairs(Categorised) do
            local Category = vgui.Create("DCollapsibleCategory", self)
            self.PanelList:AddItem(Category)
            Category:SetExpanded(false)
            Category:SetLabel(CategoryName)
            Category:SetCookieName("EntitySpawn." .. CategoryName)
            local Content = vgui.Create("DPanelList")
            Category:SetContents(Content)
            Content:EnableHorizontal(true)
            Content:SetDrawBackground(false)
            Content:SetSpacing(2)
            Content:SetPadding(2)
            Content:SetAutoSize(true)
            number = 1

            for k, v in pairs(buytableWep[CategoryName].Model) do
              
                local Icon = vgui.Create("SpawnIcon", self)
                local Model = buytableWep[CategoryName].Model[number]

                if (buytableWep[CategoryName].Model[number] ~= nil) then
                    Icon:SetModel(buytableWep[CategoryName].Model[number])
                else
                    Icon:SetModel("models/error.mdl")
                end

                Icon.DoClick = function()
                    RunConsoleCommand("gm_spawn", Model)
                end

                local lable = vgui.Create("DLabel", Icon)
                lable:SetFont("DebugFixedSmall")
                lable:SetTextColor(color_black)
                lable:SetText(Model)
                lable:SetContentAlignment(5)
                lable:SetWide(self:GetWide())
                lable:AlignBottom(-42)
                Content:AddItem(Icon)
                number = number + 1
            end
        end

        self.PanelList:InvalidateLayout()
    end

    function PANEL:PerformLayout()
        self.PanelList:StretchToParent(0, 0, 0, 0)
    end

    local CreationSheet = vgui.RegisterTable(PANEL, "Panel")

    local function CreateContentPanelWep()
        local ctrl = vgui.CreateFromTable(CreationSheet)

        return ctrl
    end


    spawnmenu.AddCreationTab("Оружие (sadmin-d)", CreateContentPanelWep, "icon16/gun.png", 5)
end


]]