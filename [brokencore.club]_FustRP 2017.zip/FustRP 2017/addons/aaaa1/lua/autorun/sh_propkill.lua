local Tag="propkill"
AddCSLuaFile()

if CLIENT then
    hook.Add("PhysgunPickup", Tag, function(pl, ent)
        ent:SetCollisionGroup(COLLISION_GROUP_WEAPON)
    end)
    
    return
end

do
	local ignore

	hook.Add("PhysgunPickup", Tag, function(pl, ent)
		if ent:IsPlayer() then return end
		if ignore then return end

		ignore = true
		local canTouch = hook.Run("PhysgunPickup", pl, ent)
		ignore = false

		if canTouch and not ent:CreatedByMap() and not (ent:GetCollisionGroup() == COLLISION_GROUP_WORLD) then
			ent.Old_ColGroup = ent:GetCollisionGroup() or COLLISION_GROUP_NONE
			ent:SetCollisionGroup(COLLISION_GROUP_WEAPON)
		end
	end)
end

hook.Add("PlayerSpawnedVehicle", Tag, function(pl, ent)
	ent:SetCollisionGroup(COLLISION_GROUP_PLAYER)
end)

hook.Add("PlayerEnteredVehicle", Tag, function(pl, ent)
	ent:SetCollisionGroup(COLLISION_GROUP_PLAYER)
end)

hook.Add("PlayerLeaveVehicle", Tag, function(pl, ent)
	timer.Simple(1, function()
		if IsValid(ent) then
			ent:SetCollisionGroup(COLLISION_GROUP_PLAYER)
		end
	end)
end)

hook.Add("PhysgunDrop", Tag, function(pl, ent)
	if ent:IsPlayer() then return end
	ent:SetPos(ent:GetPos())

	if ent.Old_ColGroup then
		ent:SetCollisionGroup(ent.Old_ColGroup)
		ent.Old_ColGroup = nil
	end

	local phys = ent:GetPhysicsObject()
	if IsValid(phys) then
		phys:AddAngleVelocity(phys:GetAngleVelocity() * -1)
	end
end)

hook.Add("PlayerShouldTakeDamage", Tag, function(pl, ent)
	if hook.Run("PropKill-PlayerShouldTakeDamage", pl, ent) then
		ent:SetPos(ent:GetPos())
		return false
	end
end)

hook.Add("PropKill-PlayerShouldTakeDamage", Tag, function(pl, ent)
	return ent.CPPIGetOwner and ent:CPPIGetOwner() and not ent:IsNPC()
end)

hook.Add("EntityTakeDamage", Tag, function(pl, dmg)
	if hook.Run("PropKill-EntityTakeDamage", pl, dmg) then
		dmg:SetDamage(0)
	end
end)

hook.Add("PropKill-EntityTakeDamage", Tag, function(pl, dmg)
	return pl:IsPlayer() and (dmg:GetAttacker():IsWorld() or (IsValid(dmg:GetAttacker()) and not dmg:GetAttacker():CreatedByMap())) and dmg:IsDamageType(DMG_CRUSH)
end)