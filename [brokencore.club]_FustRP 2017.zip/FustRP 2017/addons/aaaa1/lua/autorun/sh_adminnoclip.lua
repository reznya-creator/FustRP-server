hook.Add( "PlayerNoClip", "noclipThing", function( ply )
	if not ply:IsUserGroup("superadmin") then
		return ply:Team() == TEAM_MODERATOR or ply:Team() == TEAM_ADMIN
	end
end)


