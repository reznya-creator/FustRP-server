
-----------------------------------------------------

local draw = draw
local surface = surface
local cam = cam
local math = math
local team = team

local eyepos
local Page = Material("icon64/tool.png")

surface.CreateFont ("Playernik1", {      

        size = 250,

        weight = 800,

        antialias = true,

        additive = false,		

        font = "Tahoma"})

surface.CreateFont ("Playernik1.1", {      

        size = 250,

        weight = 800,

        antialias = true,

		additive = false,

		blursize = 10,   		

        font = "Tahoma"})

		


surface.CreateFont ("PlayerFon1", {      

        size = 100,

        weight = 800,

        antialias = true,

        additive = false,		

        font = "Tahoma"})

surface.CreateFont ("PlayerFon1.1", {      

        size = 100,

        weight = 800,

        antialias = true,

		additive = false,

		blursize = 10,   		

        font = "Tahoma"})

		
------------------------------

surface.CreateFont ("PlayerOrg1", {      

        size = 85,

        weight = 800,

        antialias = true,

        additive = false,		

        font = "Tahoma"})

surface.CreateFont ("PlayerOrg1.1", {      

        size = 85,

        weight = 800,

        antialias = true,

		additive = false,

		blursize = 10,   		

        font = "Tahoma"})

		
		
		
		
		

--Arial Narrow

hook.Add("RenderScene", "3D2DNicksPosAng",function(pos)
	eyepos = pos
end)

hook.Add("PostPlayerDraw", "3D2DNicks", function(ply)
	local dist = ply:GetPos():Distance(eyepos)
	if dist > 350 or !ply:Alive() then return end
	local bone = ply:LookupAttachment("eyes")
	if bone == 0 then return end
			
	local attach = ply:GetAttachment(bone)
	local alpha = 255 * (1 - math.Clamp((dist - 250) / 100, 0, 1))
	local color = team.GetColor(ply:Team())
	local jobcolor = Color(color.r, color.g, color.b, alpha)
	local nickcolor = Color(0,255,0,255)

	if ply:GetNWBool("PlayerNickColored", false) then 
		local col = ply:GetNWVector("PlayerNickColor") 
		nickcolor = Color(col.x, col.y, col.z, alpha)
	end

    local orrg=ply:GetNWString("orgName")
	cam.Start3D2D(attach.Pos + Vector(0, 0, 25), Angle(0, (attach.Pos - eyepos):Angle().y - 90, 90), 0.05)
		draw.SimpleText(ply:Nick(), "Playernik1", 0, 120, nickcolor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		--draw.SimpleText(ply:Nick(), "Playernik1.1", 0, 120, nickcolor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(ply:getDarkRPVar("job"), "PlayerFon1", 0, 230, jobcolor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(""..orrg, "PlayerOrg1", 0, 310, Color(196, 31, 255, 257), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(""..orrg, "PlayerOrg1.1", 0, 310, Color(165, 31, 255, 257), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        if ply:getDarkRPVar("HasGunlicense") then
			surface.SetMaterial(Page)
			surface.SetDrawColor(Color(255, 255, 255, alpha))
			surface.DrawTexturedRect(360, 210, 70, 70)
		end        

		if ply:getDarkRPVar("wanted") then
			draw.SimpleText("В розыске: "..ply:getDarkRPVar("wantedReason"), "PlayerFon1", 0, -150, Color(255, 0, 0, alpha),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
		end
	cam.End3D2D()
end)

hook.Add("InitPostEntity", "HitHaloInitPost", function()
	local localplayer = LocalPlayer() 
	local haloAdd = halo.Add

	hook.Add("PreDrawHalos", "HitHalo", function()
		if localplayer:isHitman() and localplayer:hasHit() and IsValid(localplayer:getHitTarget()) then
			haloAdd({localplayer:getHitTarget()}, Color(255,0,0), 1, 1, 5, false, true)
		end
	end)
end)