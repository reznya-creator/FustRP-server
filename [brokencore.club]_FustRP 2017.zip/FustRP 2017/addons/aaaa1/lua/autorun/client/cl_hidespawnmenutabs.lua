
-----------------------------------------------------

-----------------------------------------------------
hook.Add("SpawnMenuOpen", "Tsoyvsikarus", function()
	local all = {"#spawnmenu.category.dupes", "#spawnmenu.category.saves"}
	local nonadmins = {"#spawnmenu.category.weapons", "#spawnmenu.category.entities", "#spawnmenu.category.postprocess", "#spawnmenu.category.vehicles", "#spawnmenu.category.npcs"}
	
	for k = #g_SpawnMenu.CreateMenu.Items, 1, -1 do
		local v = g_SpawnMenu.CreateMenu.Items[k]
		if table.HasValue(all, v.Name) or not LocalPlayer():IsSuperAdmin() and table.HasValue(nonadmins, v.Name) then
			g_SpawnMenu.CreateMenu:CloseTab(v.Tab, true)
		end
	end
	hook.Remove("SpawnMenuOpen", "Tsoyvsikarus")
end)

--[[
"#spawnmenu.category.dupes" -- Никто
"#spawnmenu.category.saves" -- Никто
"#spawnmenu.category.npcs" -- Superadmin
"#spawnmenu.category.vehicles" -- Superadmin
"#spawnmenu.category.postprocess" -- user
"#spawnmenu.category.entities" -- Superadmin
"#spawnmenu.category.weapons" -- user
"SCars" -- Superadmin
]]