﻿net.Receive( "CA-ClientRequest", function ( len, ply )

	if IsValid( ply ) and ply:IsPlayer() then return end -- Clientside lua
	
	local caller = net.ReadEntity()
	
	if not IsValid( caller ) then
		return
	end
	
	print( "Вас вызвал игрок " .. caller:Nick() .. "!" )
	
	system.FlashWindow()	
	
	LocalPlayer():EmitSound( "common/warning.wav", 100, 100 )	
	
	local rearPanel = vgui.Create( "DFrame" )
	rearPanel:SetPos( 300, 300 )
	rearPanel:SetSize( 175, 200 )
	rearPanel:SetTitle( "" )
	rearPanel:SetVisible( true )
	rearPanel:SetDraggable( true )
	rearPanel:ShowCloseButton( false )
	rearPanel:SetKeyboardInputEnabled( false )

	rearPanel.Paint = function( self )
		draw.RoundedBox( 2, 0, 0, self:GetWide(), self:GetTall(), Color( 0, 0, 0, 220 ) )
	end
	
	local yesButton = vgui.Create( "DButton", rearPanel )
	yesButton:SetParent( rearPanel )
	yesButton:SetText( "Да" )
	yesButton:SetTextColor( Color( 255, 255, 255, 200 ) )
	yesButton:SetPos( ( rearPanel:GetWide() / 5 ) * 1, rearPanel:GetTall() - 50 )
	yesButton:SetSize( 40, 30 )
	yesButton.DoClick = function()
		net.Start( "CA-AcceptRequest" )
			net.WriteEntity( caller )
		net.SendToServer()
		rearPanel:Remove()
	end
	yesButton.Paint = function( self )
		draw.RoundedBox( 2, 0, 0, self:GetWide(), self:GetTall(), Color( 100, 100, 100, 120 ) )
	end
		
	local noButton = vgui.Create( "DButton", rearPanel )
	noButton:SetParent( rearPanel )
	noButton:SetText( "Нет" )
	noButton:SetTextColor( Color( 255, 255, 255, 200 ) )
	noButton:SetPos( ( rearPanel:GetWide() / 5 ) * 3, rearPanel:GetTall() - 50 )
	noButton:SetSize( 40, 30 )
	noButton.DoClick = function()
		rearPanel:Remove()
	end
	noButton.Paint = function( self )
		draw.RoundedBox( 2, 0, 0, self:GetWide(), self:GetTall(), Color( 100, 100, 100, 120 ) )
	end

-- Seperate text because some people have crazy long names
	local textLabelA = vgui.Create( "DLabel", rearPanel )
	textLabelA:AlignTop( 50 )
	textLabelA:SetColor( Color( 255, 255, 255, 200 ) )
	textLabelA:SetText( "Вас вызвал игрок:" )
	textLabelA:SizeToContents()
	textLabelA:CenterHorizontal()

	local textLabelB = vgui.Create( "DLabel", rearPanel )
	textLabelB:AlignTop( 75 )
	textLabelB:SetColor( Color( 255, 255, 255, 200 ) )
	textLabelB:SetText( caller:Nick() )
	textLabelB:SizeToContents()
	textLabelB:CenterHorizontal()
	
	local textLabelC = vgui.Create( "DLabel", rearPanel )
	textLabelC:AlignTop( 100 )
	textLabelC:SetColor( Color( 255, 255, 255, 200 ) )
	textLabelC:SetText( "Желаете принять вызов?" )
	textLabelC:SizeToContents()
	textLabelC:CenterHorizontal()
	
	net.Receive( "CA-CallComplete", function()

		local responder = net.ReadEntity()

		if IsValid( responder ) then
			print( responder:Nick() .. " запросил вызов администратора!")
		end

		rearPanel:Remove() 

	end )

end )

net.Receive( "CA-NoAdmins", function( len, ply )
	
	local str = net.ReadString()

	if str and str ~= "" then
		gui.OpenURL( net.ReadString() )
	end

end)
