-- СО́БСТВЕННОСТЬ https://vk.com/millenium_drawt

surface.CreateFont( "GModNotify", {
	size = 22,
	weight = 350,
	antialias = true,
	extended = true,
	font = "Roboto"
})

module( "notification", package.seeall)

NOTIFY_VOTE = 5

local colors = {
	[NOTIFY_GENERIC] = Color( 0, 0, 0, 255*0.9 ),
	[NOTIFY_ERROR] = Color( 0, 0, 0, 255*0.9 ),
	[NOTIFY_UNDO] = Color( 0, 0, 0, 255*0.9 ),
	[NOTIFY_HINT] = Color( 0, 0, 0, 255*0.9 ),
	[NOTIFY_CLEANUP] = Color( 0, 0, 200, 255*0.9 ),
	[NOTIFY_VOTE] = Color( 60, 60, 60, 255*0.9 )
}

do
	local PANEL = {}

	AccessorFunc( PANEL, "notificationType", "Type", FORCE_NUMBER )
	AccessorFunc( PANEL, "notificationText", "Text", FORCE_STRING )
	AccessorFunc( PANEL, "notificationIndex", "Index" )

	function PANEL:Init()
		self:SetWide( 300 )
		self:SetTall(0)
		self:SetText( "It works!" )
		self:SetType( NOTIFY_VOTE )
	end

	function PANEL:Paint(w,h)
		local type = self:GetType() or 0
		local color = colors[type]

		draw.RoundedBox( 4, 0, 0, w, h, color)

		draw.DrawText( self:GetText(), "GModNotify", 5, 5, Color(255,255,255))
	end

	function PANEL:SetDieTime(time)
		self.Die = CurTime() + time
	end

	function PANEL:PreRemove()

	end

	function PANEL:Think()
		if self.Die and CurTime() >= self.Die then
			self:AlphaTo( 0, 0.2, 0, function(_,self)
				table.RemoveByValue( notifications, self )
				self:PreRemove()
				Reposition()
				self:Remove()
			end)
		end
	end

	vgui.Register( "NotificationBase", PANEL, "EditablePanel")
end

notifications = {}

function Wrap( text )
	local text = DarkRP.textWrap( text, "GModNotify", 290 )
	local w, h = surface.GetTextSize( text )

	return text, h
end

function Reposition()

	local ypos = ScrH()-5

	for k, notice in ipairs( notifications ) do

		ypos = ypos - notice.tall - 5

		local x, y = notice:GetPos()

		if y ~= ypos then
			notice:MoveTo( ScrW()-305, ypos, 0.3 )
		end

	end

end

function GetInitPos()

	local ypos = ScrH()-5

	for k, notice in ipairs( notifications ) do

		ypos = ypos - notice.tall - 5

	end

	return ypos
end


function CreateBase( type )
	local notify = vgui.Create( "NotificationBase" )
	notify:SetType( colors[type] and type or 0 )
	return notify
end

function AddLegacy( text, type, length )

	assert(isstring(text))
	assert(isnumber(type))
	assert(isnumber(length))
	
	local h
	text, h = Wrap( text:sub(1,1) == "#" and language.GetPhrase(text:sub(2)) or text )
	h = h + 10
	local notice = CreateBase( type )
	notice:SetText(text)
	notice:SizeTo( 300, h, 0.3 )
	notice:SetPos( ScrW() - 305, GetInitPos() )
	notice:SetDieTime( length or 5 )
	notice.tall = h


	table.insert( notifications, notice)

	Reposition()

	return notice

end

