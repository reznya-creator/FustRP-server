
-----------------------------------------------------
--[[---------------------------------------------------------------------------
DarkRP custom shipments and guns
---------------------------------------------------------------------------

This file contains your custom shipments and guns.
This file should also contain shipments and guns from DarkRP that you edited.

Note: If you want to edit a default DarkRP shipment, first disable it in darkrp_config/disabled_defaults.lua
	Once you've done that, copy and paste the shipment to this file and edit it.

The default shipments and guns can be found here:
https://github.com/FPtje/DarkRP/blob/master/gamemode/config/addentities.lua

For examples and explanation please visit this wiki page:
http://wiki.darkrp.com/index.php/DarkRP:CustomShipmentFields
a

Add shipments and guns under the following line:
---------------------------------------------------------------------------]]


DarkRP.createShipment("Ключи от наручников", {
    model = "models/weapons/c_handcuff_keys.mdl",
    entity = "sj_handcuffs_crim_keys",
    price = 20000,
    amount = 4,
    separate = false,
    pricesep = nil,
    noship = false,
    allowed = {TEAM_DARKGUN},
    category = "Оборудование",
})

DarkRP.createShipment("Нож", {
    model = "models/weapons/w_knife_t.mdl",
    entity = "swb_knife",
    price =  6500,
    amount = 4,
    separate = false,
    pricesep = nil,
    noship = false,
    allowed = {TEAM_GUN, TEAM_DARKGUN},
    category = "Оборудование",
})
 
DarkRP.createShipment("AK47", {
    model = "models/weapons/w_rif_ak47.mdl",
    entity = "swb_ak47",
    price = 55000,
    amount = 10,
    separate = false,
    pricesep = nil,
    noship = false,
    allowed = {TEAM_DARKGUN},
    category = "Винтовки"
})

DarkRP.createShipment("SIG SG552", {
    model = "models/weapons/w_rif_sg552.mdl",
    entity = "swb_sg552",
    price = 48000,
    amount = 10,
    separate = false,
    pricesep = nil,
    noship = false,
    allowed = {TEAM_DARKGUN},
    category = "Винтовки"
})

DarkRP.createShipment("SIG SG552", {
    model = "models/weapons/w_snip_sg550.mdl",
    entity = "swb_sg550",
    price = 65000,
    amount = 10,
    separate = false,
    pricesep = nil,
    noship = false,
    allowed = {TEAM_DARKGUN},
    category = "Снайперские винтовки"
})

DarkRP.createShipment("FAMAS F1", {
    model = "models/weapons/w_rif_famas.mdl",
    entity = "swb_famas",
    price = 45000,
    amount = 10,
    separate = false,
    pricesep = nil,
    noship = false,
    allowed = {TEAM_GUN, TEAM_DARKGUN},
    category = "Винтовки"
})

DarkRP.createShipment("AUG", {
    model = "models/weapons/w_rif_aug.mdl",
    entity = "swb_aug",
    price = 49000,
    amount = 10,
    separate = false,
    pricesep = nil,
    noship = false,
    allowed = {TEAM_DARKGUN},
    category = "Винтовки"
})

DarkRP.createShipment("P228", {
    model = "models/weapons/w_pist_p228.mdl",
    entity = "swb_p228",
    price = 7000,
    amount = 5,
    separate = false,
    pricesep = nil,
    noship = false,
   allowed = {TEAM_GUN, TEAM_DARKGUN},
    category = "Пистолеты"
})

DarkRP.createShipment("Glock18", {
    model = "models/weapons/w_pist_glock18.mdl",
    entity = "swb_glock18",
    price = 8000,
    amount = 5,
    separate = false,
    pricesep = nil,
    noship = false,
    allowed = {TEAM_GUN, TEAM_DARKGUN},
    category = "Пистолеты"
})

DarkRP.createShipment("Desert eagle .50", {
    model = "models/weapons/w_pist_deagle.mdl",
    entity = "swb_deagle",
    price = 11000,
    amount = 5,
    separate = false,
    pricesep = nil,
    noship = false,
    allowed = {TEAM_GUN, TEAM_DARKGUN},
    category = "Пистолеты"
})

DarkRP.createShipment("Magnum .357", {
    model = "models/weapons/w_pist_deagle.mdl",
    entity = "swb_357",
    price = 16000,
    amount = 5,
    separate = false,
    pricesep = nil,
    noship = false,
    allowed = {TEAM_DARKGUN},
    category = "Пистолеты"
})

DarkRP.createShipment("M249", {
    model = "models/weapons/w_mach_m249para.mdl",
    entity = "swb_m249",
    price = 170000,
    amount = 10,
    separate = false,
    pricesep = nil,
    noship = false,
    allowed = {TEAM_DARKGUN},
    category = "Винтовки"
})

DarkRP.createShipment("Fiveseven", {
    model = "models/weapons/w_pist_fiveseven.mdl",
    entity = "swb_fiveseven",
    price = 7500,
    amount = 10,
    separate = false,
    pricesep = nil,
    noship = false,
    allowed = {TEAM_GUN, TEAM_DARKGUN},
    category = "Пистолеты"
})

DarkRP.createShipment("MP5", {
    model = "models/weapons/w_smg_mp5.mdl",
    entity = "swb_mp5",
    price = 25000,
    amount = 10,
    separate = false,
    pricesep = nil,
    noship = false,
    allowed = {TEAM_DARKGUN},
    category = "Винтовки"
})

DarkRP.createShipment("M4", {
    model = "models/weapons/w_rif_m4a1.mdl",
    entity = "swb_m4a1",
    price = 55000,
    amount = 10,
    separate = false,
    pricesep = nil,
    noship = false,
    allowed = {TEAM_DARKGUN},
    category = "Винтовки"
})

DarkRP.createShipment("Galil", {
    model = "models/weapons/w_rif_galil.mdl",
    entity = "swb_galil",
    price = 54000,
    amount = 10,
    separate = false,
    pricesep = nil,
    noship = false,
    allowed = {TEAM_GUN, TEAM_DARKGUN},
    category = "Винтовки"
})


DarkRP.createShipment("P90", {
    model = "models/weapons/w_smg_p90.mdl",
    entity = "swb_p90",
    price = 29000,
    amount = 10,
    separate = false,
    pricesep = nil,
    noship = false,
    allowed = {TEAM_DARKGUN},
    category = "Пистолет-пулемёт"
})


DarkRP.createShipment("Mac 10", {
    model = "models/weapons/w_smg_mac10.mdl",
    entity = "swb_mac10",
    price = 29000,
    amount = 10,
    separate = false,
    pricesep = nil,
    noship = false,
    allowed = {TEAM_GUN, TEAM_DARKGUN},
    category = "Пистолет-пулемёт"
})

DarkRP.createShipment("HK MP5", {
    model = "models/weapons/w_smg_mp5.mdl",
    entity = "swb_mp5",
    price = 16500,
    amount = 10,
    separate = false,
    pricesep = nil,
    noship = false,
    allowed = {TEAM_GUN, TEAM_DARKGUN},
    category = "Пистолет-пулемёт"
})

DarkRP.createShipment("HK UMP.45", { 
    model = "models/weapons/w_smg_ump45.mdl",
    entity = "swb_ump",
    price = 16500,
    amount = 10,
    separate = false,
    pricesep = nil,
    noship = false,
    allowed = {TEAM_GUN, TEAM_DARKGUN},
    category = "Пистолет-пулемёт"
})

DarkRP.createShipment("TMP", { 
    model = "models/weapons/w_smg_tmp.mdl",
    entity = "swb_tmp",
    price = 16500,
    amount = 10,
    separate = false,
    pricesep = nil,
    noship = false,
    allowed = {TEAM_DARKGUN},
    category = "Пистолет-пулемёт"
})

DarkRP.createShipment("M3 Super90", {
    model = "models/weapons/w_shot_m3super90.mdl",
    entity = "swb_m3super90",
    price = 45000,
    amount = 10,
    separate = false,
    pricesep = nil,
    noship = false,
    allowed = {TEAM_GUN, TEAM_DARKGUN},
    category = "Дробовики"
})

DarkRP.createShipment("XM1014", {
    model = "models/weapons/w_shot_xm1014.mdl",
    entity = "swb_xm1014",
    price = 50000,
    amount = 10,
    separate = false,
    pricesep = nil,
    noship = false,
    allowed = {TEAM_DARKGUN},
    category = "Дробовики"
})


DarkRP.createShipment("Steyr Scout", {
    model = "models/weapons/w_snip_scout.mdl",
    entity = "swb_scout",
    price = 60000,
    amount = 10,
    separate = false,
    pricesep = nil,
    noship = false,
    allowed = {TEAM_GUN, TEAM_DARKGUN},
    category = "Снайперские винтовки"
})


DarkRP.createShipment("G3SG1", {
    model = "models/weapons/w_snip_g3sg1.mdl",
    entity = "swb_g3sg1",
    price = 75000,
    amount = 10,
    separate = false,
    pricesep = nil,
    noship = false,
    allowed = {TEAM_DARKGUN},
    category = "Снайперские винтовки"
})

DarkRP.createShipment("AWP", {
    model = "models/weapons/w_snip_awp.mdl",
    entity = "swb_awp",
    price = 89000,
    amount = 10,
    separate = false,
    pricesep = nil,
    noship = false,
    allowed = {TEAM_DARKGUN},
    category = "Снайперские винтовки"
})