TEAM_CITIZEN = DarkRP.createJob("Гражданин", {
	color = Color(20, 150, 20, 255),
	model = {
		"models/player/Group01/Female_01.mdl",
		"models/player/Group01/Female_02.mdl",
		"models/player/Group01/Female_03.mdl",
		"models/player/Group01/Female_04.mdl",
		"models/player/Group01/Female_06.mdl",
		"models/player/group01/male_01.mdl",
		"models/player/Group01/Male_02.mdl",
		"models/player/Group01/male_03.mdl",
		"models/player/Group01/Male_04.mdl",
		"models/player/Group01/Male_05.mdl",
		"models/player/Group01/Male_06.mdl",
		"models/player/Group01/Male_07.mdl",
		"models/player/Group01/Male_08.mdl",
		"models/player/Group01/Male_09.mdl",
		"models/player/Group02/male_02.mdl",
		"models/player/Group02/male_04.mdl",
		"models/player/Group02/male_06.mdl",
		"models/player/Group02/male_08.mdl"
	},
	description = [[Гражданин — базовый общественный слой, которым вы можете безпрепятственно стать. 
	У вас нет предопределенной роли в жизни города. 
	Вы можете придумать себе свою собственную профессию и заниматься вашим делом.]],
	weapons = {},
	command = "citizen",
	max = 0,
	category = "Граждане",
	salary = GAMEMODE.Config.normalsalary * 5.45,
	admin = 0,
	vote = false,
	hasLicense = false,
	candemote = false
})

TEAM_PARKYR = DarkRP.createJob("Паркурист", {
	color = Color(20, 0, 20, 255),
	model = {
		"models/player/soldier_stripped.mdl",
	},
	description = [[Паркурист - вы должны исследовать город и не попасться полиции .]],
	weapons = {"climb_swep2"},
	command = "parkyrr",
	max = 0,
	category = "Криминал",
	salary = GAMEMODE.Config.normalsalary * 4.89,
	admin = 0,
	vote = true,
	hasLicense = false,
	candemote = false
})



TEAM_COOK = DarkRP.createJob("Повар", {
    color = Color(226, 114, 123, 255),
    model = "models/player/mossman.mdl",
    description = [[Человек, профессией которого является приготовление пищи.]],
    weapons = { },
    command = "0a4WMUyT9lb7n6namWMasddrpnRfB",
    max = 5,
    salary = GAMEMODE.Config.normalsalary,
    admin = 0,
    vote = false,
    hasLicense = false,
    category = "Бизнес",


})

TEAM_POLICE = DarkRP.createJob("Военный [Рядовой]", {
   color = Color(100, 183, 183, 255),
   model = {
   "models/player/dod_american.mdl",
   "models/player/dod_german.mdl"
   },
   description = [[Вы являетесь военным. В  ваши обязанности входит служба в военных частях и учреждениях 
Вооруженных сил ,исполнение воинского долга. 
Эта служба не просто профессия, а ваше призвание.
Общество и государство целиком надеется на вашу помощь.
Вы обязаны выполнять любые приказы ( Не нарушающие правила сервера, здравый смысл )
Вам запрещено покидать военную базу без приказа Генерала.
Вам разрешается отправляться в патруль по 2 человека.
Вы можете помогать полиции.
Вы подчиняетесь только Генералу. ( Старшему по званию назначенному генералом )]],
	weapons = {"swb_deagle", "stunstick", "door_ram", "weaponchecker", "unarrest_stick", "swb_ak47"},
   command = "voenniy",
   max = 0,
	salary = GAMEMODE.Config.normalsalary * 6,
   admin = 0,
   vote = true,
   hasLicense = false,
   candemote = true,
})
	
--
TEAM_POLICE = DarkRP.createJob("Военный [Генерал]", {
   color = Color(100, 183, 183, 255),
   model = {
   "models/player/combine_soldier.mdl",

   },
   description = [[Вы являетесь непосредственным командующим всей армии.
Вашей основной задачей является защита и удержание территории,
а также людских и материальных ресурсов.
Ваша задача командывать целой армией.
Вы обязаны командывать другими "Военными".
Вы можете повысить любого военного в звании ( Не выше "Полковника" ).
Вы можете помогать полиции в поиске военных преступников. )]],
	weapons = {"swb_deagle", "swb_awp", "stunstick", "door_ram", "weaponchecker", "unarrest_stick", "swb_ak47"},
   command = "voenniy1",
   max = 1,
	salary = GAMEMODE.Config.normalsalary * 7,
   admin = 0,
   vote = true,
   hasLicense = false,
   candemote = true,
})
	

--

TEAM_DRUG = DarkRP.createJob("Наркобарон", {
   color = Color(183, 183, 183, 255),
   model = {"models/player/soldier_stripped.mdl"},
   description = [[Вы наркобарон и торгуете наркотиками]],
   weapons = {},
   command = "narko",
   max = 0,
   salary = 90,
   admin = 0,
   vote = false,
   hasLicense = false,
   candemote = true,
})

----
TEAM_RADIO = DarkRP.createJob("Радиоведущий", {
   color = Color(183, 50, 183, 255),
   model = {"models/player/p2_chell.mdl"},
   description = [[Вы радиоведущий и ваша обязанность оповещать город обеспечивать о ....]],
   weapons = {},
   command = "radio2",
   max = 1,
   salary = 310,
   admin = 0,
   vote = true,
   hasLicense = false,
   candemote = true,
})
	
----
	
TEAM_FARM = DarkRP.createJob("Фермер", {
    color = Color(35, 83, 13, 255),
    model = "models/player/eli.mdl",
    description = [[Крестьянин-предприниматель, владеет землёй или арендует её, и занимается на ней сельским хозяйством.]],
    weapons = { },
    command = "0a4WMUyT9WMasddrpnRfB",
    max = 5,
    salary = GAMEMODE.Config.normalsalary,
    admin = 0,
    vote = false,
    hasLicense = false,
    category = "Бизнес",
})

TEAM_POLICE = DarkRP.createJob("Полиция", {
	color = Color(25, 25, 170, 255),
	model = {
	"models/player/police_fem.mdl",
	"models/player/combine_super_soldier.mdl",
	"models/player/police.mdl",
	"models/player/police_fem.mdl"
	},
	description = [[Полицейский является защитником каждого гражданина, который живет в городе.
У вас есть власть, вы можете арестовать преступников и защитить невинных людей.
Бейте их StunStick'ом, если преступники ослушались вас.
Battering Ram (Таран) может выломать дверь любого игрока, но только с ордером на обыск.
Таран также может выбивать замороженные пропы игрока.]],
	weapons = {"sj_handcuffs", "arrest_stick", "swb_usp", "stunstick", "door_ram", "weaponchecker", "unarrest_stick"},
	command = "cp",
	max = 10,
	category = "Правопорядок",
	ammo = {
		["pistol"] = 100,
	},
	salary = GAMEMODE.Config.normalsalary * 10.45,
	admin = 0,
	vote = true,
	hasLicense = true,
	PlayerLoadout = function(ply) ply:SetArmor(50) end,
	hobo = true
})

TEAM_CHIEF = DarkRP.createJob("Шеф Полиции", {
	color = Color(20, 20, 255, 255),
		model = {
	"models/player/combine_soldier.mdl",
	},
	description = [[Шеф Полиции является главным среди полицейских.
Координируйте действия сотрудников Полиции, наводя порядок в городе.
Бейте непослушных STUNSTICK'ом.
Battering Ram (Таран) может выломать дверь любого игрока, но только с ордером на обыск.
Таран также может выбивать замороженные пропы игрока.]],
	weapons = {"sj_handcuffs", "arrest_stick", "swb_deagle", "stunstick", "door_ram", "weaponchecker", "unarrest_stick"},
	command = "chief",
	category = "Правопорядок",
	max = 1,
	salary = GAMEMODE.Config.normalsalary * 3.67,
	admin = 0,
	ammo = {
		["pistol"] = 100,
	},
	vote = false,
	hasLicense = true,
	chief = true,
	NeedToChangeFrom = TEAM_POLICE,
	PlayerLoadout = function(ply) ply:SetArmor(100) end,
	hobo = true
})

TEAM_FBI = DarkRP.createJob("FBI", {
	color = Color(0, 25, 63, 255),
	model = {
		"models/player/gasmask.mdl",
		"models/player/combine_soldier.mdl",
		"models/player/barney.mdl"
	},
	description = [[Вы Федеральное бюро расследований! 
Вы имеете полномочия расследовать нарушения 
федерального законодательства города и обеспечивать 
безопасность государства, страны, нации и мэра.]],
	weapons = {"sj_handcuffs", "arrest_stick", "swb_deagle", "stunstick", "door_ram", "weaponchecker","unarrest_stick"},
	command = "fbi",
	max = 6,
	salary = 500,
	category = "Правопорядок",
	ammo = {
		["pistol"] = 100,
	},
	admin = 0,
	vote = true,
	hasLicense = true,
	NeedToChangeFrom = TEAM_POLICE,
	PlayerLoadout = function(ply) ply:SetArmor(75) end,
	hobo = true
})

TEAM_SWAT = DarkRP.createJob("SWAT", {
    color = Color(25, 25, 170, 255),
    model = {"models/player/gasmask.mdl",
	         "models/player/swat.mdl"},
    description = [[Вы являетесь опытным бойцом элитного подразделения вы обязаны служить честью и своей жизнью Меру
и всему городу в ваших силах поддерживать порядок в городе не забывайте верно служить вашему лидеру и
в благодарность город будет знать своих героев.]],
    weapons = {"sj_handcuffs", "stunstick", "door_ram", "arrest_stick", "weaponchecker", "swb_usp", "swb_m4a1"},
    command = "swat",
    max = 10,
	category = "Правопорядок",
	ammo = {
		["pistol"] = 100,
		["ar2"] = 150,
	},
    salary = 700,
    admin = 0,
    vote = true,
    hasLicense = true,
    NeedToChangeFrom = TEAM_POLICE,
	PlayerLoadout = function(ply) ply:SetArmor(100) end,
	hobo = true
})

TEAM_SWATM = DarkRP.createJob("SWAT Медик", {
    color = Color(25, 25, 170, 255),
    model = {"models/player/gasmask.mdl",
	         "models/player/swat.mdl"},
    description = [[Вы являетесь опытным бойцом элитного подразделения вы обязаны служить честью и своей жизнью Меру
и всему городу в ваших силах поддерживать порядок в городе не забывайте верно служить вашему лидеру и
в благодарность город будет знать своих героев.]],
    weapons = {"weapon_medkit", "sj_handcuffs", "stunstick", "door_ram", "weaponchecker", "swb_usp", "swb_m3super90", "arrest_stick"},
    command = "swatm",
    max = 3,
	category = "Правопорядок",
	ammo = {
		["pistol"] = 100,
		["buckshot"] = 150,
	},
    salary = 750,
    admin = 0,
    vote = true,
    hasLicense = true,
    NeedToChangeFrom = TEAM_SWAT,
	PlayerLoadout = function(ply) ply:SetArmor(100) end,
	hobo = true
})

TEAM_SWATH = DarkRP.createJob("SWAT Поддержка", {
    color = Color(25, 25, 170, 255),
    model = {"models/player/gasmask.mdl",
	         "models/player/swat.mdl"},
    description = [[Вы являетесь опытным бойцом элитного подразделения вы обязаны служить честью и своей жизнью Меру
и всему городу в ваших силах поддерживать порядок в городе не забывайте верно служить вашему лидеру и
в благодарность город будет знать своих героев.]],
    weapons = {"sj_handcuffs", "stunstick", "door_ram", "weaponchecker", "swb_usp", "swb_m4a1", "arrest_stick"},
    command = "swath",
    max = 5,
	category = "Вип работы",
	ammo = {
		["pistol"] = 100,
		["ar2"] = 500,
	},
    salary = 700,
    admin = 0,
    vote = true,
    hasLicense = true,
    NeedToChangeFrom = TEAM_SWAT,
	PlayerLoadout = function(ply) ply:SetArmor(100) end,
	customCheck = function(ply) return ply:IsDonate() end,
	hobo = true
})

TEAM_SWATL = DarkRP.createJob("Лидер SWAT", {
	color = Color(25, 25, 170, 255),
	model = {"models/player/riot.mdl"},
	description = [[Вы обученый и храбрый человек ваша задача поддерживать дисциплину в рядах S.W.A.T. 
только вы можете взять всё в свои руки и только от вас будет зависить успех операции.]],
	weapons = {"sj_handcuffs", "stunstick", "arrest_stick", "door_ram", "weaponchecker", "swb_famas", "swb_usp"},
	command = "swatl",
	max = 1,
	category = "Правопорядок",
	salary = 800,
	admin = 0,
	ammo = {
		["pistol"] = 100,
		["ar2"] = 500,
	},
	vote = true,
	hasLicense = true,
	NeedToChangeFrom = TEAM_SWAT,
	PlayerLoadout = function(ply) ply:SetArmor(100) end,
	hobo = true
})

TEAM_SWATS = DarkRP.createJob("SWAT Снайпер", {
	color = Color(25, 25, 170, 255),
    model = {"models/player/gasmask.mdl",
	         "models/player/swat.mdl"},
	description = [[Вы являетесь специальным обученым бойцом долгие годы вас обучали снайперскому ремеслу,
ваша обязаность подчиняться Меру и вашему Лидеру,
в ваших провосудие и только ты можешь решить любую проблемму всего лишь одним движением пальца на курке]],
	weapons = {"sj_handcuffs", "stunstick", "door_ram", "weaponchecker", "swb_scout", "swb_usp", "arrest_stick"},
	command = "swats",
	max = 2,
	category = "Вип работы",
	ammo = {
		["pistol"] = 100,
		["SniperPenetratedRound"] = 500,
	},
	salary = 700,
	admin = 0,
	vote = false,
	hasLicense = true,
	NeedToChangeFrom = TEAM_SWAT,
	customCheck = function(ply) return ply:IsDonate() end,
	hobo = true
})


TEAM_MAYOR = DarkRP.createJob("Мэр", {
	color = Color(150, 20, 20, 255),
	model = { 
	"models/player/breen.mdl",
	"models/player/mossman_arctic.mdl"
	},
	description = [[Мэр города создает законы, чтобы улучшить жизнь людей в городе.
Если вы мэр, то вы можете создавать или принимать ордера на обыск игроков.
Во время Комендантского часа все люди должны быть в своих домах,
а полицейские должны патрулировать город.]],
	weapons = {},
	command = "mayor",
	max = 1,
	category = "Правопорядок",
	salary = GAMEMODE.Config.normalsalary * 25.89,
	admin = 0,
	vote = true,
	hasLicense = true,
	mayor = true,
	PlayerDeath = function(ply, weapon, killer)
                if( ply:Team() == TEAM_MAYOR ) then
                        ply:changeTeam( GAMEMODE.DefaultTeam, true )
                        for k,v in pairs( player.GetAll() ) do
                                v:PrintMessage( HUD_PRINTCENTER, "Мэр был убит!" )
                        end
                end
        end
})

TEAM_GANG = DarkRP.createJob("Мафия", {
	color = Color(75, 75, 75, 255),
	model = {
				"models/player/group03/female_01.mdl",
				"models/player/group03/female_02.mdl",
				"models/player/group03/female_03.mdl",
				"models/player/group03/female_04.mdl",
				"models/player/group03/female_06.mdl",
				"models/player/group03/male_01.mdl",
				"models/player/group03/male_02.mdl",
				"models/player/group03/male_03.mdl",
				"models/player/group03/male_04.mdl",
				"models/player/group03/male_05.mdl",
				"models/player/group03/male_06.mdl",
				"models/player/group03/male_07.mdl",
				"models/player/group03/male_08.mdl",
				"models/player/group03/male_09.mdl"
			},
	description = [[Низшая каста в криминальном мире.
		Мафия обычно работает на главу мафии, который заправляет всеми делами.
		Воруйте, убивайте на заказ и следуйте агенде от босса, или вы, возможно, будете наказаны.]],
	weapons = {},
	command = "gangster",
	category = "Криминал",
	max = 16,
	salary = GAMEMODE.Config.normalsalary * 3.89 ,
	admin = 0,
	vote = false,
})

TEAM_HACK = DarkRP.createJob("Взломщик", {
    color = Color(0, 0, 0, 255),
    model = "models/player/arctic.mdl",
    description = [[Взламывает замки.
	Может вступать в банды.]],
    weapons = {"lockpick", "keypad_cracker"},
    command = "hack",
	category = "Криминал",
    max = 6,
    salary = GAMEMODE.Config.normalsalary * 3.89,
    admin = 0,
    vote = false,
    hasLicense = false,
})

TEAM_HARDHACK = DarkRP.createJob("Взломщик (VIP)", {
    color = Color(0, 0, 0, 255),
    model = "models/player/arctic.mdl",
    description = [[Взламывает замки.
	Может вступать в банды. Может
	взламывать банкоматы.]],
    weapons = {"lockpick", "keypad_cracker"},
    command = "hardhack",
	category = "Криминал",
    max = 6,
    salary = GAMEMODE.Config.normalsalary * 3.89,
    admin = 0,
    vote = false,
    hasLicense = false,
	customCheck = function(ply) return ply:IsDonate() end,
})

TEAM_GANGVIP = DarkRP.createJob("Мафия (VIP)", {
	color = Color(75, 75, 75, 255),
	model = {
		"models/player/Group01/Female_01.mdl",
		"models/player/Group01/Female_02.mdl",
		"models/player/Group01/Female_03.mdl",
		"models/player/Group01/Female_04.mdl",
		"models/player/Group01/Female_06.mdl",
		"models/player/group01/male_01.mdl",
		"models/player/Group01/Male_02.mdl",
		"models/player/Group01/male_03.mdl",
		"models/player/Group01/Male_04.mdl",
		"models/player/Group01/Male_05.mdl",
		"models/player/Group01/Male_06.mdl",
		"models/player/Group01/Male_07.mdl",
		"models/player/Group01/Male_08.mdl",
		"models/player/Group01/Male_09.mdl"
	},
	description = [[Низшая каста в криминальном мире.
		Бандит обычно работает на главу банды, который заправляет всеми делами.
		Воруйте, убивайте на заказ и следуйте агенде от босса, или вы, возможно, будете наказаны.]],
	weapons = {"swb_tmp", "weapon_eginventory_checker", "moneychecker"},
	command = "gangstervip",
	category = "Вип работы",
	max = 6,
	salary = GAMEMODE.Config.normalsalary * 3.89,
	admin = 0,
	vote = false,
	customCheck = function(ply) return ply:IsDonate() end,
})
   

TEAM_THIEFF = DarkRP.createJob("Вор", {
	color = Color(70, 68, 81, 255),
	model = {
			"models/player/Group01/female_02.mdl",
			"models/player/Group01/female_04.mdl",
			"models/player/Group01/female_01.mdl",
			"models/player/Group01/male_03.mdl",
			"models/player/Group01/male_05.mdl",
			"models/player/Group01/male_07.mdl",
			"models/player/Group02/male_04.mdl",
			"models/player/Group02/male_06.mdl",
			"models/player/Group02/male_02.mdl",
			"models/player/Group02/male_08.mdl"
	},
	description = [[Вы очень умелый медвежатник с детства испытывали влечение к этому ремеслу,
	теперь эта работа способ прокормить себя вы можите вступить в любую банду и нажить на всём этом большие деньги,
	хватай в руку монтировку и отмычки и в путь.]],
	weapons = {"lockpick", "keypad_cracker"},
	command = "thieff",
	category = "Криминал",
	max = 4,
	salary = 50,
	admin = 0,
	vote = false,
	hasLicense = false,
})
----------
TEAM_THIEFF = DarkRP.createJob("Вор (VIP)", {
	color = Color(70, 1, 50, 255),
	model = {

			"models/player/skeleton.mdl"
	},
	description = [[Ваша задача стать миллироенером.. У  вас есть возможность грабить люде! Действуй!]],
	weapons = {"lockpick", "keypad_cracker", "grabej"},
	command = "vorvip",
	category = "Криминал",
	max = 4,
	salary = 0,
	admin = 0,
	vote = false,
	hasLicense = false,
		customCheck = function(ply)
    return ply:GetUserGroup() == "vip" or ply:IsAdmin() 
    end
})
----------

TEAM_KILL = DarkRP.createJob("Наемник (VIP)", {
    color = Color(25, 25, 25, 255),
    model = "models/player/phoenix.mdl",
    description = [[Вас могут нанять в банду или
	делать заказы на убийство.]],
    weapons = {"swb_tmp"},
    command = "kill",
	category = "Вип работы",
    max = 1,
    salary = GAMEMODE.Config.normalsalary * 3.45,
    admin = 0,
    vote = false,
    hasLicense = false,
	customCheck = function(ply) return ply:IsDonate() end,
})

TEAM_GUN = DarkRP.createJob("Продавец оружия", {
	color = Color(255, 140, 0, 255),
	model = {
			"models/player/monk.mdl",
			"models/player/alyx.mdl"
	},
	description = [[Продавец оружия является единственным человеком, который
может легально продавать оружие другим людям.
Удостовертесь в том, что вы не продаёте 
нелегальные виды вооружения в открытую,
иначе вас могут арестовать!]],
	weapons = {},
	command = "gundealer",
	category = "Бизнес",
	max = 4,
	salary = GAMEMODE.Config.normalsalary * 5.89,
	admin = 0,
	vote = false,
})

TEAM_BANK = DarkRP.createJob("Банкир", {
	color = Color(79, 121, 66, 255),
	model = {
		"models/player/hostage/hostage_01.mdl",
		"models/player/hostage/hostage_02.mdl",
		"models/player/hostage/hostage_03.mdl",
		"models/player/hostage/hostage_04.mdl",
		"models/player/magnusson.mdl"
	},
	description = [[Банкир может построить свой банк и принимать вклады других людей.
		Учтите, что вам придётся постоянно укреплять защиту своего бизнеса, иначе вас могут
		ограбить и ваш банк потеряет доверие игроков.]],
	weapons = {},
	command = "banker",
	category = "Бизнес",
	max = 2,
	salary = GAMEMODE.Config.normalsalary * 4.89,
	admin = 0,
	vote = false
})

TEAM_DARKGUN = DarkRP.createJob("Контробандист (VIP)", {
    color = Color(25, 25, 25, 255),
    model = "models/player/monk.mdl",
    description = [[Продает не легальное оружие.
	Может вступать в банды.]],
    weapons = {},
    command = "darkgundealer",
	category = "Вип работы",
    max = 4,
    salary = GAMEMODE.Config.normalsalary * 4.89,
    admin = 0,
    vote = false,
    hasLicense = false,
	customCheck = function(ply) return ply:IsDonate() end,
})

TEAM_IZNAS = DarkRP.createJob("Насильник", {
    color = Color(235, 12, 168, 255),
    model = "models/player/mossman_arctic.mdl",
    description = [[Заманивает людей в укромный уголок и насилует.]],
   weapons = {"weapon_rape"},
    command = "iznas",
	category = "Вип работы",
    max = 1,
    salary = GAMEMODE.Config.normalsalary * 4.89,
    admin = 0,
    vote = false,
    hasLicense = false,
	customCheck = function(ply) return ply:IsDonate() end,
})

TEAM_SECURITY = DarkRP.createJob("Охранник", {
	color = Color(0, 140, 255, 255),
	model = "models/player/odessa.mdl",
	description = [[Нанимайтесь в охрану магазина, банка или телохранителем.
		Вы должны защищать заведение от хулиганов и мелких воров.
		При сложной ситуации вызывайте полицию.
		По умолчанию вам даётся Stunstick,
		так что не рискуйте особо, действуйте осторожно.]],
	weapons = {"stunstick"},
	command = "security",
	category = "Другие",
	max = 6,
	salary = GAMEMODE.Config.normalsalary * 4.89,
	admin = 0,
	vote = false,
})

TEAM_SECURITYVIP = DarkRP.createJob("Охранник(VIP)", {
	color = Color(0, 140, 255, 255),
	model = "models/player/leet.mdl",
	description = [[Нанимайтесь в охрану магазина, банка или телохранителем.
		Вы должны защищать заведение от хулиганов и мелких воров.
		При сложной ситуации вызывайте полицию.
		По умолчанию вам даётся Stunstick,
		так что не рискуйте особо, действуйте осторожно.]],
	weapons = {"stunstick", "swb_tmp"},
	command = "securityvip",
	category = "Вип работы",
	max = 4,
	salary = GAMEMODE.Config.normalsalary * 4.89,
	admin = 0,
	vote = false,
	customCheck = function(ply) return ply:IsDonate() end,
})

TEAM_MEDIC = DarkRP.createJob("Медик", {
	color = Color(47, 79, 79, 255),
	model = {
	-- Мужчины
		"models/player/Group03m/male_01.mdl",
		"models/player/Group03m/male_02.mdl",
		"models/player/Group03m/male_03.mdl",
		"models/player/Group03m/male_04.mdl",
		"models/player/Group03m/male_05.mdl",
		"models/player/Group03m/male_06.mdl",
		"models/player/Group03m/male_07.mdl",
		"models/player/Group03m/male_08.mdl",
		"models/player/Group03m/male_09.mdl",
	-- Женщины	
		"models/player/Group03m/female_01.mdl",
		"models/player/Group03m/female_02.mdl",
		"models/player/Group03m/female_03.mdl",
		"models/player/Group03m/female_04.mdl",
		"models/player/Group03m/female_05.mdl",
		"models/player/Group03m/female_06.mdl"
	},
	description = [[Доктор способен исцелить игроков с помощью своих медицинских знаний.
		Используйте аптечку чтобы лечить себя или других,
		либо продавайте аптечки покупателям.]],
	weapons = {"med_kit"},
	command = "medic",
	category = "Городские службы",
	max = 4,
	salary = GAMEMODE.Config.normalsalary * 5.89,
	admin = 0,
	vote = false,
	medic = true,
})

TEAM_HOBO = DarkRP.createJob("Бездомный", {
	color = Color(80, 45, 0, 255),
	model = "models/player/corpse1.mdl",
	description = [[Бездомный находится в самом низу общественного строя. Над ним все смеются.
	У вас нет дома.
	Вы вынуждены просить еду и деньги.
	Ройтесь в мусорных бакав для того чтобы найти полезные вам вещи.
	Постройте дом из дощечек и мусора, чтобы укрыться от холода.
	Вы можете поставить ведро и написать на нём просьбу, чтобы вам подавали денег.
	Проявите фантазию, устройте цирковое представление, спойте. Таким образом вы можете получить больше денег.]],
	weapons = {"weapon_bugbait"},
	command = "hobo",
	category = "Другие",
	max = 0,
	salary = 0,
	admin = 0,
	vote = false,
	candemote = false,
	hobo = true
})

TEAM_DOGE = DarkRP.createJob("Собака", {
	color = Color(0, 100, 255, 255),
	model = "models/doge_player/doge_player.mdl",
	description = [[Ну.... Гав гав..]],
	weapons = {},
	command = "doge",
	category = "Бизнес",
	max = 5,
	salary = GAMEMODE.Config.normalsalary * 1.5,
	admin = 0,
	vote = false,
	-- PlayerLoadout = function(ply) ply:StripWeapons() ply:Give("weapon_fists") return false end,
	PlayerSpawn = function(ply) ply:StripWeapons() ply:Give("weapon_fists") end,
	-- PlayerCanPickupWeapon = function (ply) return false end
})



TEAM_BISNES = DarkRP.createJob("Бизнесмен", {
	color = Color(0, 100, 255, 255),
	model = "models/player/magnusson.mdl",
	description = [[Самая креативная профессия в его силах 
	сделать из ничего что то что приносит ему деньги например
	( вы можите скупить все двери в доме и продавать квартирки )
	всё зависит лишь от вас и от ваших вооброжений.]],
	weapons = {},
	command = "bisnes",
	category = "Бизнес",
	max = 2,
	salary = GAMEMODE.Config.normalsalary * 5.89,
	admin = 0,
	vote = false
})
TEAM_GLCRIME = DarkRP.createJob("Глава мафии", {
	color = Color(0, 100, 255, 255),
	model = "models/player/gman_high.mdl",
	description = [[Вы ведущий участник всего
	приступного мира! Удачи ! ]],
	weapons = {"unarrest_stick", "lockpick"},
	command = "glavamafiii",
	category = "Криминал",
	max = 1,
	salary = GAMEMODE.Config.normalsalary * 6.89,
	admin = 0,
	vote = false
})


TEAM_NAIM = DarkRP.createJob("Наёмник", {
	color = Color(228, 64, 64, 255),
	model = "models/player/phoenix.mdl",
	description = [[Вы работаете только за деньги не важно на кого вы сделаете всё что угодно
	для вашего заказчика вы можете похитить мера ,
	сломать за деньги чей то дом украть вещи для заказчика
	удачи в нелёгком труде.]],
	weapons = {}, 
	command = "naim",
	category = "Криминал",
	max = 1,
	salary = GAMEMODE.Config.normalsalary * 3.89,
	admin = 0,
	vote = false,
})

TEAM_MODERATOR = DarkRP.createJob("Модератор", {
   color = Color(5, 43, 232, 255),
   model = {"models/player/Barney.mdl"},
   description = [[NON RP]],
   weapons = {"weapon_keypadchecker"},
   command = "moderator",
   max = 0,
   salary = 150,
   admin = 0,
   vote = false,
   hasLicense = false,
   candemote = false,
   customCheck = function(ply) return ply:IsAdmin() end,
	hobo = true
})


TEAM_ADMIN = DarkRP.createJob("Администратор", {
   color = Color(219, 0, 0, 255),
   model = {"models/player/charple.mdl"},
   description = [[NON RP]],
   weapons = {"weapon_keypadchecker"},
   command = "admin",
   max = 0,
   salary = 300,
   admin = 0,
   vote = false,
   hasLicense = false,
   PlayerLoadout = function(ply) ply:SetHealth(500) end,
   candemote = false,
	customCheck = function(ply)
    return ply:GetUserGroup() == "Admin" or ply:IsAdmin() 
    end
})

TEAM_ZOMBIE = DarkRP.createJob("Зомби (VIP) ", {
   color = Color(219, 50, 10, 255),
   model = {
   "models/player/zombie_fast.mdl",
   "models/player/zombie_classic.mdl",
   "models/player/zombie_soldier.mdl"
   },
   description = [[Мозги.... Кушать мозги! Буэээ]],
   command = "zombi",
   max = 0,
   salary = 0,
   admin = 0,
   vote = true,
   hasLicense = false,
   candemote = false,
   	PlayerSpawn = function(ply) ply:StripWeapons() ply:Give("weapon_fists") end,
	  PlayerLoadout = function(ply) ply:SetRunSpeed(500) end,
	customCheck = function(ply)
    return ply:GetUserGroup() == "vip" or ply:IsAdmin() 
    end
})





--[[
PlayerLoadout = function(ply) ply:SetArmor(100) end, (дает броню)
]]
--[[---------------------------------------------------------------------------
Define which team joining players spawn into and what team you change to if demoted
---------------------------------------------------------------------------]]
GAMEMODE.DefaultTeam = TEAM_CITIZEN


--[[---------------------------------------------------------------------------
Define which teams belong to civil protection
Civil protection can set warrants, make people wanted and do some other police related things
---------------------------------------------------------------------------]]
GAMEMODE.CivilProtection = {
	[TEAM_POLICE] = true,
	[TEAM_CHIEF] = true,
	[TEAM_MAYOR] = true,
	[TEAM_SWAT] = true,
	[TEAM_SWATL] = true,
	[TEAM_SWATS] = true,
	[TEAM_SWATH] = true,
	[TEAM_SWATM] = true,
	[TEAM_FBI] = true
}

--[[---------------------------------------------------------------------------
Jobs that are hitmen (enables the hitman menu)
---------------------------------------------------------------------------]]
DarkRP.addHitmanTeam(TEAM_NAIM)
DarkRP.addHitmanTeam(TEAM_KILL)
