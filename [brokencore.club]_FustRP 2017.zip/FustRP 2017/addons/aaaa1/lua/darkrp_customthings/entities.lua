--[[---------------------------------------------------------------------------
DarkRP custom entities
---------------------------------------------------------------------------

This file contains your custom entities.
This file should also contain entities from DarkRP that you edited.

Note: If you want to edit a default DarkRP entity, first disable it in darkrp_config/disabled_defaults.lua
	Once you've done that, copy and paste the entity to this file and edit it.

The default entities can be found here:
https://github.com/FPtje/DarkRP/blob/master/gamemode/config/addentities.lua#L111

For examples and explanation please visit this wiki page:
http://wiki.darkrp.com/index.php/DarkRP:CustomEntityFields

Add entities under the following line:
---------------------------------------------------------------------------]]
DarkRP.createEntity("Микрофон", {
    ent = "rp_radio_microphone",
    model = "models/props_junk/Shovel01a.mdl",
    price = 6000,
    max = 1,
    cmd = "microfone",
    allowed = { TEAM_RADIO },
    category = "Оборудование",
})

DarkRP.createEntity("Плита", {
    ent = "hfm_stove",
    model = "models/ent/stove.mdl",
    price = 1500,
    max = 1,
    cmd = "buystove",
    allowed = { TEAM_COOK },
    category = "Оборудование",
})

DarkRP.createEntity("Киоск", {
    ent = "hfm_kiosk",
    model = "models/props_c17/display_cooler01a.mdl",
    price = 4000,
    max = 5,
    cmd = "buykiosk",
    allowed = { TEAM_COOK, TEAM_FARM },
    category = "Оборудование",
})


DarkRP.createEntity( "Принтер", { 
   ent = "Derma_Printer", -- printer entity
   model = "models/phoenixprinters/dermaprinter.mdl", --menu model 
   price = 7000, --adjust price
   max = 3, --custom number
   cmd = "sddDKsdjkkJKfk23kf", --command
   category = "Принтеры", -- catagory
})

--[[DarkRP.createEntity("Бумбокс", {
    ent = "3d_boombox",
    model = "models/boomboxv2/boomboxv2.mdl",
    price = 5000,
    max = 1,
    cmd = "buyboombox",
    category = "VIP+",
    customCheck = function(ply)
        return ply:IsDonate()
    end
})]]-- lag shit

DarkRP.createEntity("Vape Nation [VIP+]", {
    ent = "weapon_vape",
    model = "models/swamponions/vape.mdl",
    price = 5000,
    max = 3,
    cmd = "buyvape",
    category = "VIP+",
    customCheck = function(ply)
        return ply:IsDonate()
    end
})

DarkRP.createEntity("Броня[VIP+]", {
    ent = "item_battery",
    model = "models/Items/battery.mdl",
    price = 2000,
    category = "VIP+",
    max = 2,
    cmd = "9340982093420BRO",
    customCheck = function(ply)
        return ply:IsDonate()
    end
})



DarkRP.createEntity("Граната[VIP+]", {
    ent = "weapon_frag",
    model = "models/Items/grenadeAmmo.mdl",
    price = 300000,
    category = "VIP+",
    max = 5,
    cmd = "granata5",
    customCheck = function(ply)
        return ply:IsDonate()
    end
})
DarkRP.createEntity("Аптечка [VIP+]", {
    ent = "item_healthvial",
    model = "models/Items/HealthKit.mdl",
    price = 1000,
    category = "VIP+",
    max = 2,
    cmd = "9340982093420HIL",
    customCheck = function(ply)
        return ply:IsDonate()
    end
})
-------------dildo

DarkRP.createEntity("Хил станция", {
	desc = [[Портативная лечебница. Вмещает в себе 1000 единиц энергии, но восстанавливает до 100. Абсолютно легальна.]],
	ent = "health_station",
	model = "models/props_c17/consolebox03a.mdl",
	price = 100000,
	max = 2,
	cmd = "buyhealthcharg2er",
	getMax = function(ply) return ply:IsDonate() and 2 or 1 end,
	category = "Оборудование",
})

DarkRP.createEntity("Бронестанция", {
	desc = [[Портативная наращивалка брони. Вмещает в себе 1000 единиц энергии, но восстанавливает до 100. Абсолютно легальна.]],
	ent = "armour_station",
	model = "models/props_c17/consolebox03a.mdl",
	price = 100000,
	max = 2,
	cmd = "buyarmorcharger",
	getMax = function(ply) return ply:IsDonate() and 2 or 1 end,
	category = "Оборудование",
	
})



-----------------
DarkRP.createEntity("Радио", {
	desc = [[Портативная наращивалка брони. Вмещает в себе 1000 единиц энергии, но восстанавливает до 100. Абсолютно легальна.]],
	ent = "rp_radio",
	model = "models/props_lab/citizenradio.mdl",
	price = 15000,
	max = 1,
	cmd = "radio1",
	category = "Оборудование",
})

-----------------
DarkRP.createEntity("Алкоголь", {
	ent = "durgz_alcohol",
	model = "models/drug_mod/alcohol_can.mdl",
	price = 300,
	max = 3,
	cmd = "buyalcohol",
	allowed = {TEAM_DRUG},
})

DarkRP.createEntity("Аспирин", {
	ent = "durgz_aspirin",
	model = "models/jaanus/aspbtl.mdl",
	price = 450,
	max = 5,
	cmd = "buyaspirin",
	allowed = {TEAM_DRUG},
})


DarkRP.createEntity("Кокаин", {
	ent = "durgz_cocaine",
	model = "models/cocn.mdl",
	price = 640,
	max = 3,
	cmd = "buyacocaine",
	allowed = {TEAM_DRUG},
})

DarkRP.createEntity("Героин", {
	ent = "durgz_heroine",
	model = "models/katharsmodels/syringe_out/syringe_out.mdl",
	price = 640,
	max = 5,
	cmd = "buyheroine",
	allowed = {TEAM_DRUG},
})

DarkRP.createEntity("ЛСД", {
	ent = "durgz_lsd",
	model = "models/smile/smile.mdl",
	price = 430,
	max = 5,
	cmd = "buylsd",
	allowed = {TEAM_DRUG},
})

DarkRP.createEntity("Метформин", {
	ent = "durgz_meth",
	model = "models/katharsmodels/contraband/metasync/blue_sky.mdl",
	price = 500,
	max = 5,
	cmd = "buymush",
	allowed = {TEAM_DRUG},
})

DarkRP.createEntity("Гриб", {
	ent = "durgz_mushroom",
	model = "models/ipha/mushroom_small.mdl",
	price = 640,
	max = 3,
	cmd = "buymushroom",
	allowed = {TEAM_DRUG},
})

DarkRP.createEntity("Водичка", {
	ent = "durgz_water",
	model = "models/drug_mod/the_bottle_of_water.mdl",
	price = 80,
	max = 10,
	cmd = "buywater",
})