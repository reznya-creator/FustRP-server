AddDoorGroup("Полицейский участок", TEAM_CHIEF, TEAM_POLICE, TEAM_MAYOR, TEAM_FBI, TEAM_SWAT, TEAM_SWATL)
AddDoorGroup("Мэрия", TEAM_MAYOR, TEAM_CHIEF, TEAM_FBI, TEAM_SWATL)
AddDoorGroup("Тюремная камера", TEAM_EMPTY)