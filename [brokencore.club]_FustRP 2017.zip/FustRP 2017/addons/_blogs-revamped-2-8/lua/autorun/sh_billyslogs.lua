local Version = "B8"
local Licensee = "76561198113240446"

MsgC("\n\n")
for i,v in pairs(string.ToTable(string.rep("#",59))) do
	MsgC(Color(i * 4.32203389831,255,0),v)
end
MsgC("\n\n")
for i,v in pairs({"  _     _                     "," | |   | |                    "," | |__ | |     ___   __ _ ___ "," | '_ \\| |    / _ \\ / _` / __|"," | |_) | |___| (_) | (_| \\__ \\"," |_.__/|______\\___/ \\__, |___/","                     __/ |    ","                    |___/     ","                    "}) do
	MsgC(string.rep(" ",12))
	for i,_v in pairs(string.ToTable(v)) do
		MsgC(Color(i * 8.5,255,0),_v)
	end
	MsgC("\n")
end
MsgC("\n" .. string.rep(" ",13))
local spaces = ""
for i=1,math.floor(15 - (#Version / 2)),1 do
	spaces = spaces .. " "
end
for i,v in pairs(string.ToTable(spaces .. Version)) do
	MsgC(Color(i * 8.5,255,0),v)
end
MsgC("\n\n" .. string.rep(" ",13))
local spaces = ""
for i=1,math.floor(15 - (#("Licensed to " .. Licensee) / 2)),1 do
	spaces = spaces .. " "
end
for i,v in pairs(string.ToTable(spaces .. "Licensed to " .. Licensee)) do
	MsgC(Color(i * 8.5,255,0),v)
end
MsgC("\n\n\n")
for i,v in pairs(string.ToTable(string.rep("#",59))) do
	MsgC(Color(i * 4.32203389831,255,0),v)
end
MsgC("\n\n")

local langs = file.Find("blogs/lang/*","LUA")
for _,lang in pairs(langs) do
	AddCSLuaFile("blogs/lang/" .. lang)
end
