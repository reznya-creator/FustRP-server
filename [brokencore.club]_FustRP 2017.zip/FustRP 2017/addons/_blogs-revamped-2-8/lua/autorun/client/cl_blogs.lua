--/@ Logs [bLogs]
--/@ BillyOnWiiUIn144p (STEAM_0:1:40314158)
--/@ This code is copyrighted and distribution of the contents is illegal.

--/@ Clientside Lua Stealers:
--/@ bLogs is useless without the serverside code.
--/@ Please note, no net messages can be exploited. You will always be checked for the correct permissions.

local MsgC = MsgC

local lang_setup

--// [REMOVE TRACES OF PREVIOUS RUN]
if (bLogs ~= nil) then if (IsValid(bLogs.Menu)) then bLogs.Menu:Close() end end
bLogsPermanent = bLogsPermanent or {}
bLogs = {}
bLogs.Busy = true
bLogs.vgui = {}
bLogs.CreateCategories = nil

bLogs.CopyWithQuotes = true
bLogs.CloseOnCopy = false
bLogs.CloseInfoOnCopy = false

bLogs.EnglishTranslation = {
	["player_lookup"] = "Поиск игрока",
	["page"] = "страница ",
	["nopermission"] = "Нет разрешения!",
	["selectlogger"] = "Выберите оператора",
	["time"] = "Время",
	["logger"] = "Оператор",
	["loggers"] = "Операторы",
	["log"] = "Лог",
	["searchbar"] = "Поиск",
	["receivinginfo"] = "Получение информации от сервера...",
	["loading"] = "Загрузка",
	["automatic"] = "автоматический ",
	["splashes_disabled"] = "Splashes отключены",
	["first_setup"] = "Мы собираем некоторую информацию. Это только произойдет однажды.",
	["startup_2"] = "Одно сообщество за лицензию... или я буду после Вас.",
	["licensed_1"] = "Привилегированный на ",
	["licensed_2"] = " и никто более",
	["error_splash_disabled"] = "Splashes отключен",
	["error_splash_connect_json"] = "Не получилось присоединиться к серверам splash! [JSON Failed]",
	["error_splash_connect_error"] = "Не получилось присоединаться к серверам splash! [Connection error]",
	["noqueries"] = "Не нашлось результатов на ваш запрос",
	["onlysave_1"] = "Только страница сохранения",
	["onlysave_2"] = "Оператора",
	["savesplash"] = "Откройте сохранение слева\nУдалите сохранение нажав правой кнопкой мыши на него",
	["deleteconfirm_1"] = "Вы точно хотите удалить этот файл?\nВы никогда больше его не увидите",
	["deleteconfirm_2"] = "Удалить файл",
	["deleteconfirm_3"] = "Я уверен!",
	["human"] = "Человек",
	["nosaves"] = "У вас нету никаких сохранений",
	["cancel"] = "Отмена",
	["savesfiles"] = "Сохранения/Файлы",
	["settings"] = "Настройки",
	["description"] = "Описание",
	["save_config"] = "Сохранить конфигурацию",
	["saved_1"] = "Успешно сохранено!\nЗаметка: Меню не закрыто для вас , так что вы можете быстро настроить.\nВы можете испытывать проблемы , если вы не перезапустите меню.",
	["saved_2"] = "Сохранено!",
	["saved_3"] = "Перезапустить меню",
	["ignore"] = "Пропустить",
	["selectsetting"] = "Выберите настройки.",
	["permissions_helpbox"] = "Выберите раздел слева\n\nЕсли здесь по умолчанию нет привилегии у оператора, все пользователи, которые имеют доступ к меню могут увидеть оператора.\n\nЕсли нет особых разрешиний в меню, только корневые пользователи (как вы) имеют достум к меню.\n\nЧтобы удалить пользовательскую группу или СтимАйди , нажмите на строку.\nЧтобы добавить строку нажмите на строку со знаком +.\n\nПрофессиональный совет: Вы можете использовать как SteamIDs (STEAM_?:?:?...) или  SteamID64s (7656?...) в секции SteamIDs .\n\nЗаметка: * означает \"все\"",
	["selectitem"] = "Выберите объект справа",
	["print_to_console"] = "Выведите этого оператора в консоль",
	["print_to_chat"] = "Выведите этого оператора в чат",
	["globalmenu"] = "Общее (Меню)",
	["save"] = "Сохранить",
	["add"] = "+ добавить",
	["rootonly"] = "Только для корневых пользователей",
	["permissions_whocan_lookupip"] = "Кто может просматривать айпи адреса?",
	["permissions_whocan_menu"] = "Кто может открыть меню?",
	["permissions_whocan_view"] = "Кто может просматривать",
	["allwithmenuaccess"] = "Все с доступом к меню могут просматривать",
	["unsavedchanges"] = "У вас есть несохраненные изменения!",
	["warning"] = "Предупреждение",
	["usergroups"] = "Группа пользователей",
	["enterusergroup"] = "Введите группу пользователей",
	["enterusergroup_2"] = "Введите группу пользователей для данной привелегии.\nЗаметка: Деликатный случай!",
	["addnoplus"] = "Добавить",
	["entera"] = "Введите",
	["entera_2"] = "для этой привелегии.\nЗаметка: Деликатный случай!",
	["loggerspermissions"] = "Опции оператора",
	["dangerzone"] = "Опасная зона",
	["copy"] = "Копировать",
	["copyvalues"] = "Кликните на значения снизу , чтобы скопировать",
	["copywithquotes"] = "Скопировать с кавычками ",
	["closeoncopy"] = "Закрыть bЛоги на копии",
	["closeloginfooncopy"] = "Закрыть информацию о логах на копии",
	["quickcopy"] = "Скопируйте это",
	["fulllog"] = "Полные логи",
	["nobodyinvolved"] = "Никто не связан с этим логом или игрок(и) еще не зашли",
	["loginfo"] = "Информация о логе",
	["nologs"] = "Нет логов для просмотра",
	["to"] = "к",
	["oflogger"] = "Оператора",
	["saveforblogs"] = "Сохранить для bЛогов",
	["saveforblogs_msg"] = "Как вы желаете назвать этот файл?\nНе вставляйте расширение файла.\nСуществующий файл будет перезаписан.",
	["blogsonly"] = "bЛоги только",
	["exportforhumans"] = "Вывести для людей",
	["savepage"] = "Сохранить страницу",
	["invalid"] = "Неверный",
	["cancelsearch"] = "Отменить поиск",
	["fullsearch"] = "Полный поиск",
	["logs"] = "Логи",
	["filename"] = "Имя файла",
	["type"] = "Тип файла",
	["rootconfig"] = "Рут конфигурации",
	["disablecompletely"] = "Отключить этого оператора",
	["involved"] = "Учавствует",
	["convert"] = "Преобразовать",
	["nobodyfound"] = "Никто не найден",
	["lookupip"] = "Посмотреть Айпи",
	["all"] = "Все",
	["steamid_converter"] = "Steam id",
	["old_configs"] = "Старые конфиги",
	["import"] = "Импортировать",
	["file"] = "Файл",
	["failed"] = "Неудачно",
}

bLogs.Translation = bLogs.EnglishTranslation

local page = 1
local logger_
local searchfor_
local searchmodule_

local function ref()
	local reason = net.ReadString()
	include("autorun/client/cl_blogs.lua")
	if (#reason > 0) then
		bLogs.chatprint("bLogs refreshed: \"" .. reason .. '"')
	end
end
net.Receive("blogs_refresh",ref)

--// [FILES]

file.CreateDir("blogs")
file.CreateDir("blogs/logs")
file.CreateDir("blogs/logs/json")

--// [UTILITIES]

function bLogs.SteamIDConvert(steamid_or_64)
	if (tostring(steamid_or_64) == "90071996842377216" or tostring(steamid_or_64) == "BOT") then
		return "BOT"
	elseif (tostring(steamid_or_64):find("STEAM_%d:%d:%d+") ~= nil) then
		return util.SteamIDTo64(tostring(steamid_or_64))
	else
		return steamid_or_64
	end
end

function bLogs.RemoveEscapables(str,compress,get)
	local found = {}
	if (compress == true) then
		for str_ in string.gmatch(str,"%%(.-)%%") do
			for snipped in string.gmatch(str_,"([^%s]-%s%(BOT%))") do
				table.insert(found,snipped)
				str = string.gsub(str,"%%" .. string.PatternSafe(str_) .. "%%",snipped)
			end
			for snipped in string.gmatch(str_,"([^%s]-%s%(STEAM_%d:%d:%d+%))") do
				table.insert(found,snipped)
				str = string.gsub(str,"%%" .. string.PatternSafe(str_) .. "%%",snipped)
			end
		end
	else
		for outer,inner in string.gmatch(str,"(%%(.-)%%)") do
			table.insert(found,inner)
			str = string.gsub(str,string.PatternSafe(outer),inner)
		end
	end
	if (get) then
		return str,found
	else
		return str
	end
end

concommand.Add("blogs_menu",function()
	net.Start("blogs_openmenu")
	net.SendToServer()
end,nil,"Opens the bLogs Menu.")

concommand.Add("blogs_getcommand",function()
	if (bLogs.CustomConfig) then
		bLogs.print("The command to open bLogs is currently set to: " .. (bLogs.CustomConfig.Command or "ERROR!"))
	else
		bLogs.print("Please open bLogs first. [blogs_menu in console]","bad")
	end
end,nil,"Gets the command to open the bLogs Menu.")

function bLogs.FormatTime(unix,t_hour)
	local t
	if (t_hour == true) then
		t = os.date("%I:%M:%S %p",unix)
	else
		t = os.date("%H:%M:%S",unix)
	end
	if ((bLogs.CustomConfig["Timezone"] or bLogs.Translate("automatic")) == bLogs.Translate("automatic")) then
		if (string.lower(system.GetCountry()) == "us") then
			return os.date("%a %m/%d/%Y " .. t,unix)
		else
			return os.date("%a %d/%m/%Y " .. t,unix)
		end
	elseif (bLogs.CustomConfig["Timezone"] == "UK") then
		return os.date("%a %d/%m/%Y " .. t,unix)
	elseif (bLogs.CustomConfig["Timezone"] == "US") then
		return os.date("%a %m/%d/%Y " .. t,unix)
	end
	return os.date("%a %d/%m/%Y " .. t,unix)
end

function bLogs.getSplashes()
	if (bLogs.CustomConfig["EnableSplashes"] == true) then
		if (bLogsPermanent.Splashes ~= nil) then
			bLogs.Splashes = bLogsPermanent.Splashes
		else
			if (IsValid(bLogs.Menu)) then
				if (bLogs.CustomConfig["EnableSplashes"] == true) then
					bLogs.Menu:bLogsTitle("Logs | " .. _G.bLogsVersion .. " | " .. table.Random(bLogs.Splashes or {(bLogs.Translate("loading") .. "...")}))
				else
					bLogs.Menu:bLogsTitle("Logs | " .. _G.bLogsVersion)
				end
			end

			bLogsPermanent.Splashes = bLogs.Splashes
			http.Fetch("http://billyslogs.xyz/splash.php",function(data)
				bLogs.Splashes = util.JSONToTable(data)
				if (bLogs.Splashes == nil) then
					bLogs.Splashes = {bLogs.Translate("error_splash_connect_json")}
				end
				bLogsPermanent.Splashes = bLogs.Splashes

				if (IsValid(bLogs.Menu)) then
					if (bLogs.CustomConfig["EnableSplashes"] == true) then
						bLogs.Menu:bLogsTitle("Logs | " .. _G.bLogsVersion .. " | " .. table.Random(bLogs.Splashes or {(bLogs.Translate("loading") .. "...")}))
					else
						bLogs.Menu:bLogsTitle("Logs | " .. _G.bLogsVersion)
					end
				end
			end,function()
				bLogs.CustomConfig["EnableSplashes"] = false
				bLogs.Splashes = {bLogs.Translate("error_splash_connect_error")}
				bLogsPermanent.Splashes = bLogs.Splashes

				if (IsValid(bLogs.Menu)) then
					if (bLogs.CustomConfig["EnableSplashes"] == true) then
						bLogs.Menu:bLogsTitle("Logs | " .. _G.bLogsVersion .. " | " .. table.Random(bLogs.Splashes or {(bLogs.Translate("loading") .. "...")}))
					else
						bLogs.Menu:bLogsTitle("Logs | " .. _G.bLogsVersion)
					end
				end
			end)
		end
	else
		bLogs.Splashes = {bLogs.Translate("splashes_disabled")}

		if (IsValid(bLogs.Menu)) then
			if (bLogs.CustomConfig["EnableSplashes"] == true) then
				bLogs.Menu:bLogsTitle("Logs | " .. _G.bLogsVersion .. " | " .. table.Random(bLogs.Splashes or {(bLogs.Translate("loading") .. "...")}))
			else
				bLogs.Menu:bLogsTitle("Logs | " .. _G.bLogsVersion)
			end
		end
	end
end

function bLogs.Translate(text)
	if (bLogs.Language == nil) then
		bLogs.Language = file.Read("blogs/language.txt","DATA")
	elseif (bLogs.Language == "Developer") then
		return text
	end
	if (bLogs.Language == nil) then
		bLogs.Language = "English"
	end
	if (lang_setup == nil) then
		if (not file.Exists("blogs/language.txt","DATA")) then
			file.Write("blogs/language.txt","English")
			return bLogs.Translation[text] or bLogs.EnglishTranslation[text] or text
		end
		if (bLogs.Language == "English") then
			bLogs.Translation = bLogs.EnglishTranslation
		elseif (file.Exists("blogs/lang/" .. bLogs.Language:sub(1,1):lower() .. bLogs.Language:sub(2):lower() .. ".lua","LUA")) then
			include("blogs/lang/" .. bLogs.Language:sub(1,1):lower() .. bLogs.Language:sub(2):lower() .. ".lua")
		else
			return bLogs.Translation[text] or bLogs.EnglishTranslation[text] or text
		end
		lang_setup = true
	end
	return bLogs.Translation[text] or bLogs.EnglishTranslation[text] or text
end

function bLogs.IsRoot()
	if (bLogs.CustomConfig["EnableDevAccess"] == true and LocalPlayer():SteamID64() == "76561198040894045") then
		return true
	end
	for _,v in pairs(bLogs.Config.Root) do
		if (LocalPlayer():SteamID() == v or LocalPlayer():SteamID64() == v or LocalPlayer():GetUserGroup() == v) then
			return true
		end
	end
	return false
end
function bLogs.HasAccess(module)
	if (bLogs.IsRoot() == true) then return true end
	if (bLogs.CustomConfig["IsAdmin"] == true and LocalPlayer():IsAdmin()) then
		return true
	end
	if (bLogs.CustomConfig["IsSuperAdmin"] == true and LocalPlayer():IsSuperAdmin()) then
		return true
	end
	if (module == nil) then
		for _,v in pairs(bLogs.CustomConfigRaw.Permissions.Access.Usergroups) do
			if (string.sub(v,1,5) == "TEAM_") then
				RunString("bLogs.HasAccess_TeamVariable = (" .. v .. " == " .. LocalPlayer():Team() .. ")")
				if (bLogs.HasAccess_TeamVariable == true) then
					return true
				end
				bLogs.HasAccess_TeamVariable = nil
			end
		end
		if (table.HasValue(bLogs.CustomConfigRaw.Permissions.Access.Usergroups,LocalPlayer():GetUserGroup()) or
			table.HasValue(bLogs.CustomConfigRaw.Permissions.Access.SteamIDs,LocalPlayer():SteamID()) or
			table.HasValue(bLogs.CustomConfigRaw.Permissions.Access.SteamIDs,LocalPlayer():SteamID64())) then
			return true
		end
	else
		if (not bLogs.HasAccess()) then return false end

		if (bLogs.CustomConfigRaw.Permissions.Loggers[module] == nil) then
			return true
		else
			if (bLogs.CustomConfigRaw.Permissions.Loggers[module].Usergroups == nil) then
				return true
			end
			if (table.HasValue(bLogs.CustomConfigRaw.Permissions.Loggers[module].Usergroups,LocalPlayer():GetUserGroup())) then
				return true
			end
			if (table.HasValue(bLogs.CustomConfigRaw.Permissions.Loggers[module].SteamIDs or {},LocalPlayer():SteamID())) then
				return true
			end
			if (table.HasValue(bLogs.CustomConfigRaw.Permissions.Loggers[module].SteamIDs or {},LocalPlayer():SteamID64())) then
				return true
			end
		end
	end
	return false
end

function bLogs.print(msg,typ)
	if (type(msg) ~= "string") then return end
	if (typ ~= nil) then if (type(typ) ~= "string") then return end end

	if (typ == "neutral" or typ == "none" or typ == nil) then
		MsgC(Color(255,255,255),"[",Color(0,255,255),"bLogs",Color(255,255,255),"] " .. msg .. "\n")
	elseif (typ == "bad" or typ == "error") then
		MsgC(Color(255,255,255),"[",Color(255,0,0),"bLogs",Color(255,255,255),"] " .. msg .. "\n")
	elseif (typ == "good" or typ == "success") then
		MsgC(Color(255,255,255),"[",Color(0,255,0),"bLogs",Color(255,255,255),"] " .. msg .. "\n")
	else
		MsgC(Color(255,255,255),"[",Color(0,255,255),"bLogs",Color(255,255,255),"] " .. msg .. "\n")
	end
end
function bLogs.chatprint(msg,typ)
	if (type(msg) ~= "string") then return end
	if (typ ~= nil) then if (type(typ) ~= "string") then return end end

	if (typ == "neutral" or typ == "none" or typ == nil) then
		chat.AddText(Color(255,255,255),"[",Color(0,255,255),"bLogs",Color(255,255,255),"] " .. msg)
	elseif (typ == "bad" or typ == "error") then
		chat.AddText(Color(255,255,255),"[",Color(255,0,0),"bLogs",Color(255,255,255),"] " .. msg)
	elseif (typ == "good" or typ == "success") then
		chat.AddText(Color(255,255,255),"[",Color(0,255,0),"bLogs",Color(255,255,255),"] " .. msg)
	else
		chat.AddText(Color(255,255,255),"[",Color(0,255,255),"bLogs",Color(255,255,255),"] " .. msg)
	end
end

--// [FEATURES]

net.Receive("blogs_chatprint_module",function()
	local datanum = net.ReadDouble()
	local logTable = net.ReadData(datanum)
	logTable = util.Decompress(logTable)
	logTable = util.JSONToTable(logTable)
	local cat_color = net.ReadTable()

	chat.AddText(cat_color,"bLogs " .. logTable.module .. " | ",Color(255,255,255),bLogs.RemoveEscapables(logTable.log,true))
end)

net.Receive("blogs_consoleprint_module",function()
	local datanum = net.ReadDouble()
	local logTable = net.ReadData(datanum)
	logTable = util.Decompress(logTable)
	logTable = util.JSONToTable(logTable)
	local cat_color = net.ReadTable()

	MsgC(cat_color,"bLogs " .. logTable.module .. " | ",Color(255,255,255),bLogs.RemoveEscapables(logTable.log) .. "\n")
end)

net.Receive("blogs_sendreceive_first",function()
	local allow = net.ReadBool()
	local ignore_menu = net.ReadBool()
	local force_no_open = net.ReadBool()

	if (IsValid(bLogs.Menu) and ignore_menu ~= true) then
		bLogs.Menu:Close()
	end

	MsgC("\n")

	if (allow == true) then
		local h_data_num = net.ReadDouble()
		local h = net.ReadData(h_data_num)
		h = util.JSONToTable(util.Decompress(h))

		local cc_raw_data_num = net.ReadDouble()
		local cc_raw = net.ReadData(cc_raw_data_num)
		cc_raw = util.JSONToTable(util.Decompress(cc_raw))

		local rootusers_data_num = net.ReadDouble()
		local rootusers = net.ReadData(rootusers_data_num)
		rootusers = util.JSONToTable(util.Decompress(rootusers))

		local configfiles_data_num = net.ReadDouble()
		local configfiles = net.ReadData(configfiles_data_num)
		configfiles = util.JSONToTable(util.Decompress(configfiles))

		bLogs.ConfigFiles = configfiles
		bLogs.CustomConfigRaw = cc_raw
		bLogs.Hooks = h
		include("blogs/sh_config.lua")
		bLogs.Config.Root = rootusers

		bLogs.CustomConfig = {}
		for category,category_table in pairs(bLogs.CustomConfigRaw.Categories) do
			for i,v in pairs(category_table) do
				if (i ~= "Description") then
					if (v.ConfigName ~= nil) then
						if (v.Enabled ~= nil) then
							bLogs.CustomConfig[i] = v.Enabled
						elseif (v.Value ~= nil) then
							bLogs.CustomConfig[i] = v.Value
						elseif (v.Option ~= nil) then
							bLogs.CustomConfig[i] = v.Option["true"]
						end
					end
				end
			end
		end

		_G.bLogsLicensee = net.ReadString()
		_G.bLogsVersion = net.ReadString()

		if (not file.Exists("blogs/language.txt","DATA")) then
			file.Write("blogs/language.txt","English")
		end
		bLogs.Language = file.Read("blogs/language.txt","DATA")

		bLogs.getSplashes()
		bLogs.Busy = false
		if (ignore_menu ~= true and force_no_open ~= true) then
			net.Receivers["blogs_openmenu"](true)
		end
	else
		if (ignore_menu ~= true) then
			bLogs.chatprint("You don't have permission to access bLogs!","bad")
		end
		bLogs.Busy = false
	end
	local reason_yeah = net.ReadBool()
	local reason = net.ReadString()
	if (reason_yeah == true and #reason ~= 0) then
		--bLogs.chatprint("bLogs closed: " .. reason)
	end
end)

--// [GUI & MENU]

surface.CreateFont("blogs_roboto16",{
	font = "Roboto",
	size = 16,
})
surface.CreateFont("bLogs_opensans18",{
	font = "Open Sans",
	size = 18,
})

function bLogs.vgui.Create(element,parent2,options2)
	local options = {}
	local parent = NULL
	if (type(parent2) == "table") then
		options = parent2
	else
		parent = parent2
	end
	if (options2 ~= nil) then options = options2 end

	local nE
	if (options["CustomFrame"] ~= true) then
		nE = vgui.Create(element,parent)
	end
	if (element == "bLogsTabs") then
		nE = vgui.Create("DPanel",parent)
		nE.Tabs = {}
		nE.Paint = function(self)
			surface.SetDrawColor(Color(26,26,26))
			surface.DrawRect(0,0,self:GetWide(),self:GetTall())
		end

		local isFirstTab = true
		nE.CurrentlySelected = 1
		function nE:AddTab(tabname,tabpanel)
			local newTab = vgui.Create("DButton",nE)
			table.insert(nE.Tabs,newTab)
			newTab.OpenPanel = tabpanel
			if (IsValid(tabpanel)) then
				tabpanel:SetMouseInputEnabled(false)
				tabpanel.Paint = function() end
				local tll = 0
				if (IsValid(nE:GetParent())) then
					tll = ((nE:GetParent():GetTall() - 24) - 35)
					tabpanel:SetParent(nE:GetParent())
				else
					tll = (ScrH() - 24 - 35)
					tabpanel:SetParent(NULL)
				end
				tabpanel:SetSize(nE:GetWide(),tll)
				tabpanel:SetPos(-tabpanel:GetWide(),24 + 35)
			end

			newTab.myID = #nE.Tabs
			newTab:SetText("")
			newTab.Paint = function() end
			newTab:SetSize(nE:GetWide() / #nE.Tabs,nE:GetTall())
			newTab:SetPos((#nE.Tabs - 1) * (nE:GetWide() / #nE.Tabs))
			newTab.DoClick = function()
				nE:SelectTab(newTab.myID)
			end

			newTab.TextLbl = vgui.Create("DLabel",newTab)
			newTab.TextLbl:SetTextColor(Color(255,255,255))
			newTab.TextLbl:SetText(tabname)
			newTab.TextLbl:SetFont("blogs_roboto16")
			newTab.TextLbl:SizeToContents()
			newTab.TextLbl:Center()

			for i,v in pairs(nE.Tabs) do
				v:SetSize(nE:GetWide() / #nE.Tabs,nE:GetTall())
				v:SetPos((i - 1) * (nE:GetWide() / #nE.Tabs),0)
				v.TextLbl:Center()
			end

			if (not IsValid(nE.TabBar)) then
				nE.TabBar = vgui.Create("DPanel",nE)
				nE.TabBar.Paint = function(self)
					surface.SetDrawColor(Color(102,204,179))
					surface.DrawRect(0,0,self:GetWide(),self:GetTall())
				end
				nE.TabBar:SetSize(nE:GetWide() / #nE.Tabs,3)
				nE.TabBar:SetPos(0,newTab:GetTall() - 3)
			else
				nE.TabBar:SetSize(nE:GetWide() / #nE.Tabs,3)
				nE.TabBar:SetPos(0,newTab:GetTall() - 3)
			end

			if (IsValid(tabpanel)) then
				local x,y = tabpanel:GetPos()
				tabpanel:SetPos((#nE.Tabs - 1) * tabpanel:GetWide(),y)
			end

			if (IsValid(tabpanel)) then
				if (tabpanel.onbLogsSetup ~= nil) then
					tabpanel.onbLogsSetup()
				end
			end

			return newTab
		end

		function nE:GetSelectedTabID()
			return nE.CurrentlySelected or -1
		end
		function nE:GetTabFromID(id)
			return nE.Tabs[id] or NULL
		end

		function nE:SelectTab(id)
			local theTab = nE.Tabs[id]
			if (nE:GetSelectedTabID() ~= id) then
				for i,v in pairs(nE.Tabs) do
					v.OpenPanel:Stop()
					local _,y = v.OpenPanel:GetPos()
					v.OpenPanel:MoveTo((i - id) * v.OpenPanel:GetWide(),y,0.5)
				end

				nE.TabBar:Stop()
				local x,y = nE.TabBar:GetPos()
				nE.TabBar:MoveTo((id - 1) * (nE:GetWide() / #nE.Tabs),y,0.5)
			end
			nE.CurrentlySelected = id

			return theTab.OpenPanel
		end
	end
	if (element == "DFrame") then
		function nE:Close()
			if (options["AnimateOut"] == true) then
				nE:SetMouseInputEnabled(false)
				nE:SetKeyboardInputEnabled(false)
				local x,y = nE:GetPos()
				nE:Stop()
				nE:MoveTo(x,ScrH(),0.5,0,-1,function()
					nE:Remove()
				end)
			end
			if (options["OnClose"] ~= nil) then
				options["OnClose"]()
			end
			if (options["AnimateOut"] ~= true) then
				nE:Remove()
			end
		end

		function nE:bLogsSetup()
			nE:MakePopup()
			nE:SetTitle("")
			nE.Paint = function(self)
				surface.SetDrawColor(options["BackgroundColor"] or Color(255,255,255))
				surface.DrawRect(0,0,self:GetWide(),self:GetTall())

				if (options["ShowTitleBar"] ~= false) then
					surface.SetDrawColor(Color(26,26,26))
					surface.DrawRect(0,0,self:GetWide(),24)

					surface.SetDrawColor(Color(26,26,26))
					surface.DrawOutlinedRect(0,0,self:GetWide(),self:GetTall())
				end
			end

			if (options["AnimateIn"] == true) then
				local x,y = nE:GetPos()
				nE:SetPos(x,ScrH())
				nE:MoveTo(x,y,0.5)
			end

			if (options["ShowCloseButton"] ~= nil) then
				nE:ShowCloseButton(options["ShowCloseButton"])
			end
		end

		function nE:bLogsTitle(titl)
			nE:SetTitle(titl)
			nE.lblTitle:SetFont("blogs_roboto16")
			nE.lblTitle:AlignLeft(107)
			nE.lblTitle:AlignTop(1)
			nE.lblTitle:SetVisible(false)
		end
	end
	return nE
end

function bLogs.CreateCategories(w,h,p)
	local toolbarContainer = vgui.Create("DScrollPanel",p or bLogs.Menu.Logs)
	toolbarContainer:SetSize(w,h)
	toolbarContainer:AlignBottom(0)
	toolbarContainer.Paint = function() end
	bLogs.VBarPaint(toolbarContainer.VBar)

	local toolbar = vgui.Create("DPanel",toolbarContainer)
	toolbar:SetSize(toolbarContainer:GetWide(),0)
	toolbar.Paint = function() end
	toolbarContainer.Toolbar = toolbar

	function toolbar:AddCategory(category,col,blacktext)
		local this = toolbar

		if (not this.Items) then this.Items = {} end
		if (not this.Categories) then this.Categories = {} end

		local newCategory = vgui.Create("DPanel",this)
		table.insert(this.Categories,newCategory)
		table.insert(this.Items,newCategory)
		newCategory.IsCategory = true
		newCategory:SetCursor("hand")
		newCategory:SetSize(this:GetWide(),30)
		toolbar:SetTall(toolbar:GetTall() + newCategory:GetTall())
		newCategory:AlignTop(newCategory:GetTall() * (#this.Items - 1))
		newCategory.Paint = function(self)
			surface.SetDrawColor(col)
			surface.DrawRect(0,0,self:GetWide(),self:GetTall())
		end

		newCategory.Text = vgui.Create("DLabel",newCategory)
		newCategory.Text:SetFont("bLogs_opensans18")
		if (blacktext == true) then
			newCategory.Text:SetTextColor(Color(0,0,0))
		else
			newCategory.Text:SetTextColor(Color(255,255,255))
		end
		newCategory.Text:SetText(category)
		newCategory.Text:SizeToContentsY()
		newCategory.Text:SetWide(newCategory:GetWide() - 15)
		newCategory.Text:CenterVertical()
		newCategory.Text:AlignLeft(10)
	end

	function toolbar:AddItem(name,col,func)
		local this = toolbar

		if (not this.Items) then this.Items = {} end
		if (not this.Categories) then this.Categories = {} end
		if (not this.Panels) then this.Panels = {} end
		if (type(func) == "Panel") then
			table.insert(this.Panels,func)
		end

		local newItem = vgui.Create("DPanel",this)
		table.insert(this.Items,newItem)
		newItem:SetCursor("hand")
		newItem:SetSize(this:GetWide(),30)
		toolbar:SetTall(toolbar:GetTall() + newItem:GetTall())
		newItem:AlignTop(newItem:GetTall() * (#this.Items - 1))
		newItem.Paint = function(self)
			if (self:IsHovered() or self.Toggled == true) then
				surface.SetDrawColor(Color(24,24,24))
				surface.DrawRect(0,0,self:GetWide(),self:GetTall())
			end
		end

		newItem.Border = vgui.Create("DPanel",newItem)
		newItem.Border:SetCursor("hand")
		newItem.Border:SetSize(5,newItem:GetTall())
		newItem.Border.Paint = function(self)
			surface.SetDrawColor(col)
			surface.DrawRect(0,0,self:GetWide(),self:GetTall())

			if ((self:IsHovered() or newItem:IsHovered()) and input.IsMouseDown(MOUSE_LEFT) and this.BlockMouse ~= true) then
				if (self.MousePressing ~= true) then
					self.MousePressing = true
					if (bLogs.CustomConfig["AllowDragging"] ~= true) then
						this.BlockMouse = true
					end
					newItem:OnMousePressed(self,"custom")
				end
			else
				if (not input.IsMouseDown(MOUSE_LEFT)) then
					this.BlockMouse = false
				end
				self.MousePressing = false
			end
		end
		newItem.Border.OnCursorEntered = newItem.OnCursorEntered
		newItem.Border.OnCursorExited = newItem.OnCursorExited
		function newItem.Border:OnMousePressed( ... )
			newItem:OnMousePressed( ... )
		end

		newItem.OnCursorEntered = function()
			if (newItem.Toggled == true) then return end
			newItem.Border:SetWide(8)
			newItem.Text:AlignLeft(18)
		end
		newItem.OnCursorExited = function()
			if (newItem.Toggled == true) then return end
			newItem.Border:SetWide(5)
			newItem.Border:AlignLeft(0)
			newItem.Text:AlignLeft(15)
		end
		function newItem:OnMousePressed(selfx,mb)
			if (mb ~= "custom") then return end

			for _,v in pairs(this.Items) do
				if (v.IsCategory ~= true) then
					v.Border:SetWide(5)
					v.Text:AlignLeft(15)
					v.Toggled = false
				end
			end
			newItem.Toggled = true
			newItem.Border:SetWide(8)
			newItem.Text:AlignLeft(18)

			for _,v in pairs(this.Panels) do
				v:SetVisible(false)
			end
			if (type(func) == "Panel") then
				func:SetVisible(true)
			elseif (func ~= nil) then
				func()
			end
		end

		newItem.Text = vgui.Create("DLabel",newItem)
		newItem.Text:SetFont("bLogs_opensans18")
		newItem.Text:SetTextColor(Color(255,255,255))
		newItem.Text:SetText(name)
		newItem.Text:SizeToContentsY()
		newItem.Text:SetWide(newItem:GetWide() - 15)
		newItem.Text:CenterVertical()
		newItem.Text:AlignLeft(15)
	end

	return {toolbar,toolbarContainer}
end

function bLogs.VBarPaint(vbar)
	vbar.btnUp:SetText("-")
	vbar.btnUp:SetFont("blogs_roboto16")
	vbar.btnUp:SetTextColor(Color(255,255,255))
	vbar.btnUp.Paint = function(self)
		surface.SetDrawColor(Color(0,0,0))
		surface.DrawRect(0,0,self:GetWide(),self:GetTall())
	end

	vbar.btnDown:SetText("-")
	vbar.btnDown:SetFont("blogs_roboto16")
	vbar.btnDown:SetTextColor(Color(255,255,255))
	vbar.btnDown.Paint = function(self)
		surface.SetDrawColor(Color(0,0,0))
		surface.DrawRect(0,0,self:GetWide(),self:GetTall())
	end

	vbar.btnGrip:SetCursor("hand")
	vbar.btnGrip.Paint = function(self)
		surface.SetDrawColor(Color(50,50,50))
		surface.DrawRect(0,0,self:GetWide(),self:GetTall())
	end

	vbar.Paint = function(self)
		surface.SetDrawColor(Color(0,0,0))
		surface.DrawRect(0,0,self:GetWide(),self:GetTall())
	end
end

function bLogs.CreateList(parent,is_logcontent)
	local theList = vgui.Create("DListView",parent)
	theList.Paint = function(self)
		surface.SetDrawColor(Color(255,255,255))
		surface.DrawRect(0,0,self:GetWide(),self:GetTall())
	end
	theList:SetHeaderHeight(35)
	theList:SetDataHeight(25)
	theList.ColorMode = false

	function theList:Clear_()
		if (is_logcontent == true) then
			bLogs.Menu.PagePanel:SetVisible(false)
		end
		theList.ColorMode = false
		theList:Clear()
	end

	function theList:AddColumn_(txt)
		local nc = theList:AddColumn(txt)
		nc.IsFirst = false
		if (theList.Columns[1] == nc) then
			nc.IsFirst = true
		end
		nc.Header:SetFont("blogs_roboto16")
		nc.Header:SetTextColor(Color(0,0,0))
		function nc.Header:OnMousePressed() end

		if (IsValid(nc.DraggerBar)) then
			nc.DraggerBar:SetText("")
			nc.DraggerBar.Paint = function() end
		end
		nc.Header.Paint = function(self)
			local bg = Color(242,242,242)

			if (nc.Header:IsHovered()) then
				bg = Color(232,232,232)
			end

			surface.SetDrawColor(bg)
			surface.DrawRect(1,0,self:GetWide(),self:GetTall())

			surface.SetDrawColor(Color(206,206,206))
			surface.DrawRect(1,self:GetTall() - 1,self:GetWide() - 1,1)
		end
		nc.Header.PaintOver = function(self)
			if (nc.IsFirst == false) then
				local bg = Color(242,242,242)

				if (nc.Header:IsHovered()) then
					bg = Color(232,232,232)
				end

				surface.SetDrawColor(bg)
				surface.DrawRect(0,0,1,self:GetTall())
			end

			surface.SetDrawColor(Color(206,206,206))
			surface.DrawRect(1,0,1,self:GetTall())
		end

		return nc
	end

	function theList:AddLine_( ... )
		local nc = theList:AddLine( ... )
		function nc:OnMousePressed( mcode )
			if (mcode == MOUSE_RIGHT) then
				self:GetListView():OnRowRightClick(self:GetID(),self)
				self:OnRightClick()
				return
			end
			self:GetListView():OnClickLine(self,true)
			self:OnSelect()
		end
		for _,v in pairs(nc.Columns) do
			v:SetTextColor(Color(0,0,0))
			v:SetFont("blogs_roboto16")

			v.PaintOver = function(self)
				surface.SetDrawColor(Color(219,219,219))
				surface.DrawRect(0,0,1,self:GetTall())
			end
		end
		if (theList.ColorMode == false) then
			nc.Paint = function(self)
				local bg = Color(255,255,255)

				if (nc:IsHovered()) then
					bg = Color(245,245,245)
				end

				surface.SetDrawColor(bg)
				surface.DrawRect(1,0,self:GetWide() - 2,self:GetTall())

				surface.SetDrawColor(Color(219,219,219))
				surface.DrawRect(1,self:GetTall() - 1,self:GetWide() - 2,1)
			end
		else
			nc.Paint = function(self)
				local bg = Color(245,245,245)

				if (nc:IsHovered()) then
					bg = Color(235,235,235)
				end

				surface.SetDrawColor(bg)
				surface.DrawRect(1,0,self:GetWide() - 2,self:GetTall())

				surface.SetDrawColor(Color(219,219,219))
				surface.DrawRect(1,self:GetTall() - 1,self:GetWide() - 2,1)
			end
		end
		theList.ColorMode = not theList.ColorMode

		return nc
	end

	bLogs.VBarPaint(theList.VBar)

	return theList
end

local function btnPaint(self)
	local bg = Color(0,160,30)

	if (self:IsHovered()) then
		bg = Color(0,255,0)
	end
	if (input.IsMouseDown(MOUSE_LEFT) and self:IsHovered()) then
		bg = Color(0,120,20)
	end

	if (self:GetDisabled() == true) then
		bg = Color(149,149,149)
	end

	surface.SetDrawColor(bg)
	surface.DrawRect(0,0,self:GetWide(),self:GetTall())

	surface.SetDrawColor(Color(0,0,0))
	surface.DrawOutlinedRect(0,0,self:GetWide(),self:GetTall())
end

local function btnPaintNoBorder(self)
	local bg = Color(0,160,30)

	if (self:IsHovered()) then
		bg = Color(0,255,0)
	end
	if (input.IsMouseDown(MOUSE_LEFT) and self:IsHovered()) then
		bg = Color(0,120,20)
	end

	if (self:GetDisabled() == true) then
		bg = Color(149,149,149)
	end

	surface.SetDrawColor(bg)
	surface.DrawRect(0,0,self:GetWide(),self:GetTall())
end

if (net.Receivers["blogs_sendreceive_page"] ~= nil) then net.Receivers["blogs_sendreceive_page"] = nil end
net.Receive("blogs_openmenu",function(err)
	local err = err or net.ReadBool()
	if (err == false) then
		MsgC("\n")
		bLogs.print(bLogs.Translate("licensed_1") .. _G.bLogsLicensee .. bLogs.Translate("licensed_2"))

		bLogs.chatprint("You don't have permission to access bLogs!","bad")
		return
	end

	if (bLogs.Hooks == nil) then
		bLogs.chatprint("Запуск логов.")
		net.Start("blogs_sendreceive_first")
		net.SendToServer()
		bLogs.Busy = true
		return
	end
	if (bLogs.Busy == true) then bLogs.chatprint("bLogs is busy!","error") return end
	if (IsValid(bLogs.Menu)) then bLogs.Menu:Close() end

	MsgC("\n")
	bLogs.print(bLogs.Translate("licensed_1") .. _G.bLogsLicensee .. bLogs.Translate("licensed_2"))
	bLogs.print(bLogs.Translate("startup_2") .. "\n")

	bLogs.AlwaysIgnore = false

	bLogs.Menu = bLogs.vgui.Create("DFrame",{["AnimateIn"] = true,["AnimateOut"] = true,["BackgroundColor"] = Color(26,26,26),["OnClose"] = function()
		if (IsValid(bLogs.ShowPlayers)) then
			bLogs.ShowPlayers:Close()
			hook.Run("blogs_menuclosed")
		end
	end})

	if (1152 > (ScrW() - 50)) then
		bLogs.Menu:SetWide(ScrW() - 50)
	else
		bLogs.Menu:SetWide(1152)
	end
	if (648 > (ScrH() - 50)) then
		bLogs.Menu:SetTall(ScrH() - 50)
	else
		bLogs.Menu:SetTall(648)
	end
	bLogs.Menu:Center()
	bLogs.Menu:bLogsSetup()
	bLogs.Menu:bLogsTitle("Logs | " .. _G.bLogsVersion .. " | " .. table.Random(bLogs.Splashes or {(bLogs.Translate("loading") .. "...")}))

	bLogs.Menu.TopTabs = bLogs.vgui.Create("bLogsTabs",bLogs.Menu,{["CustomFrame"] = true})
	bLogs.Menu.TopTabs:AlignTop(24)
	bLogs.Menu.TopTabs:SetSize(bLogs.Menu:GetWide(),35)

	bLogs.Menu.Logs = vgui.Create("DPanel")
	bLogs.Menu.Logs.onbLogsSetup = function()
		bLogs.Menu.Logs:SetParent(bLogs.Menu)
		bLogs.Menu.Logs:SetSize(bLogs.Menu:GetWide(),bLogs.Menu:GetTall() - 24 - 35)

		bLogs.Menu.Logs.LogContent = bLogs.CreateList(bLogs.Menu.Logs,true)
		bLogs.Menu.Logs.LogContent:SetSize(bLogs.Menu:GetWide() - 190,bLogs.Menu:GetTall() - 24 - 35 - 45)
		bLogs.Menu.Logs.LogContent:AlignBottom(45)
		bLogs.Menu.Logs.LogContent:AlignRight(0)
		bLogs.Menu.Logs.LogContent:SetMultiSelect(false)
		bLogs.Menu.Logs.LogContent.OnRowRightClick = function(_,line)
			line = bLogs.Menu.Logs.LogContent:GetLine(line)

			local function done(data2,should_load)
				local menu = DermaMenu()

				local ayy = menu:AddOption(bLogs.Translate("copyvalues"))
				ayy:SetImage("icon16/page_copy.png")
				function ayy:OnMousePressed() end

				menu:AddSpacer()

				local w = menu:AddOption(bLogs.Translate("copywithquotes"))
				local ws = '"'
				if (bLogs.CopyWithQuotes == true) then
					w:SetImage("icon16/accept.png")
				else
					w:SetImage("icon16/cancel.png")
				end
				function w:OnMousePressed()
					if (bLogs.CopyWithQuotes == true) then
						ws = ''
						w:SetImage("icon16/cancel.png")
						bLogs.CopyWithQuotes = false
					else
						ws = '"'
						w:SetImage("icon16/accept.png")
						bLogs.CopyWithQuotes = true
					end
				end

				local cl = menu:AddOption(bLogs.Translate("closeoncopy"))
				if (bLogs.CloseOnCopy == true) then
					cl:SetImage("icon16/accept.png")
				else
					cl:SetImage("icon16/cancel.png")
				end
				function cl:OnMousePressed()
					if (bLogs.CloseOnCopy == true) then
						cl:SetImage("icon16/cancel.png")
						bLogs.CloseOnCopy = false
					else
						cl:SetImage("icon16/accept.png")
						bLogs.CloseOnCopy = true
					end
				end

				local cli = menu:AddOption(bLogs.Translate("closeloginfooncopy"))
				if (bLogs.CloseInfoOnCopy == true) then
					cli:SetImage("icon16/accept.png")
				else
					cli:SetImage("icon16/cancel.png")
				end
				function cli:OnMousePressed()
					if (bLogs.CloseInfoOnCopy == true) then
						cli:SetImage("icon16/cancel.png")
						bLogs.CloseInfoOnCopy = false
					else
						cli:SetImage("icon16/accept.png")
						bLogs.CloseInfoOnCopy = true
					end
				end

				local function sSetClipboardText(txt)
					SetClipboardText(ws .. txt .. ws)
					if (bLogs.CloseOnCopy == true) then
						bLogs.Menu:Close()
					end
					if (bLogs.CloseInfoOnCopy == true) then
						bLogs.Menu.LogInfo:Close()
					end
				end

				local data
				if (data2) then
					data = util.JSONToTable(data2)
				end

				menu:AddSpacer()

				for _,v in pairs(line.Info) do
					local ply = player.GetBySteamID64(v)
					if (IsValid(ply)) then
						menu:AddOption("Nick: " .. ply:Nick(),function() sSetClipboardText(ply:Nick()) end):SetImage("icon16/user.png")
					end
					if (data) then
						for _,x in pairs(data.response.players) do
							if (x.steamid == v) then
								menu:AddOption("SteamName: " .. x.personaname,function() sSetClipboardText(x.personaname) end):SetImage("icon16/user_red.png")
								break
							end
						end
					elseif (DarkRP and IsValid(ply)) then
						menu:AddOption("SteamName: " .. ply:SteamName(),function() sSetClipboardText(ply:SteamName()) end):SetImage("icon16/user_red.png")
					end
					if (IsValid(ply)) then
						menu:AddOption("SteamID: " .. ply:SteamID(),function() sSetClipboardText(ply:SteamID()) end):SetImage("icon16/tag_blue.png")
					end
					menu:AddOption("SteamID64: " .. v,function() sSetClipboardText(v) end):SetImage("icon16/tag_red.png")
					if (#line.Info > 1 and i ~= #line.Info) then
						menu:AddSpacer()
					end
				end

				menu:AddSpacer()
				menu:AddOption(bLogs.Translate("cancel")):SetImage("icon16/cancel.png")

				if (data2 ~= nil) then
					if (not data2) then
						menu:AddSpacer()
						local thing = menu:AddOption(bLogs.Translate("loading")):SetImage("icon16/information.png")
					elseif (not data and data2) then
						menu:AddSpacer()
						local thing = menu:AddOption(bLogs.Translate("failed")):SetImage("icon16/delete.png")
					end
				end

				menu:Open()
			end
			local lineInfo = {}
			for _,v in pairs(line.Info) do
				if (IsValid(player.GetBySteamID64(v))) then
					table.insert(lineInfo,v)
				end
			end
			if (#lineInfo == 0) then
				done("")
				http.Fetch("http://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key=72CB41ADBA562F3EFD26E2AA2BCDD55C&steamids=" .. table.concat(lineInfo,","),done,done)
			else
				done()
			end
		end

		bLogs.Menu.PagePanel = vgui.Create("DPanel",bLogs.Menu.Logs)
		bLogs.Menu.PagePanel:SetVisible(false)
		bLogs.Menu.PagePanel:SetSize(bLogs.Menu:GetWide() - 190 - 16,26)
		bLogs.Menu.PagePanel:AlignTop(34)
		bLogs.Menu.PagePanel:AlignRight(16)
		bLogs.Menu.PagePanel.Paint = function(self)
			surface.SetDrawColor(Color(242,242,242))
			surface.DrawRect(0,0,self:GetWide(),self:GetTall())

			surface.SetDrawColor(Color(206,206,206))
			surface.DrawOutlinedRect(0,0,self:GetWide(),self:GetTall())
		end

		bLogs.Menu.PagePanel.Prev = vgui.Create("DButton",bLogs.Menu.PagePanel)
		bLogs.Menu.PagePanel.Prev:SetDisabled(true)
		bLogs.Menu.PagePanel.Prev:SetSize(35,20)
		bLogs.Menu.PagePanel.Prev:AlignLeft(3)
		bLogs.Menu.PagePanel.Prev:CenterVertical()
		bLogs.Menu.PagePanel.Prev:SetText("<")
		bLogs.Menu.PagePanel.Prev:SetTextColor(Color(255,255,255))
		bLogs.Menu.PagePanel.Prev.Paint = btnPaintNoBorder
		bLogs.Menu.PagePanel.Prev.Think = function()
			if (not IsValid(bLogs.Menu)) then return end
			if (page > 1) then
				bLogs.Menu.PagePanel.Prev:SetDisabled(false)
			else
				bLogs.Menu.PagePanel.Prev:SetDisabled(true)
			end
		end
		bLogs.Menu.PagePanel.Prev.DoClick = function()
			bLogs.Menu.PagePanel.Next:SetDisabled(true)
			bLogs.Menu.PagePanel.Prev:SetDisabled(true)
			bLogs.Menu.PagePanel.PageSelector:SetDisabled(true)
			bLogs.Menu.PagePanel.PageSelector:SetValue("")
			bLogs.Menu.PagePanel.Info.Loading = true

			bLogs.Menu.Logs.LogContent:Clear()
			bLogs.Menu.Logs.LogContent:AddLine_("")
			bLogs.Menu.Logs.LogContent:AddLine_("","",bLogs.Translate("receivinginfo"))

			page = page - 1
			net.Start("blogs_sendreceive_page")
				net.WriteString(logger_)
				net.WriteDouble(page)
				if (logger_ == "Search") then
					net.WriteString(searchfor_)
					net.WriteString(searchmodule_)
				end
			net.SendToServer()
		end


		bLogs.Menu.PagePanel.Next = vgui.Create("DButton",bLogs.Menu.PagePanel)
		bLogs.Menu.PagePanel.Next:SetDisabled(true)
		bLogs.Menu.PagePanel.Next:SetSize(35,20)
		bLogs.Menu.PagePanel.Next:AlignLeft(41)
		bLogs.Menu.PagePanel.Next:CenterVertical()
		bLogs.Menu.PagePanel.Next:SetText(">")
		bLogs.Menu.PagePanel.Next:SetTextColor(Color(255,255,255))
		bLogs.Menu.PagePanel.Next.Paint = btnPaintNoBorder
		bLogs.Menu.PagePanel.Next.DoClick = function()
			bLogs.Menu.PagePanel.Next:SetDisabled(true)
			bLogs.Menu.PagePanel.Prev:SetDisabled(true)
			bLogs.Menu.PagePanel.PageSelector:SetDisabled(true)
			bLogs.Menu.PagePanel.PageSelector:SetValue("")
			bLogs.Menu.PagePanel.Info.Loading = true

			bLogs.Menu.Logs.LogContent:Clear()
			bLogs.Menu.Logs.LogContent:AddLine_("")
			bLogs.Menu.Logs.LogContent:AddLine_("","",bLogs.Translate("receivinginfo"))

			page = page + 1
			net.Start("blogs_sendreceive_page")
				net.WriteString(logger_)
				net.WriteDouble(page)
				if (logger_ == "Search") then
					net.WriteString(searchfor_)
					net.WriteString(searchmodule_)
				end
			net.SendToServer()
		end

		bLogs.Menu.PagePanel.Info = vgui.Create("DLabel",bLogs.Menu.PagePanel)
		bLogs.Menu.PagePanel.Info:SetTextColor(Color(0,0,0))
		bLogs.Menu.PagePanel.Info:SetAutoStretchVertical(true)
		bLogs.Menu.PagePanel.Info.Think = function()
			if (not IsValid(bLogs.Menu)) then return end
			if (bLogs.Menu.PagePanel.Info.Loading == true) then
				bLogs.Menu.PagePanel.Info:SetText((bLogs.Translate("loading") .. "..."))
			else
				local l = ""
				if (tonumber(bLogs.Menu.Logs.LogContent.PageCount)) then
					if (tonumber(bLogs.Menu.Logs.LogContent.PageCount) > 1000) then
						l = " - That's a lot! You might want to clear the logs."
					end
				end
				bLogs.Menu.PagePanel.Info:SetText("Viewing " .. (bLogs.Menu.Logs.LogContent.LogCount or "X") .. " logs | Pages: " .. (bLogs.Menu.Logs.LogContent.PageCount or "X") .. l)
			end
			bLogs.Menu.PagePanel.Info:SizeToContents()
			bLogs.Menu.PagePanel.Info:AlignLeft(41 + 35 + 3 + 75 + 5)
			bLogs.Menu.PagePanel.Info:CenterVertical()
		end

		bLogs.Menu.PagePanel.PageSelector = vgui.Create("DTextEntry",bLogs.Menu.PagePanel)
		bLogs.Menu.PagePanel.PageSelector:SetNumeric(true)
		bLogs.Menu.PagePanel.PageSelector:SetDisabled(true)
		bLogs.Menu.PagePanel.PageSelector:SetValue("Page 1")
		bLogs.Menu.PagePanel.PageSelector:SetSize(75,20)
		bLogs.Menu.PagePanel.PageSelector:AlignLeft(41 + 35 + 3)
		bLogs.Menu.PagePanel.PageSelector:CenterVertical()
		bLogs.Menu.PagePanel.PageSelector.OldValue = "Page 1"
		function bLogs.Menu.PagePanel.PageSelector:OnEnter()
			local page_ = tonumber((string.gsub(bLogs.Menu.PagePanel.PageSelector:GetValue(),"Page%s","")))

			if (not page) then
				bLogs.Menu.PagePanel.PageSelector:SetValue(bLogs.Menu.PagePanel.PageSelector.OldValue)
				return
			end
			if ((page_ or 0) < 1) then
				bLogs.Menu.PagePanel.PageSelector:SetValue(bLogs.Menu.PagePanel.PageSelector.OldValue)
				return
			end
			if ((page_ or 1) > (bLogs.Menu.Logs.LogContent.PageCount or -1)) then
				bLogs.Menu.PagePanel.PageSelector:SetValue(bLogs.Menu.PagePanel.PageSelector.OldValue)
				return
			end

			page = page_

			bLogs.Menu.PagePanel.Next:SetDisabled(true)
			bLogs.Menu.PagePanel.Prev:SetDisabled(true)
			bLogs.Menu.PagePanel.PageSelector:SetDisabled(true)
			bLogs.Menu.PagePanel.PageSelector:SetValue("")
			bLogs.Menu.PagePanel.Info.Loading = true

			bLogs.Menu.Logs.LogContent:Clear()
			bLogs.Menu.Logs.LogContent:AddLine_("")
			bLogs.Menu.Logs.LogContent:AddLine_("","",bLogs.Translate("receivinginfo"))

			net.Start("blogs_sendreceive_page")
				net.WriteString(logger_)
				net.WriteDouble(page)
				if (logger_ == "Search") then
					net.WriteString(searchfor_)
					net.WriteString(searchmodule_)
				end
			net.SendToServer()
		end

		function bLogs.Menu.PagePanel.PageSelector:OnLoseFocus()
			bLogs.Menu.PagePanel.PageSelector:SetValue(bLogs.Menu.PagePanel.PageSelector.OldValue)
		end
		function bLogs.Menu.PagePanel.PageSelector:OnGetFocus()
			bLogs.Menu.PagePanel.PageSelector:SetValue("")
		end

		bLogs.Menu.Logs.SavePanel = vgui.Create("DPanel",bLogs.Menu.Logs)
		bLogs.Menu.Logs.SavePanel:SetSize(bLogs.Menu.Logs.LogContent:GetWide(),45)
		bLogs.Menu.Logs.SavePanel:AlignBottom(0)
		bLogs.Menu.Logs.SavePanel:AlignRight(0)
		bLogs.Menu.Logs.SavePanel.Paint = function() end

		bLogs.Menu.Logs.SavePanel.SavingButton = vgui.Create("DButton",bLogs.Menu.Logs.SavePanel)
		bLogs.Menu.Logs.SavePanel.SavingButton:SetDisabled(true)
		bLogs.Menu.Logs.SavePanel.SavingButton:SetTextColor(Color(255,255,255))
		bLogs.Menu.Logs.SavePanel.SavingButton:SetTall(30)
		bLogs.Menu.Logs.SavePanel.SavingButton:SetText(bLogs.Translate("save"))
		bLogs.Menu.Logs.SavePanel.SavingButton:SetFont("blogs_roboto16")
		bLogs.Menu.Logs.SavePanel.SavingButton:SizeToContentsX()
		bLogs.Menu.Logs.SavePanel.SavingButton:CenterVertical()
		bLogs.Menu.Logs.SavePanel.SavingButton:SetWide(120)
		bLogs.Menu.Logs.SavePanel.SavingButton:AlignLeft(5)
		bLogs.Menu.Logs.SavePanel.SavingButton.Paint = btnPaint
		bLogs.Menu.Logs.SavePanel.SavingButton.DoClick = function()
			bLogs.Menu.SavePopup:Open()
		end

		bLogs.Menu.Logs.SavePanel.CancelSearch = vgui.Create("DButton",bLogs.Menu.Logs.SavePanel)
		bLogs.Menu.Logs.SavePanel.CancelSearch:SetDisabled(true)
		bLogs.Menu.Logs.SavePanel.CancelSearch:SetTextColor(Color(255,255,255))
		bLogs.Menu.Logs.SavePanel.CancelSearch:SetTall(30)
		bLogs.Menu.Logs.SavePanel.CancelSearch:SetText(bLogs.Translate("cancelsearch"))
		bLogs.Menu.Logs.SavePanel.CancelSearch:SetFont("blogs_roboto16")
		bLogs.Menu.Logs.SavePanel.CancelSearch:SizeToContentsX()
		bLogs.Menu.Logs.SavePanel.CancelSearch:CenterVertical()
		bLogs.Menu.Logs.SavePanel.CancelSearch:SetWide(bLogs.Menu.Logs.SavePanel.CancelSearch:GetWide() + 20)
		bLogs.Menu.Logs.SavePanel.CancelSearch:AlignRight(5)
		bLogs.Menu.Logs.SavePanel.CancelSearch.Paint = btnPaint
		bLogs.Menu.Logs.SavePanel.CancelSearch.DoClick = function(ISITFROMTHINGY)
			bLogs.Menu.Logs.SavePanel.CancelSearch:SetDisabled(true)

			if (bLogs.Menu.Logs.SavePanel.CancelSearch.Refresh == true) then
				bLogs.Menu.Logs.LogContent:LoadLogger(bLogs.Menu.Logs.LogContent.CurrentLogger)
				bLogs.Menu.Logs.SavePanel.CancelSearch.Refresh = false
				return
			end

			if (ISITFROMTHINGY ~= "YES IT IS") then
				bLogs.Menu.Logs.SavePanel.SearchBox:SetText(bLogs.Translate("searchbar"))
				bLogs.Menu.Logs.SavePanel.SearchBox.placeholdered = false
			end

			bLogs.Menu.Logs.LogContent:Clear_()
			bLogs.Menu.Logs.LogContent:AddLine_("")
			for _,v in pairs(bLogs.Menu.Logs.LogContent.StoreSearch) do
				local newLine
				newLine = bLogs.Menu.Logs.LogContent:AddLine_(unpack(v[1]))
				newLine.Info = v[2]
				newLine.Module = v[3]
			end
			bLogs.Menu.PagePanel:SetVisible(true)
		end

		bLogs.Menu.Logs.SavePanel.AdvancedSearch = vgui.Create("DButton",bLogs.Menu.Logs.SavePanel)
		bLogs.Menu.Logs.SavePanel.AdvancedSearch:SetDisabled(true)
		bLogs.Menu.Logs.SavePanel.AdvancedSearch:SetTextColor(Color(255,255,255))
		bLogs.Menu.Logs.SavePanel.AdvancedSearch:SetTall(30)
		bLogs.Menu.Logs.SavePanel.AdvancedSearch:SetText(bLogs.Translate("fullsearch"))
		bLogs.Menu.Logs.SavePanel.AdvancedSearch:SetFont("blogs_roboto16")
		bLogs.Menu.Logs.SavePanel.AdvancedSearch:SizeToContentsX()
		bLogs.Menu.Logs.SavePanel.AdvancedSearch:CenterVertical()
		bLogs.Menu.Logs.SavePanel.AdvancedSearch:SetWide(bLogs.Menu.Logs.SavePanel.AdvancedSearch:GetWide() + 20)
		bLogs.Menu.Logs.SavePanel.AdvancedSearch:AlignRight(bLogs.Menu.Logs.SavePanel.CancelSearch:GetWide() + 10)
		bLogs.Menu.Logs.SavePanel.AdvancedSearch.Paint = btnPaint
		bLogs.Menu.Logs.SavePanel.AdvancedSearch.DoClick = function()
			bLogs.Menu.Logs.LogContent:Clear_()
			bLogs.Menu.Logs.LogContent:LoadLogger("Search")
		end

		bLogs.Menu.Logs.SavePanel.SearchBox = vgui.Create("DTextEntry",bLogs.Menu.Logs.SavePanel)
		bLogs.Menu.Logs.SavePanel.SearchBox:SetDisabled(true)
		bLogs.Menu.Logs.SavePanel.SearchBox:SetEditable(false)
		bLogs.Menu.Logs.SavePanel.SearchBox:SetSize(bLogs.Menu.Logs.SavePanel:GetWide() - bLogs.Menu.Logs.SavePanel.SavingButton:GetWide() - bLogs.Menu.Logs.SavePanel.AdvancedSearch:GetWide() - bLogs.Menu.Logs.SavePanel.CancelSearch:GetWide() - 25,30)
		bLogs.Menu.Logs.SavePanel.SearchBox:AlignRight(5 + bLogs.Menu.Logs.SavePanel.CancelSearch:GetWide() + bLogs.Menu.Logs.SavePanel.AdvancedSearch:GetWide() + 10)
		bLogs.Menu.Logs.SavePanel.SearchBox:CenterVertical()
		bLogs.Menu.Logs.SavePanel.SearchBox:SetDrawBorder(false)
		bLogs.Menu.Logs.SavePanel.SearchBox:SetFont("blogs_roboto16")
		bLogs.Menu.Logs.SavePanel.SearchBox:SetText(bLogs.Translate("searchbar"))
		bLogs.Menu.Logs.SavePanel.SearchBox:SetUpdateOnType(true)
		bLogs.Menu.Logs.SavePanel.SearchBox.OnGetFocus = function()
			if (bLogs.Menu.Logs.SavePanel.SearchBox:GetText() == bLogs.Translate("searchbar") and (bLogs.Menu.Logs.SavePanel.SearchBox.placeholdered == nil or bLogs.Menu.Logs.SavePanel.SearchBox.placeholdered == false)) then
				bLogs.Menu.Logs.SavePanel.SearchBox.placeholdered = true
				bLogs.Menu.Logs.SavePanel.SearchBox:SetText("")
			end
		end
		function bLogs.Menu.Logs.SavePanel.SearchBox:OnValueChange()
			bLogs.Menu.Logs.SavePanel.CancelSearch:SetDisabled(false)
			if (bLogs.Menu.Logs.LogContent.CurrentLogger ~= "File") then
				bLogs.Menu.Logs.SavePanel.AdvancedSearch:SetDisabled(false)
			end

			local txt = bLogs.Menu.Logs.SavePanel.SearchBox:GetText()
			if (txt == "") then
				bLogs.Menu.Logs.SavePanel.CancelSearch.DoClick("YES IT IS")
			else
				bLogs.Menu.Logs.LogContent:Clear_()
				local added = 0
				for _,v in pairs(bLogs.Menu.Logs.LogContent.StoreSearch) do
					if (string.find(string.lower(v[1][1]),string.lower(bLogs.Menu.Logs.SavePanel.SearchBox:GetText())) or string.find(string.lower(v[1][3]),string.lower(bLogs.Menu.Logs.SavePanel.SearchBox:GetText())) or string.find(string.lower(v[1][2]),string.lower(bLogs.Menu.Logs.SavePanel.SearchBox:GetText()))) then
						local newLine
						newLine = bLogs.Menu.Logs.LogContent:AddLine_(unpack(v[1]))
						newLine.Info = v[2]
						newLine.Module = v[3]
						added = added + 1
					end
				end
				if (added == 0) then
					bLogs.Menu.Logs.LogContent:AddLine_("","",bLogs.Translate("noqueries"))
				end
			end
		end

		local cat_table = bLogs.CreateCategories(bLogs.Menu:GetWide() - (bLogs.Menu.Logs.LogContent:GetWide()),bLogs.Menu.Logs:GetTall())
		local toolbarContainer = cat_table[2]
		bLogs.Menu.Toolbar = cat_table[1]

		bLogs.Menu.Toolbar:AddItem(bLogs.Translate("All"),Color(255,255,255),function()
			bLogs.Menu.Logs.LogContent:LoadLogger("All")
		end)
		bLogs.Menu.Toolbar:AddItem(bLogs.Translate("player_lookup"),Color(150,0,255),function()
			bLogs.Menu.Logs.LogContent:LoadLogger("PlayerLookup")
		end)
		bLogs.Menu.Toolbar:AddItem(bLogs.Translate("steamid_converter"),Color(150,0,255),function()
			gui.OpenURL("http://www.steamid.ru/")
		end)

		for _,v in pairs(bLogs.Hooks.Categories) do

			if (#bLogs.Hooks.Nice ~= 0) then
				local added = false
				for _,_v in pairs(bLogs.Hooks.Nice) do
					if (_v[3] ~= false) then
						if (_v[2] == v[1]) then
							if (bLogs.HasAccess(_v[1])) then
								local allow = true
								if (bLogs.CustomConfigRaw.Permissions.Loggers[_v[1]] ~= nil) then
									if (bLogs.CustomConfigRaw.Permissions.Loggers[_v[1]].Disabled == true) then
										allow = false
									end
								end
								if (allow == true) then
									if (added == false) then added = true
										bLogs.Menu.Toolbar:AddCategory(v[1],v[2],v[3])
									end
									bLogs.Menu.Toolbar:AddItem(_v[1],v[2],function()
										bLogs.Menu.Logs.LogContent:LoadLogger(_v[1])
									end)
								end
							end
						end
					end
				end

			end

		end

		local t = bLogs.Menu.Logs.LogContent:AddColumn_(bLogs.Translate("time"))
		local l = bLogs.Menu.Logs.LogContent:AddColumn_(bLogs.Translate("logger"))
		local logc = bLogs.Menu.Logs.LogContent:AddColumn_(bLogs.Translate("log"))
		l:SetWidth(0)
		t:SetWidth(170)
		logc:SetWidth(bLogs.Menu.Logs.LogContent:GetWide() - 16 - 170)

		bLogs.Menu.Logs.LogContent.Spacer = bLogs.Menu.Logs.LogContent:AddColumn_("")

		bLogs.Menu.Logs.LogContent:AddLine_("","",bLogs.Translate("selectlogger"))

		function bLogs.Menu.Logs.LogContent:LoadLogger(logger,file__)
			page = 1
			if (logger ~= "Search") then
				bLogs.Menu.Logs.SavePanel.CancelSearch.Refresh = false
				bLogs.Menu.Logs.LogContent.CurrentLogger = logger
			else
				bLogs.Menu.Logs.SavePanel.CancelSearch.Refresh = true
			end

			bLogs.Menu.SavePopup.Page1:SetValue("Page 1")
			bLogs.Menu.SavePopup.Page2:SetValue("Page 1")

			bLogs.Menu.SavePopup.Text2:AlignLeft(5)
			bLogs.Menu.SavePopup.Text2:SetText(bLogs.Translate("onlysave_1") .. ' "' .. logger .. '" ' .. bLogs.Translate("onlysave_2"))
			bLogs.Menu.SavePopup.Text2:SizeToContents()

			if (logger == "All") then
				t:SetWidth(170)
				logc:SetWidth(bLogs.Menu.Logs.LogContent:GetWide() - 16 - 170 - 95)
				l:SetWidth(95)
			else
				l:SetWidth(0)
				t:SetWidth(180)
				logc:SetWidth(bLogs.Menu.Logs.LogContent:GetWide() - 16 - 180)
			end

			searchfor_ = nil
			searchmodule_ = nil
			if (logger == "Search") then
				searchfor_ = bLogs.Menu.Logs.SavePanel.SearchBox:GetText()
				searchmodule_ = (logger_ or "All")
			end
			logger_ = logger
			bLogs.Menu.Logs.SavePanel.SavingButton:SetDisabled(true)
			bLogs.Menu.Logs.SavePanel.SavingButton:SetDisabled(true)
			bLogs.Menu.Logs.SavePanel.SearchBox:SetDisabled(true)
			bLogs.Menu.Logs.SavePanel.AdvancedSearch:SetDisabled(true)
			bLogs.Menu.Logs.SavePanel.SearchBox:SetEditable(false)

			bLogs.Menu.PagePanel.Next:SetDisabled(true)
			bLogs.Menu.PagePanel.Prev:SetDisabled(true)
			bLogs.Menu.PagePanel.PageSelector:SetDisabled(true)
			bLogs.Menu.PagePanel.PageSelector:SetValue("")
			bLogs.Menu.PagePanel.Info.Loading = true

			bLogs.Menu.Logs.LogContent:Clear_()
			bLogs.Menu.Logs.LogContent:AddLine_("","",bLogs.Translate("receivinginfo"))

			local function do_it(is_local,file_)
				local module
				local pages
				local dataNum
				local logs
				local should_clear

				if (is_local ~= true) then
					module = net.ReadString()
					pages = net.ReadDouble()
					if (module == "No permission") then
						bLogs.Menu.Logs.LogContent:Clear_()
						bLogs.Menu.Logs.LogContent:AddLine_("","",bLogs.Translate("nopermission"),"")
						return
					end
					dataNum = net.ReadDouble()
					logs = net.ReadData(dataNum)
					should_clear = net.ReadBool()
					logs = util.Decompress(logs)
				else
					logs = file.Read(file_,"DATA")
					logs = util.Decompress(logs)
				end
				if (logs == nil) then return end
				logs = util.JSONToTable(logs)
				if (is_local == true) then
					pages = math.ceil(#logs / 60)
					local process = table.Copy(logs)
					logs = {}
					for i,v in pairs(process) do
						if ((i - 1) >= (60 * (page - 1)) and (i - 1) <= (60 * (page - 1)) + 60) then
							logs[i] = v
						end
					end
				end

				if (IsValid(bLogs.Menu.SavePopup.Page1)) then
					bLogs.Menu.SavePopup.Page1:Clear()
					bLogs.Menu.SavePopup.Page1:SetValue(bLogs.Translate("page") .. " 1")
					bLogs.Menu.SavePopup.Page1:SetValue(bLogs.Translate("page") .. " " .. page)
					for i=1,pages,1 do
						bLogs.Menu.SavePopup.Page1:AddChoice(bLogs.Translate("page") .. " " .. i)
					end
				end
				if (IsValid(bLogs.Menu.SavePopup.Page2)) then
					bLogs.Menu.SavePopup.Page2:Clear()
					bLogs.Menu.SavePopup.Page2:SetValue(bLogs.Translate("page") .. " 1")
					bLogs.Menu.SavePopup.Page2:SetValue(bLogs.Translate("page") .. " " .. page)
					for i=1,pages,1 do
						bLogs.Menu.SavePopup.Page2:AddChoice(bLogs.Translate("page") .. " " .. i)
					end
				end

				bLogs.Menu.PagePanel.PageSelector:SetDisabled(false)
				bLogs.Menu.PagePanel.Info.Loading = false

				bLogs.Menu.Logs.LogContent.LogCount = #logs
				bLogs.Menu.Logs.LogContent.PageCount = pages

				if (pages > 1 and page ~= pages) then
					bLogs.Menu.PagePanel.Next:SetDisabled(false)
				end
				bLogs.Menu.PagePanel.PageSelector:SetValue(bLogs.Translate("page") .. " " .. (page or 1))
				bLogs.Menu.PagePanel.PageSelector.OldValue = bLogs.Translate("page") .. " " .. (page or 1)

				bLogs.Menu.Logs.LogContent:Clear_()
				bLogs.Menu.Logs.LogContent:AddLine_("","","")
				bLogs.Menu.PagePanel:SetVisible(true)

				for i,v in pairs(bLogs.Menu.Logs.LogContent.Columns) do
					if (v.Header:GetText() == "") then
						table.remove(bLogs.Menu.Logs.LogContent.Columns,i)
						v:Remove()
						bLogs.Menu.Logs.LogContent:PerformLayout()
					end
				end
				bLogs.Menu.Logs.LogContent.Spacer = bLogs.Menu.Logs.LogContent:AddColumn_("")
				bLogs.Menu.Logs.LogContent.Spacer:SetFixedWidth(16)

				bLogs.Menu.Logs.LogContent.StoreSearch = {}

				if (#logs > 0) then
					for i,v in pairs(logs) do
						local newLine
						if (v.txt == nil) then
							if (v.ip ~= nil) then
								local str_ = "Last Name: " .. v.lastname .. " | SteamID: " .. v.steamid .. " | SteamID64: " .. v.steamid64 .. " | IP Address: " .. v.ip
								newLine = bLogs.Menu.Logs.LogContent:AddLine_(bLogs.FormatTime(v.updated),"PlayerLookup",str_)
								newLine.Info = {v.steamid64}
								newLine.Module = "PlayerLookup"
								table.insert(bLogs.Menu.Logs.LogContent.StoreSearch,{{bLogs.FormatTime(v.time),"PlayerLookup",str_},newLine.Info,"PlayerLookup"})
							else
								local str_ = "Last Name: " .. v.lastname .. " | SteamID: " .. v.steamid .. " | SteamID64: " .. v.steamid64
								newLine = bLogs.Menu.Logs.LogContent:AddLine_(bLogs.FormatTime(v.updated),"PlayerLookup",str_)
								newLine.Info = {v.steamid64}
								newLine.Module = "PlayerLookup"
								table.insert(bLogs.Menu.Logs.LogContent.StoreSearch,{{bLogs.FormatTime(v.time),"PlayerLookup",str_},newLine.Info,"PlayerLookup"})
							end
						else
							local esc_str,logs_snip = bLogs.RemoveEscapables(v.txt,nil,true)
							esc_str = string.gsub(esc_str,"\n"," // ")
							newLine = bLogs.Menu.Logs.LogContent:AddLine_(bLogs.FormatTime(v.time),v.module,esc_str)
							newLine.Info = util.JSONToTable(v.involved)
							newLine.Module = v.module
							if (#logs_snip > 0) then
								newLine.Copyables = {}
								for _,sn in pairs(logs_snip) do

								end
							end
							table.insert(bLogs.Menu.Logs.LogContent.StoreSearch,{{bLogs.FormatTime(v.time),v.module,bLogs.RemoveEscapables(v.txt)},newLine.Info,newLine.Module})
						end
					end
					bLogs.Menu.Logs.SavePanel.SearchBox:SetDisabled(false)
					bLogs.Menu.Logs.SavePanel.AdvancedSearch:SetDisabled(true)
					if (is_local ~= true) then
						bLogs.Menu.Logs.SavePanel.SavingButton:SetDisabled(false)
					else
						bLogs.Menu.Logs.SavePanel.SavingButton:SetDisabled(true)
					end
					bLogs.Menu.Logs.SavePanel.SearchBox:SetEditable(true)
				else
					bLogs.Menu.Logs.LogContent:AddLine_("","",bLogs.Translate("nologs"))
				end

				if (should_clear == true) then
					bLogs.Menu.Logs.LogContent.VBar:SetScroll(bLogs.Menu.Logs.LogContent.VBar.CanvasSize - 1)
				end
				bLogs.Menu.Logs.LogContent.Loading = false
			end
			net.Receive("blogs_sendreceive_page",do_it)

			if (logger == "File") then
				do_it(true,file__)
			else
				net.Start("blogs_sendreceive_page")
					net.WriteString(logger)
					net.WriteDouble(page)
					if (logger == "Search") then
						net.WriteString(bLogs.Menu.Logs.SavePanel.SearchBox:GetText())
						net.WriteString(searchmodule_)
					end
				net.SendToServer()
			end

			if (logger ~= "Search") then
				bLogs.Menu.Logs.SavePanel.SearchBox:SetText(bLogs.Translate("searchbar"))
				bLogs.Menu.Logs.SavePanel.SearchBox.placeholdered = false
			else
				bLogs.Menu.Logs.SavePanel.SearchBox:SetDisabled(true)
				bLogs.Menu.Logs.SavePanel.SearchBox:SetEditable(false)
			end
		end

		local tbl = {}
		if (bLogs.Hooks ~= nil) then
			tbl = bLogs.Hooks.Nice
		end
	end
	bLogs.Menu.TopTabs:AddTab(bLogs.Translate("logs"),bLogs.Menu.Logs)

	bLogs.Menu.Saves = vgui.Create("DPanel")
	bLogs.Menu.Saves.onbLogsSetup = function()
		bLogs.Menu.Saves:SetParent(bLogs.Menu)
		bLogs.Menu.Saves:SetSize(bLogs.Menu:GetWide(),bLogs.Menu:GetTall() - 24 - 35)

		bLogs.Menu.Saves.SaveContent = vgui.Create("DHTML",bLogs.Menu.Saves)
		bLogs.Menu.Saves.SaveContent:SetSize(bLogs.Menu:GetWide() - 290,bLogs.Menu:GetTall() - 24 - 35)
		bLogs.Menu.Saves.SaveContent:AlignBottom(0)
		bLogs.Menu.Saves.SaveContent:AlignRight(0)
		local prefix = [[<!DOCTYPE html><html><head><style>@import url(https://fonts.googleapis.com/css?family=Open+Sans);body,html{background-color: #fff;color: #000;font-family: 'Open Sans', sans-serif;font-size: 12px;white-space: pre-line;word-wrap: break-word;}</style></head><body>]]
		local suffix = [[</body></html>]]
		bLogs.Menu.Saves.SaveContent:SetHTML(prefix .. bLogs.Translate("savesplash") .. suffix)

		bLogs.Menu.Saves.OpenSave = bLogs.CreateList(bLogs.Menu.Saves)
		bLogs.Menu.Saves.OpenSave:SetSize(bLogs.Menu:GetWide() - (bLogs.Menu.Saves.SaveContent:GetWide()) - 1,bLogs.Menu.Saves:GetTall())
		bLogs.Menu.Saves.OpenSave:AlignLeft(0)
		bLogs.Menu.Saves.OpenSave:AlignBottom(0)
		bLogs.Menu.Saves.OpenSave:AddColumn_(bLogs.Translate("filename"))
		bLogs.Menu.Saves.OpenSave:AddColumn_(bLogs.Translate("type"))

		bLogs.Menu.Saves.OpenSave.OnRowRightClick = function(_,i,line)
			if (line:GetValue(1) == bLogs.Translate("nosaves")) then return end
			local line_options = DermaMenu()
			line_options:AddOption("Delete",function()
				Derma_Query(bLogs.Translate("deleteconfirm_1"),bLogs.Translate("deleteconfirm_2"),bLogs.Translate("deleteconfirm_3"),function()
					bLogs.Menu.Saves.OpenSave:RemoveLine(i)
					if (line:GetValue(2) == bLogs.Translate("human")) then
						file.Delete("blogs/logs/" .. line:GetValue(1) .. ".txt")
					else
						file.Delete("blogs/logs/json/" .. line:GetValue(1) .. ".txt")
					end
					if (#bLogs.Menu.Saves.OpenSave:GetLines() == 0) then
						bLogs.Menu.Saves.OpenSave:AddLine_(bLogs.Translate("nosaves"),"")
					end
				end,bLogs.Translate("cancel"))
			end):SetIcon("icon16/delete.png")
			line_options:Open()
		end

		bLogs.Menu.Saves.OpenSave.OnRowSelected = function(_,_2,line)
			if (line:GetValue(2) == bLogs.Translate("human")) then
				bLogs.Menu.Saves.SaveContent:SetHTML(prefix .. file.Read("blogs/logs/" .. line:GetValue(1) .. ".txt","DATA") .. suffix)
			else
				bLogs.Menu.Logs.LogContent:LoadLogger("File","blogs/logs/json/" .. line:GetValue(1) .. ".txt")
				bLogs.Menu.TopTabs:SelectTab(1)
			end
		end

		function bLogs.Menu.Saves.OpenSave:RefreshSaves()
			local saves = file.Find("blogs/logs/*.txt","DATA")
			local jsonsaves = file.Find("blogs/logs/json/*.txt","DATA")
			if ((#saves + #jsonsaves) == 0) then
				bLogs.Menu.Saves.OpenSave:AddLine_(bLogs.Translate("nosaves"),"")
			else
				for _,v in pairs(saves) do
					local nl = bLogs.Menu.Saves.OpenSave:AddLine_(string.gsub(string.gsub(v,"blogs/logs/",""),".txt",""),"Human")
					function nl:OnMousePressed(mouse_button)
						if (mouse_button == MOUSE_RIGHT) then
							bLogs.Menu.Saves.OpenSave:OnRowRightClick(nl:GetID(),nl)
						else
							bLogs.Menu.Saves.OpenSave:OnClickLine(nl,true)
						end
					end
				end
				for _,v in pairs(jsonsaves) do
					local nl = bLogs.Menu.Saves.OpenSave:AddLine_(string.gsub(string.gsub(v,"blogs/logs/",""),".txt",""),bLogs.Translate("blogsonly"))
					function nl:OnMousePressed(mouse_button)
						if (mouse_button == MOUSE_RIGHT) then
							bLogs.Menu.Saves.OpenSave:OnRowRightClick(nl:GetID(),nl)
						else
							bLogs.Menu.Saves.OpenSave:OnClickLine(nl,true)
						end
					end
				end
			end
		end
		bLogs.Menu.Saves.OpenSave:RefreshSaves()
	end
	bLogs.Menu.TopTabs:AddTab(bLogs.Translate("savesfiles"),bLogs.Menu.Saves)

	if (bLogs.IsRoot()) then
		bLogs.Menu.Admin = vgui.Create("DPanel")
		bLogs.Menu.Admin.onbLogsSetup = function()
			bLogs.Menu.Admin:SetParent(bLogs.Menu)
			bLogs.Menu.Admin:SetSize(bLogs.Menu:GetWide(),bLogs.Menu:GetTall() - 24 - 35)

			local htmlprefix = [[<!DOCTYPE html>
	<html>
		<head>
			<style>
				@import url(https://fonts.googleapis.com/css?family=Roboto);

				body {
					background-color: #fff;
					color: #000;
					font-family: 'Roboto', sans-serif;
					font-size: 14px;
				}

				select {
					width: 100px;
				}
				.select2-dropdown {
					margin-left: 8px;
					margin-top: 5px;
				}

				.noselect {
					-webkit-touch-callout: none;
					-webkit-user-select: none;
					-khtml-user-select: none;
					-moz-user-select: none;
					-ms-user-select: none;
					user-select: none;
				}
			</style>
			<script src="http://code.jquery.com/jquery-latest.js"></script>
			<link href="http://cdnjs.cloudflare.com/ajax/libs/select2/4.0.1/css/select2.min.css" rel="stylesheet" />
			<script src="http://cdnjs.cloudflare.com/ajax/libs/select2/4.0.1/js/select2.min.js"></script>
		</head>
		<body>]]

			local htmlsuffix = [[<script>
				$(".setting").click(function() {
					console.savebLogsOption($(this).attr("name"),$(this).is(":checked"));
				});

				$(".setting_option").select2({
					minimumResultsForSearch: Infinity
				});

				$(".setting_option").on("select2:select",function() {
					console.savebLogsOption($(this).attr("name"),$(this).val(),true);
				});

				$(".setting_text").on("input",function() {
					console.savebLogsOption($(this).attr("name"),$(this).val());
				});
			</script>
		</body>
	</html>]]

			bLogs.Menu.AdminLeftTabs = bLogs.CreateCategories(bLogs.Menu:GetWide() - (bLogs.Menu.Logs.LogContent:GetWide()),bLogs.Menu.Logs:GetTall(),bLogs.Menu.Admin)[1]

			local settings = {}

			local made_category = false
			for i,v in pairs(bLogs.CustomConfigRaw.Categories) do
				if (made_category == false) then
					made_category = true
					bLogs.Menu.AdminLeftTabs:AddCategory(bLogs.Translate("settings"),v.Color)
				end
				bLogs.Menu.AdminLeftTabs:AddItem(i,v.Color,function()
					bLogs.Menu.Admin.PermissionsPanel:SetVisible(false)
					bLogs.Menu.Admin.OldConfigs:SetVisible(false)
					bLogs.Menu.AdminHTML:SetVisible(true)
					local formatted = ""
					for _i,_v in pairs(bLogs.CustomConfigRaw.Categories) do
						if (_i == i) then
							formatted = formatted .. v.Description .. "<br><br>"
							for setting_name,setting_table in pairs(v) do
								if (setting_name ~= "Color" and setting_name ~= bLogs.Translate("description")) then
									if (type(setting_table) == "table") then
										if (setting_table.Enabled ~= nil) then
											formatted = formatted .. [[<label><input class="setting" type="checkbox" name="]] .. _i .. "." .. setting_name
											if (setting_table.Enabled == true) then
												formatted = formatted .. [[" checked>]]
											else
												formatted = formatted .. [[">]]
											end
											formatted = formatted .. "&nbsp;" .. setting_table.ConfigName .. " (" .. setting_name .. ")"
											formatted = formatted .. "<br>" .. (setting_table.Help or "") .. "</label><br>"
										elseif (setting_table.Value ~= nil) then
											formatted = formatted .. [[<label><input class="setting_text" type="text" value=]] .. sql.SQLStr(setting_table.Value) .. [[ placeholder=]] .. sql.SQLStr(setting_name) .. [[ name=]] .. sql.SQLStr(_i .. "." .. setting_name) .. '><br>'
											formatted = formatted .. setting_table.ConfigName .. " (" .. setting_name .. ")"
											formatted = formatted .. "<br>" .. (setting_table.Help or "") .. "</label><br>"
										elseif (setting_table.Option ~= nil) then
											formatted = formatted .. "&nbsp;" .. setting_table.ConfigName .. " (" .. setting_name .. [[)<br>]]
											formatted = formatted .. [[<select class="setting_option" value=]] .. sql.SQLStr(setting_table.Option["true"]) .. [[ name=]] .. sql.SQLStr(_i .. "." .. setting_name) .. '>'
											for _,v in pairs(setting_table.Option) do
												if (type(v) == "table") then
													for _,x in pairs(v) do
														formatted = formatted .. "<option>" .. x .. "</div>"
													end
												else
													formatted = formatted .. "<option>" .. v .. "</div>"
												end
											end
											formatted = formatted .. "</select>"
											formatted = formatted .. "<br>" .. (string.gsub(setting_table.Help,"\n","<br>") or "") .. "<br>"
										end
										formatted = formatted .. "<br>"
									end
								end
							end
							break
						end
					end
					bLogs.Menu.AdminHTML:SetHTML(htmlprefix .. formatted .. htmlsuffix)
				end)
			end

			bLogs.Menu.Admin.SavePanel = vgui.Create("DPanel",bLogs.Menu.Admin)
			bLogs.Menu.Admin.SavePanel:SetSize(bLogs.Menu.Logs.LogContent:GetWide(),45)
			bLogs.Menu.Admin.SavePanel:AlignBottom(0)
			bLogs.Menu.Admin.SavePanel:AlignRight(0)
			bLogs.Menu.Admin.SavePanel.Paint = function() end

			bLogs.Menu.Admin.SavePanel.SavingButton = vgui.Create("DButton",bLogs.Menu.Admin.SavePanel)
			bLogs.Menu.Admin.SavePanel.SavingButton:SetDisabled(true)
			bLogs.Menu.Admin.SavePanel.SavingButton:SetTextColor(Color(255,255,255))
			bLogs.Menu.Admin.SavePanel.SavingButton:SetTall(30)
			bLogs.Menu.Admin.SavePanel.SavingButton:SetText(bLogs.Translate("save_config"))
			bLogs.Menu.Admin.SavePanel.SavingButton:SetFont("blogs_roboto16")
			bLogs.Menu.Admin.SavePanel.SavingButton:SizeToContentsX()
			bLogs.Menu.Admin.SavePanel.SavingButton:CenterVertical()
			bLogs.Menu.Admin.SavePanel.SavingButton:SetWide(120)
			bLogs.Menu.Admin.SavePanel.SavingButton:AlignLeft(5)
			bLogs.Menu.Admin.SavePanel.SavingButton.Paint = btnPaint
			bLogs.Menu.Admin.SavePanel.SavingButton.DoClick = function()
				for key,val in pairs(settings) do
					local e = string.Explode(".",key)
					local category = e[1]
					local configname = e[2]
					if (type(val) == "boolean") then
						bLogs.CustomConfigRaw["Categories"][category][configname].Enabled = val
					elseif (type(val) == "table") then
						bLogs.CustomConfigRaw["Categories"][category][configname].Option = val
					else
						bLogs.CustomConfigRaw["Categories"][category][configname].Value = val
					end
				end

				for category,category_table in pairs(bLogs.CustomConfigRaw.Categories) do
					for i,v in pairs(category_table) do
						if (i ~= "Description") then
							if (v.ConfigName ~= nil) then
								bLogs.CustomConfig[i] = v.Enabled or v.Value or v.Option
							end
						end
					end
				end

				net.Start("blogs_updateoptions")
					local settings_ = util.Compress(util.TableToJSON(settings))
					net.WriteDouble(#settings_)
					net.WriteData(settings_,#settings_)
				net.SendToServer()
				bLogs.Menu.Admin.SavePanel.SavingButton:SetDisabled(true)

				if (bLogs.AlwaysIgnore ~= true) then
					Derma_Query(bLogs.Translate("saved_1"),bLogs.Translate("saved_2"),bLogs.Translate("saved_3"),function()
						bLogs.Menu:Close()
						RunConsoleCommand("blogs_menu")
					end,bLogs.Translate("ignore"),function()
						bLogs.AlwaysIgnore = true
					end)
				end
			end

			bLogs.Menu.AdminHTMLUnder = vgui.Create("DPanel",bLogs.Menu.Admin)
			bLogs.Menu.AdminHTMLUnder:SetSize(bLogs.Menu:GetWide() - bLogs.Menu.AdminLeftTabs:GetWide(),bLogs.Menu.Logs:GetTall() - 45)
			bLogs.Menu.AdminHTMLUnder:AlignRight(0)
			bLogs.Menu.AdminHTMLUnder:AlignBottom(45)
			bLogs.Menu.AdminHTMLUnder.Paint = function(self)
				surface.SetDrawColor(Color(255,255,255))
				surface.DrawRect(0,0,self:GetWide(),self:GetTall())
			end

			bLogs.Menu.AdminHTML = vgui.Create("DHTML",bLogs.Menu.Admin)
			bLogs.Menu.AdminHTML:SetSize(bLogs.Menu:GetWide() - bLogs.Menu.AdminLeftTabs:GetWide(),bLogs.Menu.Logs:GetTall() - 45)
			bLogs.Menu.AdminHTML:AlignRight(0)
			bLogs.Menu.AdminHTML:AlignBottom(45)
			bLogs.Menu.AdminHTML:SetHTML(htmlprefix .. bLogs.Translate("selectsetting") .. htmlsuffix)
			bLogs.Menu.AdminHTML:AddFunction("console","savebLogsOption",function(key,val,isoption)
				if (isoption) then
					local e = string.Explode(".",key)
					if (settings[key] == nil) then
						settings[key] = {}
					end
					settings[key]["true"] = val
				else
					if (val == "true" or val == "false") then
						if (val == "true") then
							settings[key] = true
						else
							settings[key] = false
						end
					else
						settings[key] = val
					end
				end
				bLogs.Menu.Admin.SavePanel.SavingButton:SetDisabled(false)
			end)

			bLogs.Menu.Admin.OldConfigs = vgui.Create("DPanel",bLogs.Menu.Admin)
			bLogs.Menu.Admin.OldConfigs:SetVisible(false)
			bLogs.Menu.Admin.OldConfigs:SetSize(bLogs.Menu.Logs.LogContent:GetWide(),bLogs.Menu.Logs.LogContent:GetTall() + 45)
			bLogs.Menu.Admin.OldConfigs:AlignBottom(0)
			bLogs.Menu.Admin.OldConfigs:AlignRight(0)
			bLogs.Menu.Admin.OldConfigs.Paint = function(self)
				surface.SetDrawColor(Color(255,255,255))
				surface.DrawRect(0,0,self:GetWide(),self:GetTall())
			end

			bLogs.Menu.Admin.OldConfigsList = bLogs.CreateList(bLogs.Menu.Admin.OldConfigs)
			bLogs.Menu.Admin.OldConfigsList:AlignLeft(5)
			bLogs.Menu.Admin.OldConfigsList:AlignTop(5)
			bLogs.Menu.Admin.OldConfigsList:SetSize(bLogs.Menu.Admin.OldConfigs:GetWide() - 10,bLogs.Menu.Admin.OldConfigs:GetTall() - 10)
			bLogs.Menu.Admin.OldConfigsList:AddColumn_(bLogs.Translate("file"))
			for _,v in pairs(bLogs.ConfigFiles) do
				bLogs.Menu.Admin.OldConfigsList:AddLine_(v)
			end
			bLogs.Menu.Admin.OldConfigsList.OnClickLine = function(_,line)
				local menu = DermaMenu()

				menu:AddOption(bLogs.Translate("import"),function()
					net.Start("blogs_importconfig")
					net.WriteString(line:GetValue(1))
					net.SendToServer()
				end):SetImage("icon16/page_copy.png")

				menu:Open()
			end

			local orig_ = bLogs.Menu.Admin.OldConfigsList.PaintOver
			bLogs.Menu.Admin.OldConfigsList.PaintOver = function(self)
				if (orig_ ~= nil) then orig_(self) end

				surface.SetDrawColor(Color(206,206,206))
				surface.DrawOutlinedRect(1,0,self:GetWide() - 1,self:GetTall())
			end

			bLogs.Menu.Admin.PermissionsPanel = vgui.Create("DPanel",bLogs.Menu.Admin)
			bLogs.Menu.Admin.PermissionsPanel:SetVisible(false)
			bLogs.Menu.Admin.PermissionsPanel:SetSize(bLogs.Menu.Logs.LogContent:GetWide(),bLogs.Menu.Logs.LogContent:GetTall() + 45)
			bLogs.Menu.Admin.PermissionsPanel:AlignBottom(0)
			bLogs.Menu.Admin.PermissionsPanel:AlignRight(0)

			bLogs.Menu.Admin.PermissionsPanel.HelpBox = vgui.Create("DPanel",bLogs.Menu.Admin.PermissionsPanel)
			bLogs.Menu.Admin.PermissionsPanel.HelpBox:SetSize(bLogs.Menu.Admin.PermissionsPanel:GetWide() - 630,bLogs.Menu.Admin.PermissionsPanel:GetTall() - 45)
			bLogs.Menu.Admin.PermissionsPanel.HelpBox:AlignRight(5)
			bLogs.Menu.Admin.PermissionsPanel.HelpBox:AlignBottom(5)
			bLogs.Menu.Admin.PermissionsPanel.HelpBox.Paint = function(self)
				surface.SetDrawColor(Color(206,206,206))
				surface.DrawOutlinedRect(0,0,self:GetWide(),self:GetTall())
			end
			bLogs.Menu.Admin.PermissionsPanel.HelpBox.Text = vgui.Create("DLabel",bLogs.Menu.Admin.PermissionsPanel.HelpBox)
			bLogs.Menu.Admin.PermissionsPanel.HelpBox.Text:AlignLeft(5)
			bLogs.Menu.Admin.PermissionsPanel.HelpBox.Text:AlignTop(5)
			bLogs.Menu.Admin.PermissionsPanel.HelpBox.Text:SetWide(bLogs.Menu.Admin.PermissionsPanel.HelpBox:GetWide() - 10)
			bLogs.Menu.Admin.PermissionsPanel.HelpBox.Text:SetAutoStretchVertical(true)
			bLogs.Menu.Admin.PermissionsPanel.HelpBox.Text:SetText(bLogs.Translate("permissions_helpbox"))
			bLogs.Menu.Admin.PermissionsPanel.HelpBox.Text:SetFont("blogs_roboto16")
			bLogs.Menu.Admin.PermissionsPanel.HelpBox.Text:SetWrap(true)
			bLogs.Menu.Admin.PermissionsPanel.HelpBox.Text:SetTextColor(Color(0,0,0))

			bLogs.Menu.Admin.PermissionsPanel.InfoBox = vgui.Create("DPanel",bLogs.Menu.Admin.PermissionsPanel)
			bLogs.Menu.Admin.PermissionsPanel.InfoBox:AlignLeft(210)
			bLogs.Menu.Admin.PermissionsPanel.InfoBox:AlignTop(5)
			bLogs.Menu.Admin.PermissionsPanel.InfoBox:SetSize(bLogs.Menu.Admin.PermissionsPanel:GetWide() - 300,30)
			bLogs.Menu.Admin.PermissionsPanel.InfoBox.Text = bLogs.Translate("selectitem")
			bLogs.Menu.Admin.PermissionsPanel.InfoBox.Paint = function(self)
				surface.SetDrawColor(Color(206,206,206))
				surface.DrawOutlinedRect(0,0,self:GetWide(),self:GetTall())

				draw.SimpleText(self.Text,"blogs_roboto16",(self:GetWide() / 2),(self:GetTall() / 2),Color(0,0,0),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
			end

			bLogs.Menu.Admin.PermissionsPanel.EnableConsole = vgui.Create("DCheckBox",bLogs.Menu.Admin.PermissionsPanel.HelpBox)
			bLogs.Menu.Admin.PermissionsPanel.EnableConsole:SetDisabled(true)
			bLogs.Menu.Admin.PermissionsPanel.EnableConsole:AlignBottom(5)
			bLogs.Menu.Admin.PermissionsPanel.EnableConsole:AlignLeft(5)
			bLogs.Menu.Admin.PermissionsPanel.EnableConsole.DoClick = function()
				if (bLogs.Menu.Admin.PermissionsPanel.EnableConsole:GetDisabled()) then return end
				bLogs.Menu.Admin.PermissionsPanel.EnableConsole:Toggle()
				bLogs.Menu.Admin.PermissionsPanel.SaveButton:SetDisabled(false)
			end

			bLogs.Menu.Admin.PermissionsPanel.EnableConsole.Text = vgui.Create("DLabel",bLogs.Menu.Admin.PermissionsPanel.HelpBox)
			bLogs.Menu.Admin.PermissionsPanel.EnableConsole.Text:SetFont("blogs_roboto16")
			bLogs.Menu.Admin.PermissionsPanel.EnableConsole.Text:SetTextColor(Color(0,0,0))
			bLogs.Menu.Admin.PermissionsPanel.EnableConsole.Text:SetText(bLogs.Translate("print_to_console"))
			bLogs.Menu.Admin.PermissionsPanel.EnableConsole.Text:SizeToContents()
			bLogs.Menu.Admin.PermissionsPanel.EnableConsole.Text:AlignBottom(5)
			bLogs.Menu.Admin.PermissionsPanel.EnableConsole.Text:AlignLeft(10 + bLogs.Menu.Admin.PermissionsPanel.EnableConsole:GetWide())

			bLogs.Menu.Admin.PermissionsPanel.EnableChat = vgui.Create("DCheckBox",bLogs.Menu.Admin.PermissionsPanel.HelpBox)
			bLogs.Menu.Admin.PermissionsPanel.EnableChat:SetDisabled(true)
			bLogs.Menu.Admin.PermissionsPanel.EnableChat:AlignBottom(5 + 18)
			bLogs.Menu.Admin.PermissionsPanel.EnableChat:AlignLeft(5)
			bLogs.Menu.Admin.PermissionsPanel.EnableChat.DoClick = function()
				bLogs.Menu.Admin.PermissionsPanel.EnableChat:Toggle()
				bLogs.Menu.Admin.PermissionsPanel.SaveButton:SetDisabled(false)

				if (bLogs.Menu.Admin.PermissionsPanel.EnableChat:GetChecked() == true) then
					bLogs.Menu.Admin.PermissionsPanel.EnableConsole:SetValue(false)
					bLogs.Menu.Admin.PermissionsPanel.EnableConsole:SetDisabled(true)
				else
					bLogs.Menu.Admin.PermissionsPanel.EnableConsole:SetValue(false)
					bLogs.Menu.Admin.PermissionsPanel.EnableConsole:SetDisabled(false)
				end
			end

			bLogs.Menu.Admin.PermissionsPanel.EnableChat.Text = vgui.Create("DLabel",bLogs.Menu.Admin.PermissionsPanel.HelpBox)
			bLogs.Menu.Admin.PermissionsPanel.EnableChat.Text:SetFont("blogs_roboto16")
			bLogs.Menu.Admin.PermissionsPanel.EnableChat.Text:SetTextColor(Color(0,0,0))
			bLogs.Menu.Admin.PermissionsPanel.EnableChat.Text:SetText(bLogs.Translate("print_to_chat"))
			bLogs.Menu.Admin.PermissionsPanel.EnableChat.Text:SizeToContents()
			bLogs.Menu.Admin.PermissionsPanel.EnableChat.Text:AlignBottom(5 + 18)
			bLogs.Menu.Admin.PermissionsPanel.EnableChat.Text:AlignLeft(10 + bLogs.Menu.Admin.PermissionsPanel.EnableChat:GetWide())

			bLogs.Menu.Admin.PermissionsPanel.DisableCompletely = vgui.Create("DCheckBox",bLogs.Menu.Admin.PermissionsPanel.HelpBox)
			bLogs.Menu.Admin.PermissionsPanel.DisableCompletely:SetDisabled(true)
			bLogs.Menu.Admin.PermissionsPanel.DisableCompletely:AlignBottom(5 + 36)
			bLogs.Menu.Admin.PermissionsPanel.DisableCompletely:AlignLeft(5)
			bLogs.Menu.Admin.PermissionsPanel.DisableCompletely.DoClick = function()
				bLogs.Menu.Admin.PermissionsPanel.DisableCompletely:Toggle()
				bLogs.Menu.Admin.PermissionsPanel.SaveButton:SetDisabled(false)
			end

			bLogs.Menu.Admin.PermissionsPanel.DisableCompletely.Text = vgui.Create("DLabel",bLogs.Menu.Admin.PermissionsPanel.HelpBox)
			bLogs.Menu.Admin.PermissionsPanel.DisableCompletely.Text:SetFont("blogs_roboto16")
			bLogs.Menu.Admin.PermissionsPanel.DisableCompletely.Text:SetTextColor(Color(0,0,0))
			bLogs.Menu.Admin.PermissionsPanel.DisableCompletely.Text:SetText(bLogs.Translate("disablecompletely"))
			bLogs.Menu.Admin.PermissionsPanel.DisableCompletely.Text:SizeToContents()
			bLogs.Menu.Admin.PermissionsPanel.DisableCompletely.Text:AlignBottom(5 + 36)
			bLogs.Menu.Admin.PermissionsPanel.DisableCompletely.Text:AlignLeft(10 + bLogs.Menu.Admin.PermissionsPanel.DisableCompletely:GetWide())

			local glob = bLogs.Translate("globalmenu")
			local lookupip = bLogs.Translate("lookupip")
			bLogs.Menu.Admin.PermissionsPanel.SaveButton = vgui.Create("DButton",bLogs.Menu.Admin.PermissionsPanel)
			bLogs.Menu.Admin.PermissionsPanel.SaveButton:SetText(bLogs.Translate("save"))
			bLogs.Menu.Admin.PermissionsPanel.SaveButton:SetDisabled(true)
			bLogs.Menu.Admin.PermissionsPanel.SaveButton:SetFont("blogs_roboto16")
			bLogs.Menu.Admin.PermissionsPanel.SaveButton:SetTextColor(Color(255,255,255))
			bLogs.Menu.Admin.PermissionsPanel.SaveButton:SetSize(80,30)
			bLogs.Menu.Admin.PermissionsPanel.SaveButton:AlignRight(5)
			bLogs.Menu.Admin.PermissionsPanel.SaveButton:AlignTop(5)
			bLogs.Menu.Admin.PermissionsPanel.SaveButton.Paint = btnPaint
			bLogs.Menu.Admin.PermissionsPanel.SaveButton.DoClick = function()
				bLogs.Menu.Admin.PermissionsPanel.SaveButton:SetDisabled(true)

				local send_data = {}
				for _,v in pairs(bLogs.Menu.Admin.PermissionsPanel.Usergroups:GetLines()) do
					if (not table.HasValue({bLogs.Translate("add"),"*",bLogs.Translate("rootonly")},v:GetValue(1))) then
						if (send_data["usergroups"] == nil) then
							send_data["usergroups"] = {}
						end
						table.insert(send_data["usergroups"],v:GetValue(1))
					end
				end
				for _,v in pairs(bLogs.Menu.Admin.PermissionsPanel.SteamIDs:GetLines()) do
					if (not table.HasValue({bLogs.Translate("add"),"N/A"},v:GetValue(1))) then
						if (send_data["steamids"] == nil) then
							send_data["steamids"] = {}
						end
						table.insert(send_data["steamids"],v:GetValue(1))
					end
				end
				if (bLogs.Menu.Admin.PermissionsPanel.CurrentLogger ~= glob and bLogs.Menu.Admin.PermissionsPanel.CurrentLogger ~= lookupip) then
					send_data["EnableConsole"] = bLogs.Menu.Admin.PermissionsPanel.EnableConsole:GetChecked()
					send_data["EnableChat"] = bLogs.Menu.Admin.PermissionsPanel.EnableChat:GetChecked()
					send_data["DisableCompletely"] = bLogs.Menu.Admin.PermissionsPanel.DisableCompletely:GetChecked()
				end
				net.Start("blogs_updateoptions_permissions")
					if (bLogs.Menu.Admin.PermissionsPanel.CurrentLogger == glob) then
						net.WriteString("menu")
					elseif (bLogs.Menu.Admin.PermissionsPanel.CurrentLogger == lookupip) then
						net.WriteString("lookupip")
					else
						net.WriteString(bLogs.Menu.Admin.PermissionsPanel.CurrentLogger)
					end
					local s = util.Compress(util.TableToJSON(send_data["steamids"] or {}))
					net.WriteDouble(#s)
					net.WriteData(s,#s)
					local u = util.Compress(util.TableToJSON(send_data["usergroups"] or {}))
					net.WriteDouble(#u)
					net.WriteData(u,#u)
					net.WriteBool(send_data["EnableConsole"] or false)
					net.WriteBool(send_data["EnableChat"] or false)
					net.WriteBool(send_data["DisableCompletely"] or false)
				net.SendToServer()

				if (bLogs.AlwaysIgnore ~= true) then
					Derma_Query(bLogs.Translate("saved_1"),bLogs.Translate("saved_2"),bLogs.Translate("saved_3"),function()
						bLogs.Menu:Close()
						RunConsoleCommand("blogs_menu")
					end,bLogs.Translate("ignore"),function()
						bLogs.AlwaysIgnore = true
					end)
				end
			end

			bLogs.Menu.Admin.PermissionsPanel.ListThing = bLogs.CreateList(bLogs.Menu.Admin.PermissionsPanel)
			bLogs.Menu.Admin.PermissionsPanel.ListThing:SetSize(200,bLogs.Menu.Admin.PermissionsPanel:GetTall() - 10)
			bLogs.Menu.Admin.PermissionsPanel.ListThing:AlignBottom(5)
			bLogs.Menu.Admin.PermissionsPanel.ListThing:AlignLeft(5)
			bLogs.Menu.Admin.PermissionsPanel.ListThing:AddColumn_(bLogs.Translate("loggers"))
			bLogs.Menu.Admin.PermissionsPanel.ListThing:AddLine_(glob)
			bLogs.Menu.Admin.PermissionsPanel.ListThing:AddLine_(lookupip)
			local splitter = "-----------------------------------------------------------"
			bLogs.Menu.Admin.PermissionsPanel.ListThing:AddLine_(splitter)
			for _,v in pairs(bLogs.Hooks.Nice) do
				bLogs.Menu.Admin.PermissionsPanel.ListThing:AddLine_(v[1])
			end
			bLogs.Menu.Admin.PermissionsPanel.ListThing.OnClickLine = function(_,line)
				if (line:GetValue(1) == splitter) then return end
				local function doit_()
					bLogs.Menu.Admin.PermissionsPanel.CurrentLogger = line:GetValue(1)
					bLogs.Menu.Admin.PermissionsPanel.SteamIDs:Clear()
					bLogs.Menu.Admin.PermissionsPanel.Usergroups:Clear()

					bLogs.Menu.Admin.PermissionsPanel.DisableCompletely:SetValue(false)
					bLogs.Menu.Admin.PermissionsPanel.EnableChat:SetValue(false)
					bLogs.Menu.Admin.PermissionsPanel.EnableConsole:SetValue(false)

					if (line:GetValue(1) == glob) then
						bLogs.Menu.Admin.PermissionsPanel.DisableCompletely:SetDisabled(true)
						bLogs.Menu.Admin.PermissionsPanel.EnableChat:SetDisabled(true)
						bLogs.Menu.Admin.PermissionsPanel.EnableConsole:SetDisabled(true)

						bLogs.Menu.Admin.PermissionsPanel.InfoBox.Text = bLogs.Translate("permissions_whocan_menu")

						if (#bLogs.CustomConfigRaw.Permissions.Access.Usergroups > 0) then
							for _,v in pairs(bLogs.CustomConfigRaw.Permissions.Access.Usergroups) do
								bLogs.Menu.Admin.PermissionsPanel.Usergroups:AddLine_(v)
							end
						else
							bLogs.Menu.Admin.PermissionsPanel.Usergroups:AddLine_(bLogs.Translate("rootonly"))
						end
						if (#bLogs.CustomConfigRaw.Permissions.Access.SteamIDs > 0) then
							for _,v in pairs(bLogs.CustomConfigRaw.Permissions.Access.SteamIDs) do
								bLogs.Menu.Admin.PermissionsPanel.SteamIDs:AddLine_(v)
							end
						else
							bLogs.Menu.Admin.PermissionsPanel.SteamIDs:AddLine_("N/A")
						end
					elseif (line:GetValue(1) == lookupip) then
						bLogs.Menu.Admin.PermissionsPanel.DisableCompletely:SetDisabled(true)
						bLogs.Menu.Admin.PermissionsPanel.EnableChat:SetDisabled(true)
						bLogs.Menu.Admin.PermissionsPanel.EnableConsole:SetDisabled(true)

						bLogs.Menu.Admin.PermissionsPanel.InfoBox.Text = bLogs.Translate("permissions_whocan_lookupip")

						if (#bLogs.CustomConfigRaw.Permissions.lookupip.Usergroups > 0) then
							for _,v in pairs(bLogs.CustomConfigRaw.Permissions.lookupip.Usergroups) do
								bLogs.Menu.Admin.PermissionsPanel.Usergroups:AddLine_(v)
							end
						else
							bLogs.Menu.Admin.PermissionsPanel.Usergroups:AddLine_(bLogs.Translate("rootonly"))
						end
						if (#bLogs.CustomConfigRaw.Permissions.lookupip.SteamIDs > 0) then
							for _,v in pairs(bLogs.CustomConfigRaw.Permissions.lookupip.SteamIDs) do
								bLogs.Menu.Admin.PermissionsPanel.SteamIDs:AddLine_(v)
							end
						else
							bLogs.Menu.Admin.PermissionsPanel.SteamIDs:AddLine_("N/A")
						end
					else
						bLogs.Menu.Admin.PermissionsPanel.EnableChat:SetDisabled(false)
						bLogs.Menu.Admin.PermissionsPanel.DisableCompletely:SetDisabled(false)
						bLogs.Menu.Admin.PermissionsPanel.EnableConsole:SetDisabled(false)
						bLogs.Menu.Admin.PermissionsPanel.EnableChat:SetValue(false)
						bLogs.Menu.Admin.PermissionsPanel.EnableConsole:SetValue(false)

						if (bLogs.CustomConfigRaw.Permissions.Loggers[line:GetValue(1)] ~= nil) then
							bLogs.Menu.Admin.PermissionsPanel.InfoBox.Text = bLogs.Translate("permissions_whocan_view") .. " \"" .. line:GetValue(1) .. '"?'

							if (bLogs.CustomConfigRaw.Permissions.Loggers[line:GetValue(1)].EnableChat == true) then
								bLogs.Menu.Admin.PermissionsPanel.EnableChat:SetValue(true)
								bLogs.Menu.Admin.PermissionsPanel.EnableConsole:SetValue(false)
								bLogs.Menu.Admin.PermissionsPanel.EnableConsole:SetDisabled(true)
							elseif (bLogs.CustomConfigRaw.Permissions.Loggers[line:GetValue(1)].EnableConsole == true) then
								bLogs.Menu.Admin.PermissionsPanel.EnableConsole:SetValue(true)
							end
							if (bLogs.CustomConfigRaw.Permissions.Loggers[line:GetValue(1)].Disabled == true) then
								bLogs.Menu.Admin.PermissionsPanel.DisableCompletely:SetValue(true)
							end

							if (bLogs.CustomConfigRaw.Permissions.Loggers[line:GetValue(1)].SteamIDs ~= nil) then
								for _,v in pairs(bLogs.CustomConfigRaw.Permissions.Loggers[line:GetValue(1)].SteamIDs) do
									bLogs.Menu.Admin.PermissionsPanel.SteamIDs:AddLine_(v)
								end
							else
								bLogs.Menu.Admin.PermissionsPanel.SteamIDs:AddLine_("N/A")
							end
							if (bLogs.CustomConfigRaw.Permissions.Loggers[line:GetValue(1)].Usergroups ~= nil) then
								for _,v in pairs(bLogs.CustomConfigRaw.Permissions.Loggers[line:GetValue(1)].Usergroups) do
									bLogs.Menu.Admin.PermissionsPanel.Usergroups:AddLine_(v)
								end
							else
								bLogs.Menu.Admin.PermissionsPanel.Usergroups:AddLine_("*")
							end
						else
							bLogs.Menu.Admin.PermissionsPanel.Usergroups:AddLine_("*")
							bLogs.Menu.Admin.PermissionsPanel.SteamIDs:AddLine_("N/A")
							bLogs.Menu.Admin.PermissionsPanel.InfoBox.Text = bLogs.Translate("allwithmenuaccess") .. ' "' .. line:GetValue(1) .. '".'
						end
					end
					bLogs.Menu.Admin.PermissionsPanel.SteamIDs:AddLine_(bLogs.Translate("add"))
					bLogs.Menu.Admin.PermissionsPanel.Usergroups:AddLine_(bLogs.Translate("add"))
				end
				if (bLogs.Menu.Admin.PermissionsPanel.CurrentLogger ~= nil and not bLogs.Menu.Admin.PermissionsPanel.SaveButton:GetDisabled()) then
					Derma_Query(bLogs.Translate("unsavedchanges"),bLogs.Translate("warning"),bLogs.Translate("save"),function()
						bLogs.Menu.Admin.PermissionsPanel.SaveButton.DoClick()
						doit_()
					end,bLogs.Translate("ignore"),function()
						bLogs.Menu.Admin.PermissionsPanel.SaveButton:SetDisabled(true)
						doit_()
					end)
				else
					doit_()
				end
			end

			bLogs.Menu.Admin.PermissionsPanel.Usergroups = bLogs.CreateList(bLogs.Menu.Admin.PermissionsPanel)
			bLogs.Menu.Admin.PermissionsPanel.Usergroups:SetSize(200,bLogs.Menu.Admin.PermissionsPanel:GetTall() - 45)
			bLogs.Menu.Admin.PermissionsPanel.Usergroups:AlignBottom(5)
			bLogs.Menu.Admin.PermissionsPanel.Usergroups:AlignLeft(210)
			bLogs.Menu.Admin.PermissionsPanel.Usergroups:AddColumn_(bLogs.Translate("usergroups"))
			bLogs.Menu.Admin.PermissionsPanel.Usergroups.Think = function()
				if (not IsValid(bLogs.Menu)) then return end
				if (not input.IsMouseDown(MOUSE_LEFT)) then
					bLogs.Menu.Admin.PermissionsPanel.Usergroups.Allow = true
				end
			end
			bLogs.Menu.Admin.PermissionsPanel.Usergroups.OnClickLine = function(listx,line)
				if (listx.Allow ~= true) then return end
				listx.Allow = false
				if (line:GetValue(1) == bLogs.Translate("add") or line:GetValue(1) == "*" or line:GetValue(1) == bLogs.Translate("rootonly")) then
					Derma_StringRequest(bLogs.Translate("enterusergroup"),bLogs.Translate("enterusergroup_2"),"",function(txt)
						txt = string.Trim(txt)
						if (txt == "") then
							return
						end
						local lines = {}
						for _,v in pairs(listx:GetLines()) do
							if (v:GetValue(1) ~= "*" and v:GetValue(1) ~= bLogs.Translate("rootonly")) then
								table.insert(lines,v:GetValue(1))
							end
						end
						listx:Clear()
						listx:AddLine_(txt)
						for _,v in pairs(lines) do
							listx:AddLine_(v)
						end
						bLogs.Menu.Admin.PermissionsPanel.SaveButton:SetDisabled(false)

					end,nil,bLogs.Translate("addnoplus"),bLogs.Translate("cancel"))
				else
					local redo = true
					for i,v in pairs(listx:GetLines()) do
						if (v == line) then
							listx:RemoveLine(i)
						elseif (v:GetValue(1) ~= bLogs.Translate("add")) then
							redo = false
						end
					end
					if (redo) then
						listx:Clear()
						if (bLogs.Menu.Admin.PermissionsPanel.CurrentLogger == glob or bLogs.Menu.Admin.PermissionsPanel.CurrentLogger == lookupip) then
							listx:AddLine_(bLogs.Translate("rootonly"))
						else
							listx:AddLine_("*")
						end
						listx:AddLine_(bLogs.Translate("add"))
					end
					bLogs.Menu.Admin.PermissionsPanel.SaveButton:SetDisabled(false)
				end
			end

			bLogs.Menu.Admin.PermissionsPanel.SteamIDs = bLogs.CreateList(bLogs.Menu.Admin.PermissionsPanel)
			bLogs.Menu.Admin.PermissionsPanel.SteamIDs:SetSize(200,bLogs.Menu.Admin.PermissionsPanel:GetTall() - 45)
			bLogs.Menu.Admin.PermissionsPanel.SteamIDs:AlignBottom(5)
			bLogs.Menu.Admin.PermissionsPanel.SteamIDs:AlignLeft(420)
			bLogs.Menu.Admin.PermissionsPanel.SteamIDs:AddColumn_("SteamIDs")
			bLogs.Menu.Admin.PermissionsPanel.SteamIDs.Think = function()
				if (not IsValid(bLogs.Menu)) then return end
				if (not input.IsMouseDown(MOUSE_LEFT)) then
					bLogs.Menu.Admin.PermissionsPanel.SteamIDs.Allow = true
				end
			end
			bLogs.Menu.Admin.PermissionsPanel.SteamIDs.OnClickLine = function(listx,line)
				if (listx.Allow ~= true) then return end
				listx.Allow = false
				if (line:GetValue(1) == bLogs.Translate("add") or line:GetValue(1) == "N/A") then
					Derma_StringRequest(bLogs.Translate("entera") .. " SteamID/SteamID64",bLogs.Translate("entera") .. " SteamID/SteamID64 " .. bLogs.Translate("entera_2"),"",function(txt)

						if (txt == "") then return end
						local lines = {}
						for _,v in pairs(listx:GetLines()) do
							if (v:GetValue(1) ~= "N/A") then
								table.insert(lines,v:GetValue(1))
							end
						end
						listx:Clear()
						listx:AddLine_(txt)
						for _,v in pairs(lines) do
							listx:AddLine_(v)
						end
						bLogs.Menu.Admin.PermissionsPanel.SaveButton:SetDisabled(false)

					end,nil,bLogs.Translate("addnoplus"),bLogs.Translate("cancel"))
				else
					local redo = true
					for i,v in pairs(listx:GetLines()) do
						if (v == line) then
							listx:RemoveLine(i)
						elseif (v:GetValue(1) ~= bLogs.Translate("add")) then
							redo = false
						end
					end
					if (redo) then
						listx:Clear()
						listx:AddLine_("N/A")
						listx:AddLine_(bLogs.Translate("add"))
					end
					bLogs.Menu.Admin.PermissionsPanel.SaveButton:SetDisabled(false)
				end
			end

			local orig_ = bLogs.Menu.Admin.PermissionsPanel.ListThing.PaintOver
			bLogs.Menu.Admin.PermissionsPanel.ListThing.PaintOver = function(self)
				if (orig_ ~= nil) then orig_(self) end

				surface.SetDrawColor(Color(206,206,206))
				surface.DrawOutlinedRect(1,0,self:GetWide() - 1,self:GetTall())
			end

			local orig_ = bLogs.Menu.Admin.PermissionsPanel.SteamIDs.PaintOver
			bLogs.Menu.Admin.PermissionsPanel.SteamIDs.PaintOver = function(self)
				if (orig_ ~= nil) then orig_(self) end

				surface.SetDrawColor(Color(206,206,206))
				surface.DrawOutlinedRect(1,0,self:GetWide() - 1,self:GetTall())
			end

			local orig_ = bLogs.Menu.Admin.PermissionsPanel.Usergroups.PaintOver
			bLogs.Menu.Admin.PermissionsPanel.Usergroups.PaintOver = function(self)
				if (orig_ ~= nil) then orig_(self) end

				surface.SetDrawColor(Color(206,206,206))
				surface.DrawOutlinedRect(1,0,self:GetWide() - 1,self:GetTall())
			end

			bLogs.Menu.AdminLeftTabs:AddItem(bLogs.Translate("loggerspermissions"),Color(0,125,255),function()
				bLogs.Menu.Admin.PermissionsPanel:SetVisible(true)
				bLogs.Menu.AdminHTML:SetVisible(false)
				bLogs.Menu.Admin.OldConfigs:SetVisible(false)
			end)
			bLogs.Menu.Admin.PermissionsPanel.Paint = function(self)
				surface.SetDrawColor(Color(255,255,255))
				surface.DrawRect(0,0,self:GetWide(),self:GetTall())
			end

			bLogs.Menu.AdminLeftTabs:AddItem(bLogs.Translate("dangerzone"),Color(255,0,0),function()
				bLogs.Menu.Admin.PermissionsPanel:SetVisible(false)
				bLogs.Menu.Admin.OldConfigs:SetVisible(false)
				bLogs.Menu.AdminHTML:SetVisible(true)

				bLogs.Menu.AdminHTML:AddFunction("console","blogs_resetall",function()
					if (IsValid(bLogs.Menu)) then
						net.Start("blogs_resetall")
						net.SendToServer()
						bLogs.Menu:Close()
					end
				end)

				bLogs.Menu.AdminHTML:AddFunction("console","reset_config",function()
					if (IsValid(bLogs.Menu)) then
						net.Start("blogs_resetconfig")
						net.SendToServer()
						bLogs.Menu:Close()
					end
				end)

				bLogs.Menu.AdminHTML:AddFunction("console","blogs_refreshblogs",function()
					if (IsValid(bLogs.Menu)) then
						net.Start("blogs_refreshblogs")
						net.SendToServer()
						bLogs.Menu:Close()
					end
				end)

				bLogs.Menu.AdminHTML:SetHTML(htmlprefix .. [[<style>
					.btn {
						display: inline-block;
						width: 146px;
					    -webkit-border-radius: 6;
					    -moz-border-radius: 6;
					    border-radius: 6px;
					    font-family: Arial;
					    color: #fff;
					    font-size: 12px;
					    background: #8a1d1d;
					    padding: 10px 20px;
					    cursor: pointer;
					    text-align: center;

						-webkit-touch-callout: none;
						-webkit-user-select: none;
						-khtml-user-select: none;
						-moz-user-select: none;
						-ms-user-select: none;
						user-select: none;

						margin-bottom: 5px;

						-webkit-transition: background-color 5s;
						-moz-transition: background-color 5s;
						-o-transition: background-color 5s;
						transition: background-color 5s;
					}
					.btn:active {
						background-color: #0096FF;
					}
				</style>
				<span class='btn' href id="reset_all">Reset bLogs & Players</span><br><span id="reset_config" class='btn' href>Reset config</span><br><span id="refresh_yeah" class='btn' href>Refresh bLogs</span><br><br>
				Hold down on the buttons for 5 seconds.
				<script>
					var reset_all_timeout;
					$("#reset_all").mousedown(function() {
						reset_all_timeout = window.setTimeout(function() {
							console.blogs_resetall();
						},2000);
					});
					$("#reset_all").mouseup(function() {
						clearTimeout(reset_all_timeout);
					});

					var reset_config_timeout;
					$("#reset_config").mousedown(function() {
						reset_config_timeout = window.setTimeout(function() {
							console.reset_config();
						},2000);
					});
					$("#reset_config").mouseup(function() {
						clearTimeout(reset_config_timeout);
					});

					var blogs_refreshblogs;
					$("#refresh_yeah").mousedown(function() {
						blogs_refreshblogs = window.setTimeout(function() {
							console.blogs_refreshblogs();
						},2000);
					});
					$("#refresh_yeah").mouseup(function() {
						clearTimeout(blogs_refreshblogs);
					});
				</script>]] .. htmlsuffix)
			end)

			bLogs.Menu.AdminLeftTabs:AddItem(bLogs.Translate("old_configs"),Color(0,255,0),function()
				bLogs.Menu.Admin.PermissionsPanel:SetVisible(false)
				bLogs.Menu.AdminHTML:SetVisible(false)
				bLogs.Menu.Admin.OldConfigs:SetVisible(true)
			end)
		end
		bLogs.Menu.TopTabs:AddTab(bLogs.Translate("rootconfig"),bLogs.Menu.Admin)
	end

	bLogs.Menu.LogInfoBg = vgui.Create("DPanel",bLogs.Menu.Logs)
	bLogs.Menu.LogInfoBg.Open = false
	bLogs.Menu.LogInfoBg:SetMouseInputEnabled(false)
	bLogs.Menu.LogInfoBg:SetSize(bLogs.Menu.Logs:GetWide(),bLogs.Menu.Logs:GetTall())
	bLogs.Menu.LogInfoBg:AlignBottom(0)
	bLogs.Menu.LogInfoBg.AlphaLevel = 0
	bLogs.Menu.LogInfoBg.Paint = function(self)
		surface.SetDrawColor(Color(0,0,0,self.AlphaLevel))
		surface.DrawRect(0,0,self:GetWide(),self:GetTall())
	end
	function bLogs.Menu.LogInfoBg:OnMousePressed()
		bLogs.Menu.LogInfo:Close()
	end

	bLogs.Menu.LogInfo = vgui.Create("DPanel",bLogs.Menu.Logs)
	bLogs.Menu.LogInfo:SetSize(575,300)
	bLogs.Menu.LogInfo:Center()
	local x,y = bLogs.Menu.LogInfo:GetPos()
	bLogs.Menu.LogInfo.YRequired = y
	bLogs.Menu.LogInfo:SetPos(x,bLogs.Menu:GetTall())
	bLogs.Menu.LogInfo.Paint = function(self)
		surface.SetDrawColor(Color(255,255,255))
		surface.DrawRect(0,0,self:GetWide(),self:GetTall())

		surface.SetDrawColor(Color(26,26,26))
		surface.DrawRect(0,0,self:GetWide(),24)
	end


		bLogs.Menu.LogInfo.TopTabs = bLogs.vgui.Create("bLogsTabs",bLogs.Menu.LogInfo,{["CustomFrame"] = true})
		bLogs.Menu.LogInfo.TopTabs:AlignTop(24)
		bLogs.Menu.LogInfo.TopTabs:SetSize(bLogs.Menu.LogInfo:GetWide(),35)

		bLogs.Menu.LogInfo.FullLog = vgui.Create("DPanel")
		bLogs.Menu.LogInfo.FullLog.onbLogsSetup = function()
			bLogs.Menu.LogInfo.FullLog:SetParent(bLogs.Menu.LogInfo)
			bLogs.Menu.LogInfo.FullLog:SetSize(bLogs.Menu.LogInfo:GetWide(),bLogs.Menu.LogInfo:GetTall() - 24 - 35)
		end
		bLogs.Menu.LogInfo.FullLog.onLineSelected = function(line)
			if (IsValid(bLogs.Menu.LogInfo.FullLog.FullLog)) then bLogs.Menu.LogInfo.FullLog.FullLog:Remove() end
			local fulllog = "[" .. line:GetValue(1) .. "] (" .. line:GetValue(2) .. ") " .. line:GetValue(3)
			bLogs.Menu.LogInfo.FullLog.FullLog = vgui.Create("DHTML",bLogs.Menu.LogInfo.FullLog)
			bLogs.Menu.LogInfo.FullLog.FullLog:SetHTML([[<!DOCTYPE html>
<html>
	<head>
		<style>
			@import url(https://fonts.googleapis.com/css?family=Roboto:500);

			body {
				background-color: #fff;
				font-family: 'Roboto', sans-serif;
				color: #0A0A0A;
				font-size: 13px;
			}
		</style>

		<script>
			window.onload = function() {
				function escapeHtml(text) {
				  var map = {
				    '&': '&amp;',
				    '<': '&lt;',
				    '>': '&gt;',
				    '"': '&quot;',
				    "'": '&#039;'
				  };

				  return text.replace(/[&<>"']/g, function(m) { return map[m]; });
				}

				document.body.innerHTML = escapeHtml(document.body.innerHTML);
			}
		</script>
	</head>
	<body>
		]] .. fulllog .. [[
	</body>
</html>]])
			bLogs.Menu.LogInfo.FullLog.FullLog:SetSize(bLogs.Menu.LogInfo.FullLog:GetWide(),bLogs.Menu.LogInfo.FullLog:GetTall() - 16 - 5 - 5)

			bLogs.Menu.LogInfo.FullLog.CopyText = vgui.Create("DLabel",bLogs.Menu.LogInfo.FullLog)
			bLogs.Menu.LogInfo.FullLog.CopyText:SetFont("blogs_roboto16")
			bLogs.Menu.LogInfo.FullLog.CopyText:SetText(bLogs.Translate("copy"))
			bLogs.Menu.LogInfo.FullLog.CopyText:SetTextColor(Color(0,0,0))
			bLogs.Menu.LogInfo.FullLog.CopyText:SizeToContents()
			bLogs.Menu.LogInfo.FullLog.CopyText:AlignBottom(5)
			bLogs.Menu.LogInfo.FullLog.CopyText:AlignLeft(16 + 5 + 5)

			bLogs.Menu.LogInfo.FullLog.CopyButton = vgui.Create("DImageButton",bLogs.Menu.LogInfo.FullLog)
			bLogs.Menu.LogInfo.FullLog.CopyButton:SetSize(16,16)
			bLogs.Menu.LogInfo.FullLog.CopyButton:AlignBottom(5)
			bLogs.Menu.LogInfo.FullLog.CopyButton:SetImage("icon16/page_copy.png")
			bLogs.Menu.LogInfo.FullLog.CopyButton:AlignLeft(5)
			bLogs.Menu.LogInfo.FullLog.CopyButton.DoClick = function()
				local menu = DermaMenu()

				menu:AddOption(bLogs.Translate("quickcopy"),function() SetClipboardText(fulllog) end):SetImage("icon16/page_copy.png")

				menu:AddSpacer()
				menu:AddOption(bLogs.Translate("cancel")):SetImage("icon16/cancel.png")
				menu:Open()
			end
		end
		bLogs.Menu.LogInfo.TopTabs:AddTab(bLogs.Translate("fulllog"),bLogs.Menu.LogInfo.FullLog)

		bLogs.Menu.LogInfo.Involved = vgui.Create("DPanel")
		bLogs.Menu.LogInfo.Involved.onbLogsSetup = function()
			bLogs.Menu.LogInfo.Involved:SetParent(bLogs.Menu.LogInfo)
			bLogs.Menu.LogInfo.Involved:SetSize(bLogs.Menu.LogInfo:GetWide(),bLogs.Menu.LogInfo:GetTall() - 24 - 35)
		end
		local line___id = 0
		bLogs.Menu.LogInfo.Involved.onLineSelected = function(line)
			if (IsValid(bLogs.Menu.LogInfo.Involved.Involved)) then bLogs.Menu.LogInfo.Involved.Involved:Remove() end

			line___id = line___id + 1

			bLogs.Menu.LogInfo.Involved.Involved = vgui.Create("DScrollPanel",bLogs.Menu.LogInfo.Involved)
			local it = bLogs.Menu.LogInfo.Involved.Involved
			it.MyID = line___id
			it.Players = {}
			it:SetSize(bLogs.Menu.LogInfo.Involved:GetWide(),bLogs.Menu.LogInfo.Involved:GetTall())
			it.Paint = function(self) end

			local lineInfo = line.Info
			if (not lineInfo) then return end
			if (#lineInfo == 0) then
				local nothing = vgui.Create("DLabel",it)
				nothing:SetText(bLogs.Translate("nobodyinvolved"))
				nothing:SetFont("blogs_roboto16")
				nothing:SetTextColor(Color(0,0,0))
				nothing:SizeToContents()
				nothing:SetPos((it:GetWide() / 2) - (nothing:GetWide() / 2),(it:GetTall() / 2) - (nothing:GetTall() / 2))
			else
				for _,v in pairs(lineInfo) do
					v = bLogs.SteamIDConvert(v)
					local ply = player.GetBySteamID64(v)

					local plyPanel = vgui.Create("DPanel",it)
					it.Players[v] = plyPanel
					plyPanel.PlyID = v
					plyPanel:SetSize(it:GetWide(),90)
					plyPanel:AlignTop(90 * (table.Count(it.Players) - 1))
					plyPanel.Paint = function(self)
						surface.SetDrawColor(Color(242,242,242))
						surface.DrawRect(1,0,self:GetWide(),self:GetTall())

						surface.SetDrawColor(Color(206,206,206))
						surface.DrawRect(1,self:GetTall() - 1,self:GetWide() - 1,1)
					end

					if (IsValid(ply)) then
						plyPanel.Player = ply
						plyPanel.plyModelUnder = vgui.Create("DPanel",plyPanel)
						plyPanel.plyModelUnder.Paint = function(self)
							surface.SetDrawColor(Color(26,26,26))
							surface.DrawRect(0,0,self:GetWide(),self:GetTall())
						end
						plyPanel.plyModel = vgui.Create("DModelPanel",plyPanel)
						plyPanel.plyModel:SetSize(plyPanel:GetTall() - 10,plyPanel:GetTall() - 10)
						plyPanel.plyModel:AlignRight(5)
						plyPanel.plyModel:AlignTop(5)
						plyPanel.plyModelUnder:SetSize(plyPanel.plyModel:GetSize())
						plyPanel.plyModelUnder:SetPos(plyPanel.plyModel:GetPos())
						plyPanel.plyModel:SetModel(ply:GetModel())
						if (IsValid(plyPanel.plyModel.Entity)) then
							local bodygroups = ""
							for i=0,ply:GetNumBodyGroups() do
								bodygroups = bodygroups .. ply:GetBodygroup(i)
							end
							plyPanel.plyModel.Entity:SetBodyGroups(bodygroups)
							plyPanel.plyModel:SetFOV(40)
							local angl = 60
							plyPanel.plyModel:SetCamPos(Vector(30,-15,angl))
							plyPanel.plyModel:SetLookAt(Vector(0,0,(angl - 4)))
							plyPanel.plyModel.Entity:SetEyeTarget(Vector(200,200,110))
							function plyPanel.plyModel.Entity:GetPlayerColor() return ply:GetPlayerColor() end
						end
					end

					plyPanel.SteamIDs = vgui.Create("DLabel",plyPanel)
					plyPanel.SteamIDs:SetText(v .. " / " .. util.SteamIDFrom64(v))
					plyPanel.SteamIDs:SetTextColor(Color(0,0,0))
					plyPanel.SteamIDs:SetFont("blogs_roboto16")
					plyPanel.SteamIDs:SizeToContents()
					plyPanel.SteamIDs:SetWide(plyPanel:GetWide() - 180)
					plyPanel.SteamIDs:AlignLeft(90)
					plyPanel.SteamIDs:AlignTop(5)

					local nom = "Offline / Loading"
					if (IsValid(ply)) then
						nom = ply:Nick() .. " / Loading"
					end
					plyPanel.NameLabel = vgui.Create("DLabel",plyPanel)
					plyPanel.NameLabel:SetText(nom)
					plyPanel.NameLabel:SetTextColor(Color(0,0,0))
					plyPanel.NameLabel:SetFont("blogs_roboto16")
					plyPanel.NameLabel:SizeToContents()
					plyPanel.NameLabel:SetWide(plyPanel:GetWide() - 180)
					plyPanel.NameLabel:AlignLeft(90)
					plyPanel.NameLabel:AlignTop(5 + plyPanel.SteamIDs:GetTall())

					if (ulx and IsValid(ply) and ply ~= LocalPlayer()) then
						plyPanel.ULXButton = vgui.Create("DImageButton",plyPanel)
						plyPanel.ULXButton:SetSize(16,16)
						plyPanel.ULXButton:AlignBottom(5)
						plyPanel.ULXButton:SetImage("icon16/lightning.png")
						plyPanel.ULXButton:AlignLeft(111)
						plyPanel.ULXButton.DoClick = function()
							local menu = DermaMenu()
							local ayy = menu:AddOption("ULX")
							ayy:SetImage("icon16/lightning.png")
							function ayy:OnMousePressed() end

							menu:AddSpacer()

							local w = menu:AddOption("Goto")
							w:SetImage("icon16/lightning_go.png")
							function w:OnMousePressed()
								RunConsoleCommand("ulx","goto",ply:Nick())
							end

							local w = menu:AddOption("Bring")
							w:SetImage("icon16/lightning_delete.png")
							function w:OnMousePressed()
								RunConsoleCommand("ulx","bring",ply:Nick())
							end

							local w = menu:AddOption("Spectate")
							w:SetImage("icon16/eye.png")
							function w:OnMousePressed()
								RunConsoleCommand("ulx","spectate",ply:Nick())
							end

							menu:Open()
						end
					end

					plyPanel.CopyButton = vgui.Create("DImageButton",plyPanel)
					plyPanel.CopyButton:SetSize(16,16)
					plyPanel.CopyButton:AlignBottom(5)
					plyPanel.CopyButton:SetImage("icon16/page_copy.png")
					plyPanel.CopyButton:AlignLeft(90)
					plyPanel.CopyButton.DoClick = function()
						local menu = DermaMenu()

						local ayy = menu:AddOption(bLogs.Translate("copyvalues"))
						ayy:SetImage("icon16/page_copy.png")
						function ayy:OnMousePressed() end

						menu:AddSpacer()

						local w = menu:AddOption(bLogs.Translate("copywithquotes"))
						local ws = '"'
						if (bLogs.CopyWithQuotes == true) then
							w:SetImage("icon16/accept.png")
						else
							w:SetImage("icon16/cancel.png")
						end
						function w:OnMousePressed()
							if (bLogs.CopyWithQuotes == true) then
								ws = ''
								w:SetImage("icon16/cancel.png")
								bLogs.CopyWithQuotes = false
							else
								ws = '"'
								w:SetImage("icon16/accept.png")
								bLogs.CopyWithQuotes = true
							end
						end

						local cl = menu:AddOption(bLogs.Translate("closeoncopy"))
						if (bLogs.CloseOnCopy == true) then
							cl:SetImage("icon16/accept.png")
						else
							cl:SetImage("icon16/cancel.png")
						end
						function cl:OnMousePressed()
							if (bLogs.CloseOnCopy == true) then
								cl:SetImage("icon16/cancel.png")
								bLogs.CloseOnCopy = false
							else
								cl:SetImage("icon16/accept.png")
								bLogs.CloseOnCopy = true
							end
						end

						local cli = menu:AddOption(bLogs.Translate("closeloginfooncopy"))
						if (bLogs.CloseInfoOnCopy == true) then
							cli:SetImage("icon16/accept.png")
						else
							cli:SetImage("icon16/cancel.png")
						end
						function cli:OnMousePressed()
							if (bLogs.CloseInfoOnCopy == true) then
								cli:SetImage("icon16/cancel.png")
								bLogs.CloseInfoOnCopy = false
							else
								cli:SetImage("icon16/accept.png")
								bLogs.CloseInfoOnCopy = true
							end
						end

						local function sSetClipboardText(txt)
							SetClipboardText(txt)
							if (bLogs.CloseOnCopy == true) then
								bLogs.Menu:Close()
							end
							if (bLogs.CloseInfoOnCopy == true) then
								bLogs.Menu.LogInfo:Close()
							end
						end

						menu:AddSpacer()
						if (IsValid(ply)) then
							menu:AddOption(ply:Nick(),function() sSetClipboardText(ws .. ply:Nick() .. ws) end):SetImage("icon16/user.png")
							if (plyPanel.myData ~= nil) then
								if (plyPanel.myData.personaname ~= ply:Nick()) then
									menu:AddOption(plyPanel.myData.personaname,function() sSetClipboardText(ws .. plyPanel.myData.personaname .. ws) end):SetImage("icon16/user_red.png")
								end
							end
							menu:AddOption(ply:SteamID(),function() sSetClipboardText(ws .. ply:SteamID() .. ws) end):SetImage("icon16/tag_blue.png")
							menu:AddOption(ply:SteamID64(),function() sSetClipboardText(ws .. ply:SteamID64() .. ws) end):SetImage("icon16/tag_red.png")
						elseif (plyPanel.myData ~= nil) then
							menu:AddSpacer()
							menu:AddOption(plyPanel.myData.personaname,function() sSetClipboardText(ws .. plyPanel.myData.personaname .. ws) end):SetImage("icon16/user_red.png")
							menu:AddOption(util.SteamIDFrom64(plyPanel.myData.steamid),function() sSetClipboardText(ws .. util.SteamIDFrom64(plyPanel.myData.steamid) .. ws) end):SetImage("icon16/tag_blue.png")
							menu:AddOption(plyPanel.myData.steamid,function() sSetClipboardText(ws .. plyPanel.myData.steamid .. ws) end):SetImage("icon16/tag_red.png")
						end
						menu:AddSpacer()
						menu:AddOption(bLogs.Translate("cancel")):SetImage("icon16/cancel.png")
						menu:Open()
					end

					plyPanel.plyImg = vgui.Create("DHTML",plyPanel)
					plyPanel.plyImg:SetSize(plyPanel:GetTall() - 10,plyPanel:GetTall() - 10)
					plyPanel.plyImg:AlignLeft(5)
					plyPanel.plyImg:AlignTop(5)
					plyPanel.plyImg:SetHTML([[<!DOCTYPE html>
<html>
<head>
	<style>
		body {
			width: 100%;
			height: 100%;
			background-color: #fff;
			margin: 0px;
		}

		div {
			background-size: 100% 100%;
			position: fixed;
			width: 100%;
			height: 100%;
			background-image: url(http://billyslogs.xyz/none.jpg);
		}
	</style>
	<script src="http://code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>
	<div></div>
</body>
</html>]])
				end

				http.Fetch("http://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key=72CB41ADBA562F3EFD26E2AA2BCDD55C&steamids=" .. table.concat(lineInfo,","),function(data2)
					local stuff = util.JSONToTable(data2)
					if (stuff == nil) then
						for i,v in pairs(it.Players or {}) do
							if (IsValid(v.Player)) then
								v.NameLabel:SetText(v.Player:Nick() .. " / " .. "Steam down")
							else
								v.NameLabel:SetText("Offline / Steam down")
							end
						end
					else
						local data = stuff["response"]["players"]
						if (not it.Players) then return end
						for i,v in pairs(it.Players) do
							for _,v_steam in pairs(data) do
								v.myData = v_steam
								if (v.PlyID == v_steam.steamid) then
									if (IsValid(v.Player)) then
										if (v.Player:Nick() == v_steam.personaname) then
											v.NameLabel:SetText(v.Player:Nick())
										else
											v.NameLabel:SetText(v.Player:Nick() .. " / " .. v_steam.personaname)
										end
									else
										v.NameLabel:SetText("Offline / " .. v_steam.personaname)
									end
									v.plyImg:AddFunction("console","openplayer",function()
										gui.OpenURL("http://www.steamid.ru/?q=" .. v_steam.steamid or v.Player:SteamID64())
									end)
									v.plyImg:SetHTML([[<!DOCTYPE html>
<html>
<head>
	<style>
		body {
			width: 100%;
			height: 100%;
			background-color: #fff;
			margin: 0px;
		}

		div {
			background-size: 100% 100%;
			position: fixed;
			width: 100%;
			height: 100%;
			background-image: url(]] .. v_steam.avatarfull .. [[);
			cursor: pointer;
		}
	</style>
	<script src="http://code.jquery.com/jquery-2.1.4.min.js"></script>
</head>
<body>
	<div></div>
	<script>
		$("div").click(function() {console.openplayer();});
	</script>
</body>
</html>]])
									break
								end
							end
						end
					end
				end,function()
					for _,v in pairs(it.Players) do
						if (IsValid(v.Player)) then
							v.NameLabel:SetText(v.Player:Nick() .. " / " .. "Steam down")
						else
							v.NameLabel:SetText("Offline / Steam down")
						end
					end
				end)
			end
		end
		bLogs.Menu.LogInfo.TopTabs:AddTab(bLogs.Translate("involved"),bLogs.Menu.LogInfo.Involved)


	bLogs.Menu.LogInfo.Title = vgui.Create("DLabel",bLogs.Menu.LogInfo)
	bLogs.Menu.LogInfo.Title:SetText("bLogs | " .. bLogs.Translate("loginfo"))
	bLogs.Menu.LogInfo.Title:SetFont("blogs_roboto16")
	bLogs.Menu.LogInfo.Title:SetTextColor(Color(255,255,255))
	bLogs.Menu.LogInfo.Title:SizeToContents()
	bLogs.Menu.LogInfo.Title:AlignTop(4)
	bLogs.Menu.LogInfo.Title:AlignLeft(4)

	bLogs.Menu.LogInfo.CloseButton = vgui.Create("DButton",bLogs.Menu.LogInfo)
	bLogs.Menu.LogInfo.CloseButton.Paint = function() end
	bLogs.Menu.LogInfo.CloseButton:SetSize(18,18)
	bLogs.Menu.LogInfo.CloseButton:SetText("X")
	bLogs.Menu.LogInfo.CloseButton:SetFont("blogs_roboto16")
	bLogs.Menu.LogInfo.CloseButton:SetTextColor(Color(255,255,255))
	bLogs.Menu.LogInfo.CloseButton:AlignRight(2)
	bLogs.Menu.LogInfo.CloseButton:AlignTop(2)
	bLogs.Menu.LogInfo.CloseButton.DoClick = function()
		bLogs.Menu.LogInfo:Close()
	end

	function bLogs.Menu.LogInfo:Close()
		if (bLogs.Menu.LogInfoBg.Open == false) then return end
		bLogs.Menu.LogInfoBg.Open = false

		timer.Stop("blogs_loginfo_open")
		local x = bLogs.Menu.LogInfo:GetPos()
		bLogs.Menu.LogInfo:Stop()
		bLogs.Menu.LogInfo:MoveTo(x,bLogs.Menu:GetTall(),0.5)
		bLogs.Menu.LogInfoBg.AlphaLevel = 225
		local i = 0
		timer.Create("blogs_loginfo_close",0.0001,0,function( ... )
			if (not IsValid(bLogs.Menu)) then timer.Remove("blogs_loginfo_close") return end
			if (not IsValid(bLogs.Menu.LogInfoBg)) then timer.Remove("blogs_loginfo_close") return end
			bLogs.Menu.LogInfoBg.AlphaLevel = math.Round(Lerp(0.1,bLogs.Menu.LogInfoBg.AlphaLevel,0))
			i = i + 1
			if (i == 5) then
				bLogs.Menu.LogInfoBg:SetMouseInputEnabled(false)
			end
			if (bLogs.Menu.LogInfoBg.AlphaLevel == 0) then
				timer.Remove("blogs_loginfo_close")
			end
		end)
	end

	function bLogs.Menu.LogInfo:Open()
		if (bLogs.Menu.LogInfoBg.Open == true) then return end
		bLogs.Menu.LogInfoBg.Open = true

		bLogs.Menu.LogInfoBg:SetMouseInputEnabled(true)
		timer.Stop("blogs_loginfo_close")
		local x = bLogs.Menu.LogInfo:GetPos()
		bLogs.Menu.LogInfo:Stop()
		bLogs.Menu.LogInfo:MoveTo(x,bLogs.Menu.LogInfo.YRequired,0.5)
		bLogs.Menu.LogInfoBg.AlphaLevel = 0
		timer.Create("blogs_loginfo_open",0.0001,0,function()
			if (not IsValid(bLogs.Menu)) then timer.Remove("blogs_loginfo_open") return end
			if (not IsValid(bLogs.Menu.LogInfoBg)) then timer.Remove("blogs_loginfo_open") return end
			bLogs.Menu.LogInfoBg.AlphaLevel = math.Round(Lerp(0.1,bLogs.Menu.LogInfoBg.AlphaLevel,225))
			if (bLogs.Menu.LogInfoBg.AlphaLevel == 225) then
				timer.Remove("blogs_loginfo_open")
			end
		end)
	end

	bLogs.Menu.Logs.LogContent.OnClickLine = function(_,line)
		if (not table.HasValue({bLogs.Translate("nologs"),bLogs.Translate("receivinginfo"),bLogs.Translate("selectlogger"),bLogs.Translate("noqueries")},line:GetValue(3))) then
			bLogs.Menu.LogInfo:Open()

			local stuff = {bLogs.Menu.LogInfo.FullLog,bLogs.Menu.LogInfo.Involved}
			for _,v in pairs(stuff) do
				if (v.onLineSelected ~= nil) then
					v.onLineSelected(line)
				end
			end
		end
	end

	bLogs.Menu.SavePopupBg = vgui.Create("DPanel",bLogs.Menu.Logs)
	bLogs.Menu.SavePopupBg.Open = false
	bLogs.Menu.SavePopupBg:SetMouseInputEnabled(false)
	bLogs.Menu.SavePopupBg:SetSize(bLogs.Menu.Logs:GetWide(),bLogs.Menu.Logs:GetTall())
	bLogs.Menu.SavePopupBg:AlignBottom(0)
	bLogs.Menu.SavePopupBg.AlphaLevel = 0
	bLogs.Menu.SavePopupBg.Paint = function(self)
		surface.SetDrawColor(Color(0,0,0,self.AlphaLevel))
		surface.DrawRect(0,0,self:GetWide(),self:GetTall())
	end
	function bLogs.Menu.SavePopupBg:OnMousePressed()
		bLogs.Menu.SavePopup:Close()
	end

	bLogs.Menu.SavePopup = vgui.Create("DPanel",bLogs.Menu.Logs)
	bLogs.Menu.SavePopup:SetSize(575,300)
	bLogs.Menu.SavePopup:Center()
	local x,y = bLogs.Menu.SavePopup:GetPos()
	bLogs.Menu.SavePopup.YRequired = y
	bLogs.Menu.SavePopup:SetPos(x,bLogs.Menu:GetTall())
	bLogs.Menu.SavePopup.Paint = function(self)
		surface.SetDrawColor(Color(255,255,255))
		surface.DrawRect(0,0,self:GetWide(),self:GetTall())

		surface.SetDrawColor(Color(26,26,26))
		surface.DrawRect(0,0,self:GetWide(),24)
	end

	bLogs.Menu.SavePopup.Title = vgui.Create("DLabel",bLogs.Menu.SavePopup)
	bLogs.Menu.SavePopup.Title:SetText("bLogs | " .. bLogs.Translate("save"))
	bLogs.Menu.SavePopup.Title:SetFont("blogs_roboto16")
	bLogs.Menu.SavePopup.Title:SetTextColor(Color(255,255,255))
	bLogs.Menu.SavePopup.Title:SizeToContents()
	bLogs.Menu.SavePopup.Title:AlignTop(4)
	bLogs.Menu.SavePopup.Title:AlignLeft(4)

	bLogs.Menu.SavePopup.CloseButton = vgui.Create("DButton",bLogs.Menu.SavePopup)
	bLogs.Menu.SavePopup.CloseButton.Paint = function() end
	bLogs.Menu.SavePopup.CloseButton:SetSize(18,18)
	bLogs.Menu.SavePopup.CloseButton:SetText("X")
	bLogs.Menu.SavePopup.CloseButton:SetFont("blogs_roboto16")
	bLogs.Menu.SavePopup.CloseButton:SetTextColor(Color(255,255,255))
	bLogs.Menu.SavePopup.CloseButton:AlignRight(2)
	bLogs.Menu.SavePopup.CloseButton:AlignTop(2)
	bLogs.Menu.SavePopup.CloseButton.DoClick = function()
		bLogs.Menu.SavePopup:Close()
	end

	function bLogs.Menu.SavePopup:Close()
		if (bLogs.Menu.SavePopupBg.Open == false) then return end
		bLogs.Menu.SavePopupBg.Open = false

		timer.Stop("blogs_SavePopup_open")
		local x = bLogs.Menu.SavePopup:GetPos()
		bLogs.Menu.SavePopup:Stop()
		bLogs.Menu.SavePopup:MoveTo(x,bLogs.Menu:GetTall(),0.5)
		bLogs.Menu.SavePopupBg.AlphaLevel = 225
		local i = 0
		timer.Create("blogs_SavePopup_close",0.0001,0,function()
			if (not IsValid(bLogs.Menu)) then timer.Remove("blogs_SavePopup_close") return end
			if (not IsValid(bLogs.Menu.LogInfoBg)) then timer.Remove("blogs_SavePopup_close") return end
			bLogs.Menu.SavePopupBg.AlphaLevel = math.Round(Lerp(0.1,bLogs.Menu.SavePopupBg.AlphaLevel,0))
			i = i + 1
			if (i == 5) then
				bLogs.Menu.SavePopupBg:SetMouseInputEnabled(false)
			end
			if (bLogs.Menu.SavePopupBg.AlphaLevel == 0) then
				timer.Remove("blogs_SavePopup_close")
			end
		end)
	end

	function bLogs.Menu.SavePopup:Open()
		if (bLogs.Menu.SavePopupBg.Open == true) then return end
		bLogs.Menu.SavePopupBg.Open = true

		bLogs.Menu.SavePopupBg:SetMouseInputEnabled(true)
		timer.Stop("blogs_SavePopup_close")
		local x = bLogs.Menu.SavePopup:GetPos()
		bLogs.Menu.SavePopup:Stop()
		bLogs.Menu.SavePopup:MoveTo(x,bLogs.Menu.SavePopup.YRequired,0.5)
		bLogs.Menu.SavePopupBg.AlphaLevel = 0
		timer.Create("blogs_SavePopup_open",0.0001,0,function()
			if (not IsValid(bLogs.Menu)) then timer.Remove("blogs_SavePopup_open") return end
			if (not IsValid(bLogs.Menu.LogInfoBg)) then timer.Remove("blogs_SavePopup_open") return end
			bLogs.Menu.SavePopupBg.AlphaLevel = math.Round(Lerp(0.1,bLogs.Menu.SavePopupBg.AlphaLevel,225))
			if (bLogs.Menu.SavePopupBg.AlphaLevel == 225) then
				timer.Remove("blogs_SavePopup_open")
			end
		end)
	end

	bLogs.Menu.SavePopup.Text1 = vgui.Create("DLabel",bLogs.Menu.SavePopup)
	bLogs.Menu.SavePopup.Text1:SetFont("blogs_roboto16")
	bLogs.Menu.SavePopup.Text1:SetTextColor(Color(0,0,0))
	bLogs.Menu.SavePopup.Text1:AlignLeft(110)
	bLogs.Menu.SavePopup.Text1:AlignTop(24 + 7)
	bLogs.Menu.SavePopup.Text1:SetText(bLogs.Translate("to"))
	bLogs.Menu.SavePopup.Text1:SizeToContents()

	bLogs.Menu.SavePopup.Page1 = vgui.Create("DComboBox",bLogs.Menu.SavePopup)
	bLogs.Menu.SavePopup.Page1:AlignLeft(5)
	bLogs.Menu.SavePopup.Page1:AlignTop(24 + 5)
	bLogs.Menu.SavePopup.Page1:SetWidth(100)
	bLogs.Menu.SavePopup.Page1:SetValue("X")

	bLogs.Menu.SavePopup.Page2 = vgui.Create("DComboBox",bLogs.Menu.SavePopup)
	bLogs.Menu.SavePopup.Page2:AlignLeft(5)
	bLogs.Menu.SavePopup.Page2:AlignTop(24 + 5 + bLogs.Menu.SavePopup.Page1:GetTall() + 5)
	bLogs.Menu.SavePopup.Page2:SetWidth(100)
	bLogs.Menu.SavePopup.Page2:SetValue("X")

	bLogs.Menu.SavePopup.Text2 = vgui.Create("DLabel",bLogs.Menu.SavePopup)
	bLogs.Menu.SavePopup.Text2:SetFont("blogs_roboto16")
	bLogs.Menu.SavePopup.Text2:SetTextColor(Color(0,0,0))
	bLogs.Menu.SavePopup.Text2:AlignLeft(5)
	bLogs.Menu.SavePopup.Text2:AlignTop(24 + 5 + bLogs.Menu.SavePopup.Page1:GetTall() + 5 + bLogs.Menu.SavePopup.Page2:GetTall() + 5)
	bLogs.Menu.SavePopup.Text2:SetText(bLogs.Translate("onlysave_1") .. " 1 " .. bLogs.Translate("oflogger") .. " \"" .. bLogs.Translate("all") .. '"')
	bLogs.Menu.SavePopup.Text2:SizeToContents()

	bLogs.Menu.SavePopup.SaveForbLogs = vgui.Create("DButton",bLogs.Menu.SavePopup)
	bLogs.Menu.SavePopup.SaveForbLogs:SetDisabled(false)
	bLogs.Menu.SavePopup.SaveForbLogs:SetFont("blogs_roboto16")
	bLogs.Menu.SavePopup.SaveForbLogs:SetText(bLogs.Translate("saveforblogs"))
	bLogs.Menu.SavePopup.SaveForbLogs:SetTextColor(Color(255,255,255))
	bLogs.Menu.SavePopup.SaveForbLogs:SetSize(140,25)
	bLogs.Menu.SavePopup.SaveForbLogs:AlignBottom(5)
	bLogs.Menu.SavePopup.SaveForbLogs:AlignLeft(5)
	bLogs.Menu.SavePopup.SaveForbLogs.Paint = btnPaintNoBorder
	bLogs.Menu.SavePopup.SaveForbLogs.DoClick = function()
		Derma_StringRequest(bLogs.Translate("saveforblogs"),bLogs.Translate("saveforblogs_msg"),"",function(name)
			name = string.Trim(name)
			if (name == "") then
				name = "Untitled"
			end
			name = name .. ".txt"
			file.Write("blogs/logs/json/" .. name,"")

			bLogs.Menu.SavePopup.SaveForbLogs:SetDisabled(true)
			bLogs.Menu.SavePopup.ExportForHumans:SetDisabled(true)
			bLogs.Menu.SavePopup.SaveForbLogs:SetText("...")

			net.Receive("blogs_request_pagerange",function()
				local data_num = net.ReadDouble()
				local data = net.ReadData(data_num)
				data = util.Decompress(data)
				data = util.Compress(data)

				file.Write("blogs/logs/json/" .. name,data)
				if (bLogs.Menu.Saves.OpenSave:GetLines()[1]:GetValue(1) == bLogs.Translate("nosaves")) then
					bLogs.Menu.Saves.OpenSave:RemoveLine(1)
				end
				bLogs.Menu.Saves.OpenSave:AddLine_(string.gsub(name,"%.txt$",""),bLogs.Translate("blogsonly"))

				bLogs.Menu.SavePopup:Close()
				bLogs.Menu.SavePopup.SaveForbLogs:SetDisabled(false)
				bLogs.Menu.SavePopup.ExportForHumans:SetDisabled(false)
				bLogs.Menu.SavePopup.SaveForbLogs:SetText(bLogs.Translate("saveforblogs"))
			end)

			local p1 = string.gsub(bLogs.Menu.SavePopup.Page1:GetValue(),bLogs.Translate("page") .. '%s','')
			p1 = tonumber(p1)

			local p2 = string.gsub(bLogs.Menu.SavePopup.Page2:GetValue(),bLogs.Translate("page") .. '%s','')
			p2 = tonumber(p2)

			net.Start("blogs_request_pagerange")
				net.WriteDouble(p1)
				net.WriteDouble(p2)
				net.WriteString(bLogs.Menu.Logs.LogContent.CurrentLogger)
				if (bLogs.Menu.Logs.SavePanel.CancelSearch.Refresh == true) then
					net.WriteString(bLogs.Menu.Logs.SavePanel.SearchBox:GetText())
				end
			net.SendToServer()
		end,nil,bLogs.Translate("save"),bLogs.Translate("cancel"))
	end

	bLogs.Menu.SavePopup.ExportForHumans = vgui.Create("DButton",bLogs.Menu.SavePopup)
	bLogs.Menu.SavePopup.ExportForHumans:SetDisabled(false)
	bLogs.Menu.SavePopup.ExportForHumans:SetFont("blogs_roboto16")
	bLogs.Menu.SavePopup.ExportForHumans:SetText(bLogs.Translate("exportforhumans"))
	bLogs.Menu.SavePopup.ExportForHumans:SetTextColor(Color(255,255,255))
	bLogs.Menu.SavePopup.ExportForHumans:SetSize(140,25)
	bLogs.Menu.SavePopup.ExportForHumans:AlignBottom(5)
	bLogs.Menu.SavePopup.ExportForHumans:AlignLeft(150)
	bLogs.Menu.SavePopup.ExportForHumans.Paint = btnPaintNoBorder
	bLogs.Menu.SavePopup.ExportForHumans.DoClick = function()
		Derma_StringRequest(bLogs.Translate("exportforhumans"),bLogs.Translate("saveforblogs_msg"),"",function(name)
			name = string.Trim(name)
			if (name == "") then
				name = "Untitled"
			end
			name = name .. ".txt"
			file.Write("blogs/logs/" .. name,"")

			bLogs.Menu.SavePopup.ExportForHumans:SetDisabled(true)
			bLogs.Menu.SavePopup.SaveForbLogs:SetDisabled(true)
			bLogs.Menu.SavePopup.ExportForHumans:SetText("...")

			net.Receive("blogs_request_pagerange",function()
				local data_num = net.ReadDouble()
				local data = net.ReadData(data_num)
				data = util.Decompress(data)
				data = util.JSONToTable(data)

				file.Append("blogs/logs/" .. name,"[bLogs Save (for humans) | This cannot be loaded on bLogs]\r\n")
				for _,v in pairs(data) do
					file.Append("blogs/logs/" .. name,"[" .. bLogs.FormatTime(v.time) .. "] (" .. v.module .. ") " .. bLogs.RemoveEscapables(v.txt) .. "\r\n")
				end
				if (bLogs.Menu.Saves.OpenSave:GetLines()[1]:GetValue(1) == bLogs.Translate("nosaves")) then
					bLogs.Menu.Saves.OpenSave:RemoveLine(1)
				end
				bLogs.Menu.Saves.OpenSave:AddLine_(string.gsub(name,"%.txt$",""),"Human")

				bLogs.Menu.SavePopup:Close()
				bLogs.Menu.SavePopup.ExportForHumans:SetDisabled(false)
				bLogs.Menu.SavePopup.SaveForbLogs:SetDisabled(false)
				bLogs.Menu.SavePopup.ExportForHumans:SetText("Export for humans")
			end)

			local p1 = string.gsub(bLogs.Menu.SavePopup.Page1:GetValue(),bLogs.Translate("page") .. '%s','')
			p1 = tonumber(p1)

			local p2 = string.gsub(bLogs.Menu.SavePopup.Page2:GetValue(),bLogs.Translate("page") .. '%s','')
			p2 = tonumber(p2)

			net.Start("blogs_request_pagerange")
				net.WriteDouble(p1)
				net.WriteDouble(p2)
				net.WriteString(bLogs.Menu.Logs.LogContent.CurrentLogger)
				if (bLogs.Menu.Logs.SavePanel.CancelSearch.Refresh == true) then
					net.WriteString(bLogs.Menu.Logs.SavePanel.SearchBox:GetText())
				end
			net.SendToServer()
		end,nil,"Save","Cancel")
	end

	bLogs.Menu.SavePopup.HelpButton = vgui.Create("DButton",bLogs.Menu.SavePopup)
	bLogs.Menu.SavePopup.HelpButton.Paint = function() end
	bLogs.Menu.SavePopup.HelpButton:SetSize(18,18)
	bLogs.Menu.SavePopup.HelpButton:SetText("?")
	bLogs.Menu.SavePopup.HelpButton:SetFont("blogs_roboto16")
	bLogs.Menu.SavePopup.HelpButton:SetTextColor(Color(0,0,0))
	bLogs.Menu.SavePopup.HelpButton:AlignLeft(290)
	bLogs.Menu.SavePopup.HelpButton:AlignBottom(8)
	bLogs.Menu.SavePopup.HelpButton.DoClick = function()
		gui.OpenURL("http://wiki.billyslogs.xyz/index.php/Saving")
	end

	function bLogs.Menu.SavePopup.Page1:OnSelect(i)
		local v = string.gsub(bLogs.Menu.SavePopup.Page2:GetValue(),bLogs.Translate("page") .. '%s','')
		v = tonumber(v)
		if (i > v) then
			bLogs.Menu.SavePopup.Text2:AlignLeft(5)
			bLogs.Menu.SavePopup.Text2:SetText("Invalid!")
			bLogs.Menu.SavePopup.Text2:SizeToContents()

			bLogs.Menu.SavePopup.ExportForHumans:SetDisabled(true)
			bLogs.Menu.SavePopup.SaveForbLogs:SetDisabled(true)
		elseif (i == v) then
			bLogs.Menu.SavePopup.Text2:AlignLeft(5)
			bLogs.Menu.SavePopup.Text2:SetText(bLogs.Translate("onlysave_1") .. " " .. i .. " " .. bLogs.Translate("onlysave_2") .. " \"" .. bLogs.Menu.Logs.LogContent.CurrentLogger .. '"')
			bLogs.Menu.SavePopup.Text2:SizeToContents()

			bLogs.Menu.SavePopup.ExportForHumans:SetDisabled(false)
			bLogs.Menu.SavePopup.SaveForbLogs:SetDisabled(false)
		else
			bLogs.Menu.SavePopup.Text2:AlignLeft(5)
			bLogs.Menu.SavePopup.Text2:SetText(bLogs.Translate("savepage") .. " " .. v .. " to page " .. i .. " " .. bLogs.Translate("onlysave_2") .. " \"" .. bLogs.Menu.Logs.LogContent.CurrentLogger .. '"')
			bLogs.Menu.SavePopup.Text2:SizeToContents()

			bLogs.Menu.SavePopup.ExportForHumans:SetDisabled(false)
			bLogs.Menu.SavePopup.SaveForbLogs:SetDisabled(false)
		end
	end

	function bLogs.Menu.SavePopup.Page2:OnSelect(i)
		local v = string.gsub(bLogs.Menu.SavePopup.Page1:GetValue(),bLogs.Translate("page") .. '%s','')
		v = tonumber(v)
		if (i > v) then
			bLogs.Menu.SavePopup.Text2:AlignLeft(5)
			bLogs.Menu.SavePopup.Text2:SetText(bLogs.Translate("savepage") .. " " .. v .. " to page " .. i .. " " .. bLogs.Translate("onlysave_2") .. " \"" .. bLogs.Menu.Logs.LogContent.CurrentLogger .. '"')
			bLogs.Menu.SavePopup.Text2:SizeToContents()

			bLogs.Menu.SavePopup.ExportForHumans:SetDisabled(false)
			bLogs.Menu.SavePopup.SaveForbLogs:SetDisabled(false)
		elseif (i == v) then
			bLogs.Menu.SavePopup.Text2:AlignLeft(5)
			bLogs.Menu.SavePopup.Text2:SetText(bLogs.Translate("onlysave_1") .. " " .. i .. " " .. bLogs.Translate("onlysave_2") .. " \"" .. bLogs.Menu.Logs.LogContent.CurrentLogger .. '"')
			bLogs.Menu.SavePopup.Text2:SizeToContents()

			bLogs.Menu.SavePopup.ExportForHumans:SetDisabled(false)
			bLogs.Menu.SavePopup.SaveForbLogs:SetDisabled(false)
		else
			bLogs.Menu.SavePopup.Text2:AlignLeft(5)
			bLogs.Menu.SavePopup.Text2:SetText(bLogs.Translate("invalid"))
			bLogs.Menu.SavePopup.Text2:SizeToContents()

			bLogs.Menu.SavePopup.ExportForHumans:SetDisabled(true)
			bLogs.Menu.SavePopup.SaveForbLogs:SetDisabled(true)
		end
	end

	bLogs.Menu.Language = vgui.Create("DComboBox",bLogs.Menu)
	bLogs.Menu.Language:SetSize(100,22)
	bLogs.Menu.Language:AlignLeft(2)
	bLogs.Menu.Language:AlignTop(2)
	bLogs.Menu.Language:SetText(bLogs.Language)
	bLogs.Menu.Language:AddChoice("English")
	bLogs.Menu.Language:AddChoice("Developer")
	local langs = file.Find("blogs/lang/*","LUA")
	for _,v in pairs(langs) do
		bLogs.Menu.Language:AddChoice(v:sub(1,1):upper() .. v:sub(2):gsub("%.lua$",""))
	end
	bLogs.Menu.Language.OnSelect = function(p,i,v)
		if (v == bLogs.Language) then return end
		bLogs.Language = v
		lang_setup = nil
		file.Write("blogs/language.txt",v)
		bLogs.Menu:Close()
		RunConsoleCommand("blogs_menu")
	end

	bLogs.Menu.Title = vgui.Create("DLabel",bLogs.Menu)
	bLogs.Menu.Title:SetTextColor(Color(255,255,255))
	bLogs.Menu.Title:SetFont("blogs_roboto16")
	bLogs.Menu.Title:SetText("")
	bLogs.Menu.Title.Think = function()
		if (not IsValid(bLogs.Menu)) then return end
		bLogs.Menu.Title:SetText(bLogs.Menu.lblTitle:GetText())
		bLogs.Menu.Title:SizeToContents()
		bLogs.Menu.Title:AlignLeft(107)
		bLogs.Menu.Title:AlignTop(5)
	end

	bLogs.Menu.HelpButton = vgui.Create("DButton",bLogs.Menu)
	bLogs.Menu.HelpButton.Paint = function() end
	bLogs.Menu.HelpButton:SetSize(18,18)
	bLogs.Menu.HelpButton:SetText("?")
	bLogs.Menu.HelpButton:SetFont("blogs_roboto16")
	bLogs.Menu.HelpButton:SetTextColor(Color(255,255,255))
	bLogs.Menu.HelpButton:AlignRight(4 + 18)
	bLogs.Menu.HelpButton:AlignTop(2)
	bLogs.Menu.HelpButton.DoClick = function()
		gui.OpenURL("http://wiki.billyslogs.xyz/")
	end

	hook.Run("blogs_menuopened")

	bLogs.Menu.CloseButton = vgui.Create("DButton",bLogs.Menu)
	bLogs.Menu.CloseButton.Paint = function() end
	bLogs.Menu.CloseButton:SetSize(18,18)
	bLogs.Menu.CloseButton:SetText("X")
	bLogs.Menu.CloseButton:SetFont("blogs_roboto16")
	bLogs.Menu.CloseButton:SetTextColor(Color(255,255,255))
	bLogs.Menu.CloseButton:AlignRight(2)
	bLogs.Menu.CloseButton:AlignTop(2)
	bLogs.Menu.CloseButton.DoClick = function()
		if (net.Receivers["blogs_sendreceive_page"] ~= nil) then net.Receivers["blogs_sendreceive_page"] = nil end
		net.Start("blogs_closemenu")
		net.SendToServer()
		bLogs.Menu:Close()
	end
	bLogs.Menu:ShowCloseButton(false)
end)

local _,mods = file.Find("blogs/mods/*","LUA")
for _,mod in pairs(mods) do
	local cl = file.Find("blogs/mods/" .. mod .. "/cl/*.lua","LUA")
	for _,clf in pairs(cl) do
		include("blogs/mods/" .. mod .. "/cl/" .. clf)
	end
	local sh = file.Find("blogs/mods/" .. mod .. "/sh/*.lua","LUA")
	for _,shf in pairs(sh) do
		include("blogs/mods/" .. mod .. "/sh/" .. shf)
	end
end
