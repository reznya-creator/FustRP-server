local RunString=RunString;local http=http;local debug=debug;local timer=timer;_G.bLogsLicensee="76561198113240446"_G.bLogsVersion="B8"AddCSLuaFile("blogs/sh_config.lua")bLogs={}bLogs.CustomConfigRaw={}if not pcall(function()include("../../blogs/sh_config.lua")end)then include("blogs/sh_config.lua")end;if file.Read("blogs/configcache.dat","DATA")~=file.Read("blogs/sh_config.lua","LUA")then file.Write("blogs/configcache.dat",file.Read("blogs/sh_config.lua","LUA"))end;function bLogs.print(a,b)if type(a)~="string"then return end;if b~=nil then if type(b)~="string"then return end end;if b=="neutral"or b=="none"or b==nil then MsgC(Color(255,255,255),"[",Color(0,255,255),"bLogs",Color(255,255,255),"] "..a.."\n")elseif b=="bad"or b=="error"then MsgC(Color(255,255,255),"[",Color(255,0,0),"bLogs",Color(255,255,255),"] "..a.."\n")elseif b=="good"or b=="success"then MsgC(Color(255,255,255),"[",Color(0,255,0),"bLogs",Color(255,255,255),"] "..a.."\n")else MsgC(Color(255,255,255),"[",Color(0,255,255),"bLogs",Color(255,255,255),"] "..a.."\n")end end;file.CreateDir("blogs")

local function go()
	BLib("bLogs","1599","B8",'93c137907c390eb44ba7295dac9a1a56')
end
if (BLibLoaded) then
	go()
else
	hook.Add("blib_load","blogs_load_blib",go)
end
