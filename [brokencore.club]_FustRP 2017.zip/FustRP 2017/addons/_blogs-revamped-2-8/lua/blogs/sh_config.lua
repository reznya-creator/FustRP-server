bLogs.Config = {} local config = bLogs.Config

--// http://billyslogs.xyz/wiki/index.php/Configuration

--// These are root users.
--// Anyone who is a root user can edit the config and access everything.
--// Enter usergroups, SteamIDs, SteamID64s and TEAM_JOB jobs (or team numbers).
--// For the more advanced, you can even add functions! return true to allow.
--// Example:
--// function(ply) if (ply:Nick() == "admin to meeee!!!") then return true end end

config.Root = {"","STEAM_0:0","superadmin"}
