bLogs.MySQL = {}
local Sensitive = {}

bLogs.MySQL.Enabled = false

--// http://billyslogs.xyz/wiki/index.php/Configuration#MySQL

--// The IP Address CANNOT be localhost.

--// tMySQL4 IS REQUIRED!

--// The reason why I do not support mysqloo is because:
--// 1) mysqloo sometimes creates memory leaks
--// 2) mysqloo sometimes does not even go through with a query
--// 3) mysqloo doesnt reconnect to the database
--// 4) mysqloo does not queue anything

--// NOTE: If you have a domain that points to your MySQL server, you can use it here, too.
Sensitive.IPAddress = ""
Sensitive.Port = 3306
Sensitive.Username = ""
Sensitive.Password = ""
Sensitive.Database = ""

--// Enable this to see MySQL queries and raw tMySQL4 results.
bLogs.MySQL.Debug = false

--/////////////////////////////////////////////////////////////////////////////////--

hook.Remove("blogs_player","blogs_mysql_player")
hook.Remove("blogs_log","blogs_mysql_log")
if (bLogs.MySQL.Database) then
	bLogs.MySQL.Database:Disconnect()
end

local function mysql_init()
	if (bLogs.MySQL.Enabled == true) then

		(function()
			local tmysql4 = file.Exists("bin/gmsv_tmysql4_*.dll","LUA")
			if (tmysql4 == true) then
				require("tmysql4")
				bLogs.print("tMySQL4 is installed!","good")
				bLogs.print("Connecting to database...")

				if (type(Sensitive.IPAddress) ~= "string") then
					bLogs.print("Your configuration is malformed. (IP Address must be a string)","error")
					return
				end
				if (type(Sensitive.IPAddress) == "localhost") then
					bLogs.print("Your configuration is malformed. (IP Address cannot be localhost)","error")
					return
				end
				if (type(Sensitive.Port) ~= "number") then
					bLogs.print("Your configuration is malformed. (Port must be a number)","error")
					return
				end
				if (type(Sensitive.Username) ~= "string") then
					bLogs.print("Your configuration is malformed. (Username must be a string)","error")
					return
				end
				if (type(Sensitive.Password) ~= "string") then
					bLogs.print("Your configuration is malformed. (Password must be a string)","error")
					return
				end
				if (type(Sensitive.Database) ~= "string") then
					bLogs.print("Your configuration is malformed. (Database must be a string)","error")
					return
				end
				if (string.find(Sensitive.IPAddress,"%s")) then
					bLogs.print("Your configuration is malformed. (IP Address contains space(s))","error")
					return
				end
				if (string.find(Sensitive.Database,"%s")) then
					bLogs.print("Your configuration is malformed. (Database contains space(s))","error")
					return
				end

				bLogs.MySQL.Database,bLogs.MySQL.Error = tmysql.initialize(Sensitive.IPAddress,Sensitive.Username,Sensitive.Password,Sensitive.Database,Sensitive.Port)

				if (not bLogs.MySQL.Database) then
					bLogs.print("Could not connect to database: " .. (bLogs.MySQL.Error or "UNKNOWN"),"error")
					return
				else
					bLogs.print("Connected to database successfully!","good")
					bLogs.print("NOTE: MySQL only does anything when a player is connected.","bad")

					function bLogs.MySQL.Query(query_text_,callback,raw, ... )
						local query_text = ""
						for _,v in pairs(string.Explode("\n",query_text_)) do
							query_text = query_text .. string.Trim(v) .. "\n"
						end
						query_text = string.sub(query_text,1,-2)
						if (bLogs.MySQL.Debug == true) then
							bLogs.print(query_text,"bad")
						end
						bLogs.MySQL.Database:Query(query_text,function(results, ... )
							if (bLogs.MySQL.Debug == true) then
								PrintTable(results)
							end
							if (results[1].error ~= nil) then
								bLogs.print("Error with query: " .. results[1].error,"bad")
								return
							end
							if (callback) then
								if (raw == true) then
									callback(results, ... )
								else
									callback(results[1].data or {}, ... )
								end
							end
						end, ... )
					end

					bLogs.MySQL.Query([[SHOW TABLES WHERE
					`Tables_in_]] .. Sensitive.Database .. [[` LIKE '%blogs_servers%' OR
					`Tables_in_]] .. Sensitive.Database .. [[` LIKE '%blogs_players%' OR
					`Tables_in_]] .. Sensitive.Database .. [[` LIKE '%blogs%']],function(find_tables)
						local blogs_ = false
						local blogs_players_ = false
						local blogs_servers_ = false

						for _,v in pairs(find_tables) do
							if (v["Tables_in_" .. Sensitive.Database] == "blogs") then
								blogs_ = true
							elseif (v["Tables_in_" .. Sensitive.Database] == "blogs_players") then
								blogs_players_ = true
							elseif (v["Tables_in_" .. Sensitive.Database] == "blogs_servers") then
								blogs_servers_ = true
							end
						end

						if (blogs_ == false) then
							bLogs.print("Could not find the bLogs table! Creating it...","bad")

							bLogs.MySQL.Query([[CREATE TABLE IF NOT EXISTS `blogs` (
								`module` varchar(255) NOT NULL,
								`log` text NOT NULL,
								`involved` text,
								`time` int(11) NOT NULL,
								`ip_address` varchar(45) NOT NULL,
								`session` mediumint(9) NOT NULL,
								`id` mediumint(9) NOT NULL AUTO_INCREMENT,
								PRIMARY KEY (`id`),
								UNIQUE KEY `id` (`id`)
							) ENGINE=MyISAM DEFAULT CHARSET=utf8]])

							bLogs.print("Created successfully!","good")
						else
							bLogs.print("Found bLogs table!","good")
						end
						if (blogs_players_ == false) then
							bLogs.print("Could not find the bLogs Players table! Creating it...","bad")

							bLogs.MySQL.Query([[CREATE TABLE IF NOT EXISTS `blogs_players` (
								`steamid` varchar(85) DEFAULT NULL,
								`steamid64` tinyint(17) DEFAULT NULL,
								`lastnick` varchar(255) DEFAULT NULL,
								UNIQUE KEY `steamid` (`steamid`,`steamid64`)
							) ENGINE=MyISAM DEFAULT CHARSET=utf8]])

							bLogs.print("Created successfully!","good")
						else
							bLogs.print("Found players table!","good")
						end
						if (blogs_servers_ == false) then
							bLogs.print("Could not find the bLogs Servers table! Creating it...","bad")

							bLogs.MySQL.Query([[CREATE TABLE IF NOT EXISTS `blogs_servers` (
								`ip_address` varchar(45) NOT NULL,
								`name` varchar(255) DEFAULT NULL,
								UNIQUE KEY `ip_address` (`ip_address`)
							) ENGINE=MyISAM DEFAULT CHARSET=utf8]])

							bLogs.print("Created successfully!","good")
						else
							bLogs.print("Found servers table!","good")
						end

						MsgC("\n")
						bLogs.print("Grabbing session number...")

						bLogs.MySQL.Query("SELECT max(`session`) FROM `blogs`",function(max_session)
							Sensitive.Session = (max_session[1]["max(`session`)"] or 0) + 1
							bLogs.print("Session #" .. Sensitive.Session,"good")

							MsgC("\n")

							bLogs.print("Now logging!","good")

							MsgC("\n")

							bLogs.MySQL.Query("INSERT IGNORE INTO `blogs_servers` (`ip_address`) VALUES ('" .. game.GetIPAddress() .. "')")

							hook.Add("blogs_player","blogs_mysql_player",function(steamid,steamid64,nick)
								if (bLogs == nil) then return end
								if (bLogs.MySQL == nil) then return end
								bLogs.MySQL.Query("INSERT IGNORE INTO `blogs_players` (`steamid`,`steamid64`) VALUES ('" .. bLogs.MySQL.Database:Escape(steamid) .. "','" .. bLogs.MySQL.Database:Escape(steamid64) .. "')")
								bLogs.MySQL.Query("UPDATE `blogs_players` SET `lastnick`='" .. bLogs.MySQL.Database:Escape(nick) .. "' WHERE `steamid64`='" .. bLogs.MySQL.Database:Escape(steamid64) .. "'")
							end)
							hook.Add("blogs_log","blogs_mysql_log",function(logTable)
								local involved = {}
								for _,v in pairs(logTable.involved or {}) do
									if (type(v) == "Player") then
										table.insert(involved,{v:SteamID64(),v:SteamID(),v:Nick()})
									elseif (type(v) == "Entity") then
										table.insert(involved,tostring(v))
									else
										table.insert(involved,v)
									end
								end

								bLogs.MySQL.Query([[INSERT INTO `blogs` (`module`,`log`,`involved`,`time`,`ip_address`,`session`) VALUES
								(']] .. bLogs.MySQL.Database:Escape(logTable.module) .. "','" .. bLogs.MySQL.Database:Escape(bLogs.RemoveEscapables(logTable.log)) .. "','" .. bLogs.MySQL.Database:Escape(util.TableToJSON(involved)) .. "'," .. os.time() .. ",'" .. bLogs.MySQL.Database:Escape(Sensitive.IPAddress) .. ":" .. GetConVarString("hostport") .. "'," .. Sensitive.Session .. ")")
							end)
						end)
					end)

				end
			else
				bLogs.print("bLogs could not connect to MySQL because you don't have tMySQL4 installed.","error")
				bLogs.MySQL.Error = "tMySQL4 is not installed."
				return
			end
		end)()

	else

		bLogs.print("Not running bLogs MySQL because it is disabled.","error")

	end
end

mysql_init()
concommand.Add("blogs_mysql_init",mysql_init)
