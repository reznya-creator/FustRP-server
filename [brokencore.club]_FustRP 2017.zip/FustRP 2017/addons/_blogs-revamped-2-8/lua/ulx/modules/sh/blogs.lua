function ulx.bLogs(ply)
	bLogs.openMenu(ply)
end

local bLogsCMD = ulx.command("bLogs","ulx blogs",ulx.bLogs)
bLogsCMD:defaultAccess(ULib.ACCESS_ALL)
bLogsCMD:help("View bLogs")