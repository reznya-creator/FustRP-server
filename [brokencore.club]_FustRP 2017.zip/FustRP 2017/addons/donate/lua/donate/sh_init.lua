-- require(string name)
nw.Register('DonatTable'):Write(net.WriteTable):Read(net.ReadTable):SetPlayer()