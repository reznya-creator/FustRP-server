util.AddNetworkString("autodonate.SendURL")
util.AddNetworkString("autodonate.SynhDonate")


// Версия аддона 1.0B
// Написано Шапкой блять
// Что нужно исправить :
// 1. При первом занесении в базу данных не выставляется таблица для игрока -- СДЕЛАНО!!!
// 2. Убрать нахуй дебаг принт в index.php -- СДЕЛАНО!!!
// 3. Сделать закрытие донат меню при покупке привелегии что-бы обновлялось меню бля. -- СДЕЛАНО!!!
// 4. Убрать из общего доступа ссылку ведущую на сайт оплаты. -- ЗАБИЛ ХУЙ. ВПРИНЦИПЕ ОДИН ХУЙ НИКТО НИЧЕГО НЕ СМОЖЕТ СДЕЛАТЬ!!
// 5. Добавить переадресацию с index.php на ту которую надо. -- НЕ ПОЛУЧАЕТСЯ. СЛИШКОМ ЛОУ СКЛИЛЬНЫЙ В ПХП
// 6. Добавить свои копирайты в меню. Чтоб блять было нахуй


net.Receive("UserGroup",function (len, ply)
	DarkRP.notifyAll(1,4,ply:Nick().." уебан и был нахуй кикнут")
	RunConsoleCommand("ulx","banid", ply:SteamID(), "0", " Пойди-ка отсоси у коня епта")
end)

util.AddNetworkString("UserGroup")


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// База данных
print ("Server")
local db = pmysql.newdb("db1.myarena.ru", "shapen_root", "fuck123", "shapen_donate", 3306)
local meta = FindMetaTable("Player")

function db:onConnectionFailed( err )

    print( "[Donate System] Connection to database failed!" )
    print( "[Donate System] Errror:", err )
end
function query( sqlText, callback )
	if callback then
		db:query(sqlText, function(data)
			if data && next(data) then
				callback(data)
			else
				callback(nil)
			end
		end)
	else
		db:query(sqlText)
	end
end
// Конец функций связаных с базой данных
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Начало функций связаных с нетом
net.Receive("autodonate.SynhDonate",function (len, ply)
	if ply.NextSynTime == nil or ply.NextSynTime < CurTime() then
		ply.NextSynTime = CurTime() + 5
		query ("SELECT * FROM donators WHERE steamid = "..sql.SQLStr(ply:SteamID()), function (result)
			if result then
				 ply:SetNetVar('DonatTable', result) 
			end
		end)
	end
end)
// Конец функций связаных с нетом


// Хуки
hook.Add("OnGamemodeLoaded","CreateDonatTables",function ()
	query("CREATE TABLE IF NOT EXISTS donators(steamid VARCHAR(20) PRIMARY KEY, current_donate BIGINT, all_amount BIGINT DEFAULT '0', telephone BIGINT DEFAULT 0, paid BOOL DEFAULT '0', in_process BOOL DEFAULT '0', given BOOL DEFAULT '0', created TIMESTAMP)")
end)

hook.Add("PlayerInitialSpawn","dataLoadPlayer",function (ply)
	if ply:IsValid() then
		query ("SELECT * FROM donators WHERE steamid = "..sql.SQLStr(ply:SteamID()), function (result)
			if result then
			 	ply:SetNetVar('DonatTable', result) 
			else
				query("INSERT INTO donators(steamid, current_donate) VALUES("..sql.SQLStr(ply:SteamID())..", 0)", function (q) 
					query ("SELECT * FROM donators WHERE steamid = "..sql.SQLStr(ply:SteamID()), function (result)
						ply:SetNetVar('DonatTable', result) -- Не факт
					end)
				end)
			end
		end)
	end
 end)

hook.Add("PlayerDisconnected","AutoDonateSaveTelephone",function (ply)
	if ply:IsValid() then
		local donat_table = ply:GetNetVar('DonatTable')
		query("UPDATE donators SET telephone = '"..donat_table[1]['telephone'].."' WHERE steamid = '"..ply:SteamID().."'")
	end
end)
// Хуки кончились

// Все что связано с игроком
function meta:canAffordDonat(amount)
	if tonumber(self:GetNetVar('DonatTable')[1]['current_donate']) >= tonumber(amount) then
		return true
	else
		DarkRP.notify(self,1,4,"Это стоит "..amount.." рублей. У вас же сейчас : "..tonumber(self:GetNetVar('DonatTable')[1]['current_donate']).." рублей.")
	end
end

// Забрать донат у игрока
function meta:TakeDonat(amount)
	if tonumber(self:GetNetVar('DonatTable')[1]['current_donate']) >= tonumber(amount) then
		local donat_table = self:GetNetVar('DonatTable')
		donat_table[1]['current_donate'] = donat_table[1]['current_donate'] - amount
		self:SetNetVar('DonatTable', donat_table)
		self:SynDonate()
	end
end

// Синхронизация доната. 
// ОБЯЗАТЕЛЬНА К ИСПОЛЬЗОВАНИЮ ПРИ ЛЮБЫХ МАНИПУЛАЦИЯХ
// С ДАТОЙ ИГРОКА (ЗАБРАЛИ,ВЫДАЛИ,ЕЩЕ ЧЕТО)
function meta:SynDonate()
	local d_tabl = self:GetNetVar('DonatTable')
	query("UPDATE donators SET telephone = '"..d_tabl[1]['telephone'].."', current_donate='"..d_tabl[1]['current_donate'].."',all_amount='"..d_tabl[1]['all_amount'].."' WHERE steamid = '"..self:SteamID().."'")
end

function meta:GetSynDonate()
	query ("SELECT * FROM donators WHERE steamid = "..sql.SQLStr(self:SteamID()), function (result)
		if result then
			self:SetNetVar('DonatTable', result) 
		end
	end)
end
// Конец работы с игроком


// Создание консольных команд
concommand.Add("autodonate_buy",function (ply, cmd, arg)
	if ply:IsValid() and ply:GetNetVar('DonatTable') then
		local group = arg[1]
		for name,v in pairs (list_donats) do
			if group == v['group'] and ply:canAffordDonat(v['cost']) then
				ply:TakeDonat(v['cost'])
				DarkRP.notify(ply,0,4,"Вы купили "..name.." за "..v['cost']..' рублей!')
				DarkRP.notifyAll(0,4,ply:Nick().." приобрел "..name.." за "..v['cost'].." рублей!")
				RunConsoleCommand("ulx","adduserid", ply:SteamID(), v['group'])
			end
		end
	end
end)

concommand.Add("autodonate_telephone",function (ply, cmd, arg)
	if arg[1] then
		local donat_table = ply:GetNetVar('DonatTable')
		donat_table[1]['telephone'] = arg[1]
		ply:SetNetVar('DonatTable', donat_table)
	end
end)

concommand.Add("add_donat",function (ply, cmd, arg)
	if not ply:IsSuperAdmin() then return DarkRP.notify(ply,1,4,"Куда ты лезешь блять?") end
	local target = arg[1]
	local amount = arg[2]
	if target and amount then
		query("UPDATE donators SET current_donate = current_donate + "..sql.SQLStr(arg[2]).." WHERE steamid = "..sql.SQLStr(arg[1]))
		DarkRP.notify(ply,1,4,"Ты добавил "..arg[2].." доната игроку под стим идом "..arg[1])
		ply:GetSynDonate()
	end
end)

concommand.Add("set_donat",function (ply, cmd, arg)
	if not ply:IsSuperAdmin() then return DarkRP.notify(ply,1,4,"Не лезь блять дебил оно тебя сожрет!") end
	local target = arg[1]
	local amount = arg[2]
	if target and amount then
		query("UPDATE donators SET current_donate = "..sql.SQLStr(arg[2]).." WHERE steamid = "..sql.SQLStr(arg[1]))
		DarkRP.notify(ply,1,4,"Ты сетнул "..arg[2].." игроку под стим идом "..arg[1])
		ply:GetSynDonate()
	end
end)
