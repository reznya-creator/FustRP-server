// Menu
print ("CLIENT")

local list_actions = {
	["Указать номер телефона"] = {
		func = function () Derma_StringRequest("Номер","Номер","ФОРМАТ ДОЛЖЕН БЫТЬ БЕЗ ПЛЮСА! НАПРИМЕР : 79123456789!!!",function (c) LocalPlayer():ConCommand("autodonate_telephone "..c) end,function () end,"Ок","Отмена") end
	},
	["Пополнить баланс"] = {
		func =  function () Derma_StringRequest("Сколько","Сколько",50,function (c ) if not tonumber(c) then return end LocalPlayer():ConCommand("donate_add_balans "..tonumber(c)) end ,function () end,"OK","Отмена") end,
	}
}

concommand.Add("open_donat",function ()
	local ply = LocalPlayer()
	local tel = ply:GetNetVar('DonatTable')[1]['telephone']

	if tel == "0" then
		tel = "НЕ УКАЗАНО!"
	end

	local frame = vgui.Create("KADFrame")
	frame:SetSize(450,250)
	frame:Center()
	frame:MakePopup()

	frame.Button = vgui.Create("KADButton",frame)
	frame.Button:SetPos(6,35)
	frame.Button:SetSize(73,75)

	local avatar = vgui.Create("AvatarImage",frame)
	avatar:SetPos(10,40)
	avatar:SetSize(64,64)
	avatar:SetPlayer(LocalPlayer(),64)

	local copyrights = vgui.Create("KADButton",frame)
	copyrights:SetPos(0,0)
	copyrights:SetSize(250,25)
	copyrights:SetNewText("АвтоДонат by Шапка. Версия 1.0Beta.")
	copyrights.DoClick = function ()
		gui.OpenURL("http://steamcommunity.com/id/xamats45")
	end

	local refresh_donat = vgui.Create("KADButton",frame)
	refresh_donat:SetPos(239,0)
	refresh_donat:SetSize(180,25)
	refresh_donat:SetNewText("Обновить данные о балансе")
	refresh_donat.DoClick = function ()
		frame:Remove()
		net.Start("autodonate.SynhDonate")
		net.SendToServer()
	end

	
	print (ply:GetNetVar('DonatTable')[1]['current_donate'])

	local info_telephone = vgui.Create("KADButton",frame)
	info_telephone:SetPos(90,85)
	info_telephone:SetSize(350,20)
	info_telephone:SetNewText("Номер телефона: +"..tel.."")
	info_telephone:SetFont("Trebuchet24")

	local info_all_amount = vgui.Create("KADButton",frame)
	info_all_amount:SetPos(90,60)
	info_all_amount:SetSize(350,20)
	info_all_amount:SetNewText("Всего вы задонатили : "..ply:GetNetVar('DonatTable')[1]['all_amount'].." рублей")
	info_all_amount:SetFont("Trebuchet24")

	local info_current_donate = vgui.Create("KADButton",frame)
	info_current_donate:SetPos(90,35)
	info_current_donate:SetSize(350,20)
	info_current_donate:SetNewText("Ваш баланс : "..ply:GetNetVar('DonatTable')[1]['current_donate'].." рублей")
	info_current_donate:SetFont("Trebuchet24")


	local all_donat_frame = vgui.Create("KADFrame")
	all_donat_frame:SetSize(350,250)
	all_donat_frame:SetParent(frame)
	all_donat_frame:CreateCloseButton(false)
	all_donat_frame:SetPos(50,353)

	local desc = vgui.Create("KADFrame")
	desc:SetSize(350,250)
	desc:SetParent(frame)
	desc:SetPos(50,630)

	local scroll = vgui.Create( "DScrollPanel", desc)
	scroll:Dock(FILL)

	desc_donat = vgui.Create("DTextEntry",scroll)
	desc_donat:SetSize(500,500)
	desc_donat:SetEnterAllowed(true)
	desc_donat:SetEditable(false)
	desc_donat:SetMultiline(true)
	desc_donat:SetPos(0,0)
	desc_donat:SetText("Выберите услугу")

	local buy_button = vgui.Create("KADButton",desc)
	buy_button:Dock(BOTTOM)
	buy_button:SetNewText("Выберите услугу!")

	for name,actions in pairs (list_donats) do
		local all_donats = vgui.Create("KADButton",all_donat_frame)
		all_donats:Dock(TOP)
		all_donats:SetNewText(name)
		all_donats.DoClick = function ()
			desc_donat:SetText(actions['desc'])

			buy_button:SetNewText("Купить за "..actions['cost'].." рублей!")

			buy_button.DoClick = function ()
				ply:ConCommand("autodonate_buy "..actions['group'])
				frame:Remove()
			end
		end
	end
	for k,v in pairs (list_actions) do
		local buttons = vgui.Create("KADButton",frame)
		buttons:SetNewText(k)
		buttons:Dock(BOTTOM)
		buttons.DoClick = function ()
			v['func']()
			frame:Remove()
		end
	end

end)

concommand.Add("donate_add_balans",function (ply, cmd, arg)
	local number = ply:GetNetVar('DonatTable')[1]['telephone']
	if number == "0" or string.find(number,"+") then return ply:ChatPrint("[АвтоДонат] Укажите верный номер телефона!\n[АвтоДонат] ВНИМАНИЕ! ТЕЛЕФОН ДОЛЖЕН БЫТЬ БЕЗ ПЛЮСА (+)") end
	local chose_your_desteny = vgui.Create("KADFrame")
	chose_your_desteny:Center()
	chose_your_desteny:SetSize(250,250)

	local qiwi = vgui.Create("KADButton",chose_your_desteny)
	qiwi:Dock(TOP)
	qiwi:SetNewText("Оплатить через киви")
	qiwi.DoClick = function ()
		chose_your_desteny:Remove()
		local url = "http://scal.studio/qiwi_test/index.php?steamid="..LocalPlayer():SteamID().."&sum="..arg[1].."&phone="..ply:GetNetVar('DonatTable')[1]['telephone']
		local dframe = vgui.Create("DFrame")
		dframe:SetSize(900,900)
		dframe:Center()
		dframe:MakePopup()
		dframe:ShowCloseButton(true)

		dframe:SetTitle("Пополнить баланс")

		local w8 = vgui.Create("DButton", dframe)
		w8:Dock(FILL)
		w8:SetText("Подождите. Идет загрузка страницы!")

		timer.Simple(5,function ()
			w8:Remove()
		end)

		local html = vgui.Create("HTML",dframe)
		html:Dock(FILL)
		html:OpenURL(url)

		dframe.OnClose = function ()
			net.Start("autodonate.SynhDonate")
			net.SendToServer()
		end

	end

	local cerebro = vgui.Create("KADButton",chose_your_desteny)
	cerebro:Dock(TOP)
	cerebro:SetNewText("Оплатить другими способами")
	cerebro.DoClick = function ()
		chose_your_desteny:Remove()
		gui.OpenURL("http://millenium.myarena.ru/buy.html")
	end
end)