
-- Radio + Microphone Mod (DarkRP)
-- By Fish


/*
	Creates Player Data
*/

usermessage.Hook( "createRadPData", function( um )

	if ( LocalPlayer():GetPData( "rpRadioVolume" ) == nil ) then
	
		LocalPlayer():SetPData( "rpRadioVolume", 85 )
	end
	
	if ( LocalPlayer():GetPData( "rpRadioVolOver" ) == nil ) then
	
		LocalPlayer():SetPData( "rpRadioVolOver", 0 )
	end
	
	if ( LocalPlayer():GetPData( "radMenuColorScheme" ) == nil ) then
	
		LocalPlayer():SetPData( "radMenuColorScheme", rpRadio.Config.ListViewColorScheme )
	end
	
	timer.Simple( 1, function()
	
		hook.Call( 'radMenuSetScheme' )
	end )
end )



rpRadio.channels = {}


/*
	Receives broadcasters and listeners
*/

net.Receive( "radBroads", function( len )

	rpRadio.broads = table.Copy( net.ReadTable() )
end )

net.Receive( "radListeners", function( len )

	rpRadio.listeners = table.Copy( net.ReadTable() )
end )


/*
	DarkRP hear compatibility
*/

local function hearFunc( ply )

	if not LocalPlayer().DRPIsTalking then return nil end
	
	if ( not LocalPlayer():GetNWBool( "ulx_gagged" ) && rpRadio.onSameChannel( ply, LocalPlayer() ) ) then
		return true
	end
	
	if ( LocalPlayer():GetPos():Distance( ply:GetPos() ) > 550 ) then return false end
	
	return not GAMEMODE.Config.dynamicvoice or ply:isInRoom()
end

timer.Simple( 1, function()

	if ( string.lower( gmod.GetGamemode().Name ) == "darkrp" ) then -- DarkRP 2.5+ only!
	
		DarkRP.addChatReceiver( "speak", DarkRP.getPhrase( "speak" ), hearFunc )
	end
end )


/*
	Gets the current station
*/

local function getCurrentStation( ent )
	
	local nowStation = nil
	
	if ( IsValid( ent ) ) then
	
		if ( rpRadio.channels[ ent:EntIndex() ] ) then
		
			nowStation = rpRadio.channels[ ent:EntIndex() ].station
		end
	end
	
	return nowStation
end


/*
	Called when a video has cued
*/

local lastCue = 0

local function videoHasCued( ent, id )
	
	-- The last condition ensures a two second delay between seeking
	if ( ent.canHear && ent:GetVideoId() != "" && ( CurTime() - lastCue ) >= 2 ) then // valid video
	
		lastCue = math.floor( CurTime() )
		
		net.Start( "radSetSeekTime" )
			net.WriteEntity( ent )
			net.WriteString( id )
		net.SendToServer()
	end
end


/*
	Changes the volume
*/

local function switchVolume( ent, vol )
	
	local over = tonumber( LocalPlayer():GetPData( "rpRadioVolOver" ) )
	local volume = ent.GetVolume && ent:GetVolume() || 45
	
	if ( over >= 1 ) then
	
		if ( vol ) then
	
			volume = vol
		else
		
			return
		end
	end
	
	--
	
	local currStation = getCurrentStation( ent )
	local channel = ent.GetChannel && ent:GetChannel() || 1
	
	if ( IsValid( currStation ) ) then
	
		currStation:SetVolume( volume / 100 )
	else
	
		if ( ( channel == 2 || channel == 3 ) && rpRadio.Config.AllowYouTube ) then
		
			if ( IsValid( ent.html ) ) then
			
				for i = 0, 1 do
					ent.html:RunJavascript( "setVolume( " .. volume .. " );" )
				end
			end
		end
	end
end


/*
	Updates radio station volume and position
*/

local oldDist = -1
local minD = math.min( rpRadio.Config.MaxVolume3dRadius, rpRadio.Config.HearRadius )

local function updateRadioFadeVolume( ent, force )

	-- YouTube 3d fade
	
	if ( IsValid( ent ) && rpRadio.Config.Sound3d ) then
	
		local channel = ent.GetChannel && ent:GetChannel() || 1
		
		if ( ( channel == 2 || channel == 3 ) && rpRadio.Config.AllowYouTube ) then
		
			if ( IsValid( ent.html ) ) then
				
				local dist 	= math.max( minD, math.floor( ent:LocalToWorld( ent:OBBCenter() ):Distance( LocalPlayer():GetPos() ) ) )
				local frac = 0
				
				-- Don't update if we didn't move!
				if ( !force && oldDist == dist ) then return end
				
				local vol = tonumber( LocalPlayer():GetPData( "rpRadioVolume" ) )
				local over = tonumber( LocalPlayer():GetPData( "rpRadioVolOver" ) )
				
				if ( dist != rpRadio.Config.HearRadius ) then
				
					local max = ( ( over == 0 && ent:GetVolume() || vol ) / 100 )
					frac = max - math.Clamp( ( dist - minD ) / ( rpRadio.Config.HearRadius - minD ), 0, max )
				end
				
				ent.html:RunJavascript( "setVolume( " .. frac * 100 .. " );" )
				return
			end
		end
	end
end

local oldVol = -1
local oldOver = -1

local function updateRadio( ent )

	-- Grab the current station
	
	local channel = ent.GetChannel && ent:GetChannel() || 1
	local currStation = getCurrentStation( ent )
	
	-- Update position
	
	if ( IsValid( ent ) ) then
	
		if ( IsValid( currStation ) ) then
		
			currStation:SetPos( ent:LocalToWorld( ent:OBBCenter() ) )
		elseif ( !IsValid( ent.html ) ) then
		
			rpRadio.channels[ ent:EntIndex() ].fail = rpRadio.channels[ ent:EntIndex() ].fail + 1
		end
		
		
		if ( not rpRadio.Config.Sound3d ) then
		
			-- Update volume
			
			local vol = tonumber( LocalPlayer():GetPData( "rpRadioVolume" ) )
			local over = tonumber( LocalPlayer():GetPData( "rpRadioVolOver" ) )
			
			--
			
			if ( vol == nil || over == nil ) then return end
			
			--
			
			if ( over != oldOver ) then
				
				if ( over == 0 ) then
					switchVolume( ent )
				else
					switchVolume( ent, vol )
				end
				
				oldOver = over
				return
			end
			
			if ( over >= 1 && vol != oldVol ) then
			
				switchVolume( ent, vol )
				oldVol = vol
			end
		end
	end
end


/*
	Stops the YouTube audio
*/

usermessage.Hook( "stopYouTubeRad", function( um )

	local ent = um:ReadEntity()
	
	if ( IsValid( ent ) && IsValid( ent.html ) ) then
		
		if ( rpRadio.channels[ ent:EntIndex() ] ) then
			rpRadio.channels[ ent:EntIndex() ].url = "none"
		end
		
		ent.html:RunJavascript( "stopVideo();" )
	end
end )


/*
	Forces a change in a radio's volume
*/

usermessage.Hook( "radVolumeSwitch", function( um )

	local ent = um:ReadEntity()
	local level = um:ReadLong()
	
	if ( IsValid( ent ) ) then
		
		switchVolume( ent )
	end
end )


/*
	Gets a radio's URL
*/

local function getCurrentURL( ent, channel )

	if ( rpRadio.Config.AllowYouTube && ( channel == 2 || channel == 3 ) && ent:GetVideoId() != "" ) then
		return ( ent:GetVideoId() )
	elseif ( channel == 2 && ent:GetClass() != "rp_radio_microphone" ) then
		local c = ent:GetMicHost().GetChannel && ent:GetMicHost():GetChannel() || 1
		return ( channel != nil && rpRadio.stations[ c ] != nil && rpRadio.stations[ c ][ 2 ] != nil && rpRadio.stations[ c ][ 2 ] || "none" )
	else
		return ( channel != nil && rpRadio.stations[ channel ] != nil && rpRadio.stations[ channel ][ 2 ] != nil && rpRadio.stations[ channel ][ 2 ] || "none" )
	end
end


/*
	Radio seek callback
*/

net.Receive( "seekDone", function( len )

	local ent = net.ReadEntity()
	local id = net.ReadString()
	local time = tonumber( net.ReadString() )
	
	if ( IsValid( ent ) && IsValid( ent.html ) && id == ent:GetVideoId() ) then
		
		ent.html:RunJavascript( [[seekTo( ]] .. math.max( 0, time ) .. [[ );]] )
		
		timer.Simple( 0.5, function()
		
			if ( IsValid( ent.html ) && !rpRadio.Config.Sound3d ) then
				
				if ( tonumber( LocalPlayer():GetPData( "rpRadioVolOver" ) ) >= 1 ) then
					local vol = tonumber( LocalPlayer():GetPData( "rpRadioVolume" ) )
					ent.html:RunJavascript( "setVolume( " .. vol .. " );" )
				else
					ent.html:RunJavascript( "setVolume( " .. ent:GetVolume() .. " );" ) 
				end
				
				timer.Simple( 0.5, function()
					
					if ( IsValid( ent.html ) ) then
						
						if ( tonumber( LocalPlayer():GetPData( "rpRadioVolOver" ) ) >= 1 ) then
						
							local vol = tonumber( LocalPlayer():GetPData( "rpRadioVolume" ) )
							ent.html:RunJavascript( "setVolume( " .. vol .. " );" )
						else
							ent.html:RunJavascript( "setVolume( " .. ent:GetVolume() .. " );" ) 
						end
					end
				end )
			end
		end )
	end
end )

/*
	Controls the radio stations
*/

local function detectStations()

	for _, ent in ipairs( rpRadio.ENT_BOTH ) do
	
		if ( !rpRadio.channels[ ent:EntIndex() ] ) then
		
			rpRadio.channels[ ent:EntIndex() ] = {}
		end
		
		if ( !rpRadio.channels[ ent:EntIndex() ].station ) then
		
			rpRadio.channels[ ent:EntIndex() ].station = nil
		end
		
		if ( !rpRadio.channels[ ent:EntIndex() ].url ) then
		
			rpRadio.channels[ ent:EntIndex() ].url = "none"
		end
		
		if ( !rpRadio.channels[ ent:EntIndex() ].fail ) then
		
			rpRadio.channels[ ent:EntIndex() ].fail = 0
		end
		
		--
		
		if ( not timer.Exists( "radVolumeUpdate" .. ent:EntIndex() ) ) then
			
			local entindex = ent:EntIndex()
			
			timer.Create( "radVolumeUpdate" .. entindex, 0.2, 0, function()
			
				if ( !IsValid( ent ) ) then
				
					timer.Destroy( "radVolumeUpdate" .. entindex )
				else
					
					updateRadioFadeVolume( ent )
				end
			end )
		end
		
		--
		
		local channel = ent.GetChannel && ent:GetChannel() || 1
		local url = getCurrentURL( ent, channel )
		
		-- Stop radio sounds (outside radius)
		
		if ( LocalPlayer():GetPos():Distance( ent:GetPos() ) > rpRadio.Config.HearRadius ) then
		
			local chan = rpRadio.channels[ ent:EntIndex() ].station
			
			if ( IsValid( chan ) ) then
			
				chan:Stop()
				chan = nil
			end
			
			if ( IsValid( ent.html ) && ent.canHear ) then
			
				ent.canHear = false
				
				for i = 0, 1 do
				
					timer.Simple( i * 0.5, function()
						ent.html:RunJavascript( "stopVideo();" )
					end )
				end
			end
			
			if ( rpRadio.channels[ ent:EntIndex() ].url != "none" ) then
				rpRadio.channels[ ent:EntIndex() ].url = "none"
			end
			
			continue
		end
		
		
		local nowStation = getCurrentStation( ent )
		
		
		-- Channel changed!
		
		if ( rpRadio.channels[ ent:EntIndex() ].url != url || rpRadio.channels[ ent:EntIndex() ].fail > 15 ) then
		
			-- Stop
			if ( IsValid( nowStation ) ) then
				nowStation:Stop()
				nowStation = nil
			end
			
			if ( IsValid( ent.html ) ) then
				ent.html:RunJavascript( "stopVideo();" )
			end
			
			if ( rpRadio.Config.AllowYouTube && ( channel == 2 || channel == 3 ) && ent:GetVideoId() != "" ) then
				
				-- Prevent OSX from playing YouTube (OSX does not work with YT audio)
				if ( system.IsOSX() ) then continue end
				
				local id = ent:GetVideoId()
				
				if ( rpRadio.Config.YouTubeChatNotification ) then
					chat.AddText( color_white, "[YouTube] " .. ( rpRadio.getPhrase( "play_vid" ) or "?" ) .. ": " .. ent:GetVideoTitle() )
				end
				
				-- Set new URL
				rpRadio.channels[ ent:EntIndex() ].url = id
				
				-- Reset fail count
				rpRadio.channels[ ent:EntIndex() ].fail = 0
				
				--
				
				if ( !IsValid( ent.frame ) ) then
				
					ent.frame = vgui.Create( "DFrame" )
					ent.frame:SetSize( 1, 1 )
					ent.frame:SetTitle( "" )
					ent.frame:SetVisible( false )
				end
				
				----
				
				if ( !IsValid( ent.html ) ) then
				
					ent.html = vgui.Create( "DHTML", ent.frame )
					ent.html:SetPos( 0, 0 )
					ent.html:SetSize( 1, 1 )
					ent.html:SetVisible( false )
					ent.html:SetMouseInputEnabled( false )
					ent.html:OpenURL( 'https://wikipedia.org/wiki/Wikipedia:Contact_us' )
					function ent.html:ConsoleMessage() end
					
					-- Finished loading fix
					timer.Create( "radLoadJSHTML", 0.2, 0, function() 
					
						if ( !IsValid( ent.html ) ) then timer.Destroy( "radLoadJSHTML" ) return end
						
						--
						
						if ( !ent.html:IsLoading() ) then
							
							timer.Destroy( "radLoadJSHTML" )
							
							timer.Simple( 0.5, function()
							
								ent.html:RunJavascript( [[document.body.innerHTML = "<div id='player'></div>"; ]] )
								
								ent.html:AddFunction( "rad", "VideoCued", function()
									videoHasCued( ent, id )
								end )
								
								ent.html:AddFunction( "rad", "PlayerReady", function()
									ent.canHear = true
									ent.html:RunJavascript( [[cueVideo( ']] .. id .. [[', 0, 'small' );]] )
								end )
								
								ent.html:RunJavascript( [[var tag = document.createElement('script');
										
										tag.src = "https://www.youtube.com/iframe_api";
										var firstScriptTag = document.getElementsByTagName('script')[0];
										firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

										var player;
										function onYouTubePlayerAPIReady() {
											player = new YT.Player('player', {
												height: '1',
												width: '1',
												videoId: '',
												events: {
													'onReady': onPlayerReady,
													'onStateChange': onPlayerStateChange,
												  }
											} );
										}
										
										function onPlayerReady( event ) {
											rad.PlayerReady();
										}
										
										function onPlayerStateChange( event ) {
											if ( event.data == 5 ) {
												rad.VideoCued();
											}
										}
										
										function cueVideo( id, seek ) {
											player.cueVideoById( id, seek );
										}
										
										function seekTo( time ) {
											player.seekTo( time );
										}
										
										function setVolume( time ) {
											player.setVolume( time );
										}
										
										function stopVideo() {
											player.stopVideo();
										}
								]] )
							end )
						end
					end )
				else
					
					ent.canHear = false
					
					// Re-define the function
					ent.html:AddFunction( "rad", "VideoCued", function()
						videoHasCued( ent, id )
					end )
					
					timer.Simple( 2, function()
						
						if ( IsValid( ent ) && IsValid( ent.html ) ) then
							ent.canHear = true
							ent.html:RunJavascript( [[cueVideo( ']] .. id .. [[', 0, 'small' );]] )
						end
					end )
				end
				
				return
			end
			
			-- Set new URL
			rpRadio.channels[ ent:EntIndex() ].url = url
			
			-- Silence
			if ( channel < 2 ) then
				continue
			end
			
			-- Reset fail count
			rpRadio.channels[ ent:EntIndex() ].fail = 0
			
			-- Play the new station
			sound.PlayURL( url, rpRadio.Config.Sound3d && "3d" || "mono", function( station )
			
				local currentURL = getCurrentURL( ent, channel )
				
				if ( IsValid( station ) && IsValid( ent ) ) then
				
					station:SetPos( ent:LocalToWorld( ent:OBBCenter() ) )
					
					if ( rpRadio.channels[ ent:EntIndex() ].url == currentURL ) then
					
						station:Play()
					else
					
						station:Stop()
						station = nil
						
						return
					end
					
					-- Loud volume fix
					station:SetVolume( 0 )
					
					timer.Simple( 0.5, function()
					
						if ( IsValid( ent ) ) then
						
							local over = tonumber( LocalPlayer():GetPData( "rpRadioVolOver" ) )
							local oVol = tonumber( LocalPlayer():GetPData( "rpRadioVolume" ) )
							
							if ( over > 0 ) then
								switchVolume( ent, oVol )
							else
								switchVolume( ent )
							end
						end
					end )
					
					-- Add new station
					rpRadio.channels[ ent:EntIndex() ].station = station
				end
			end )
		end
		
		updateRadio( ent )
	end
end
timer.Create( "detectStations01", 1, 0, detectStations )

concommand.Add( "force_play", function( p, c, a )

	local ent = p:GetEyeTrace().Entity
	
	ent.html:RunJavascript( [[YT.VideoPlaying();]] )
end )

/*
	Recovers the radio timer
*/

timer.Create( "radioRecovery", 2, 0, function()

	if ( !timer.Exists( "detectStations01" ) ) then
	
		timer.Create( "detectStations01", 1, 0, detectStations )
	end
end )