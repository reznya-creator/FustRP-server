
/*
	-------------------------------------
	// Default language file (English) //
	-------------------------------------
	
	Don't see your language?
	
		Follow these instructions:
		
		1) Copy and paste this file in the same directory (rename it to anything)
		2) Change the text in the double quotes to your language
		3) At the bottom, change 'en' to your language code. e.g. de
		
		Type 'gmod_language' in the GMod console to discover your language code.
*/

local lang = {
	
	channel = "Канал",
	volume = "",
	
	offline = "Выкл",
	on_air = "В эфире",
	in_range = "В зоне слышемости",
	mic = "Микрофон",
	
	radio = "Радио",
	settings = "Настройки",
	live_chans = "Онлайн каналы",
	in_game_chan = "Игровые каналы",
	
	override_vol = "Дальность ",
	override_rad = "Переопр. Громкости Радио(Stream)",
	current_scheme = "Цвет",
	color_scheme = "Выбрать",
	
	blue = "Синий",
	red = "Красный",
	green = "Зелёный",
	grey = "Серый",
	orange = "оранжевый",
	pink = "розовый",
	purple = "фиолетовый",
	yellow = "желтый",
	
	next = "Далее",
	stop = "Стоп",
	loop = "Зациклить",
	not_playing = "-Не выбрано-",
	browse = "Выбрать",
	playlist = "Лист",
	title = "Заголовок",
	desc = "описание ",
	id = "ID",
	
	blacklist = "Черн список",
	play = "Запуск",
	nevermind = "Зыбыть..",
	copy_url = "Copy URL",
	add_to_blacklist = "Черн. список",
	add_to_queue = "Add to queue",
	remove = "Удалить",
	
	success_remove = "Успешно удалено список видео!",
	play_vid = "Играть",
}

rpRadio.addLanguage( "en", lang )