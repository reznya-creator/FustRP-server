------------------------------------------------------------
------------Copyright 2016, ScriptJunkie,-------------------
----------------All rights reserved.------------------------
------------------------------------------------------------

AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("sh_handcuffs_config.lua")
include("shared.lua")


function SWEP:SecretPrimaryAttack()
	--if not self:CanPrimaryAttack() then return end
	self.Owner:SetAnimation(ACT_VM_PRIMARYATTACK)
	self:SetNextPrimaryFire(CurTime() + 1)
	local tr = self.Owner:GetEyeTraceNoCursor()
	local properJob = false
	local canArrest = false
	if not handcuffs.Allow_Team_Detain then
		for k, v in pairs(handcuffs.Allow_Teams) do
			if  (tr.Entity:IsPlayer()) and (tr.Entity:Team() ~= v) and self:GetOwner():EyePos():Distance(tr.Entity:GetPos()) < handcuffs.Arrest_Distance then
				if !tr.Entity:IsCppipi() then
					canArrest = true
				end
			else
				canArrest = false
			end
		end
	else
		canArrest = true
	end

	if not handcuffs.Allow_All_Teams then
		for k, v in pairs(handcuffs.Allow_Teams) do
			if (self.Owner:Team() == v) then
				properJob = true
			end
		end
	else
		properJob = true
	end

	if properJob then

		if canArrest and tr.Entity.IsPlayer() and self:GetOwner():EyePos():Distance(tr.Entity:GetPos()) < 150 and tr.Entity:GetNWBool("isHandcuffed") == false then
			tr.Entity:SetNWBool("isHandcuffed", true)

			tr.Entity:ManipulateBoneAngles(tr.Entity:LookupBone("ValveBiped.Bip01_L_UpperArm"), Angle(20, 8.8, 0)) -- Left UpperArm
			tr.Entity:ManipulateBoneAngles(tr.Entity:LookupBone("ValveBiped.Bip01_L_Forearm"), Angle(15, 0, 0)) -- Left ForeArm
			tr.Entity:ManipulateBoneAngles(tr.Entity:LookupBone("ValveBiped.Bip01_L_Hand"), Angle(0, 0, 75)) -- Left Hand
			tr.Entity:ManipulateBoneAngles(tr.Entity:LookupBone("ValveBiped.Bip01_R_Forearm"), Angle(-15, 0, 0)) -- Right Forearm
			tr.Entity:ManipulateBoneAngles(tr.Entity:LookupBone("ValveBiped.Bip01_R_Hand"), Angle(0, 0, -75)) -- Right Hand
			tr.Entity:ManipulateBoneAngles(tr.Entity:LookupBone("ValveBiped.Bip01_R_UpperArm"), Angle(-20, 16.6, 0)) -- Right Upperarm
			tr.Entity:SetWalkSpeed(GAMEMODE.Config.walkspeed / 2.5)
			tr.Entity:SetRunSpeed(GAMEMODE.Config.runspeed / 2.5)

			if handcuffs.Teleport_Jail then
				tr.Entity:arrest()
			end

			tr.Entity.HandcuffedWeapons = {}
			tr.Entity.HandcuffedWeaponAmmo = {}
			tr.Entity.HandcuffedWeaponAmmoType = {}
			local weps = tr.Entity:GetWeapons()

			for i, v in ipairs(weps) do
				tr.Entity.HandcuffedWeapons[i] = v:GetClass()
				tr.Entity.HandcuffedWeaponAmmo[v:GetPrimaryAmmoType()] = tr.Entity:GetAmmoCount( v:GetPrimaryAmmoType() )
			end

			tr.Entity:StripWeapons()
		end
	else
		self:GetOwner():SendLua("GAMEMODE:AddNotify(\"Your job does not allow the use of handcuffs!\", NOTIFY_ERROR, 5)")
	end
end

function SWEP:SecretSecondaryAttack()
	local tr = self.Owner:GetEyeTraceNoCursor()

	if not handcuffs.Allow_All_Teams then
		for k, v in pairs(handcuffs.Allow_Teams) do
			if (self.Owner:Team() == v) then
				if tr.Entity:IsPlayer() and self:GetOwner():EyePos():Distance(tr.Entity:GetPos()) < handcuffs.Arrest_Distance and (tr.Entity:GetNWBool("isHandcuffed") == true) then
					tr.Entity:SetNWBool("isHandcuffed", false)
					self:GiveHandcuffWeaponsBack(tr.Entity)
					self:GiveHandcuffWeaponAmmoBack(tr.Entity)
					tr.Entity:SwitchToDefaultWeapon()
					tr.Entity:SetWalkSpeed(GAMEMODE.Config.walkspeed)
					tr.Entity:SetRunSpeed(GAMEMODE.Config.runspeed)
					tr.Entity:ManipulateBoneAngles(tr.Entity:LookupBone("ValveBiped.Bip01_L_UpperArm"), Angle(0, 0, 0)) -- Left UpperArm
					tr.Entity:ManipulateBoneAngles(tr.Entity:LookupBone("ValveBiped.Bip01_L_Forearm"), Angle(0, 0, 0)) -- Left ForeArm
					tr.Entity:ManipulateBoneAngles(tr.Entity:LookupBone("ValveBiped.Bip01_L_Hand"), Angle(0, 0, 0)) -- Left Hand
					tr.Entity:ManipulateBoneAngles(tr.Entity:LookupBone("ValveBiped.Bip01_R_Forearm"), Angle(0, 0, 0)) -- Right Forearm
					tr.Entity:ManipulateBoneAngles(tr.Entity:LookupBone("ValveBiped.Bip01_R_Hand"), Angle(0, 0, 0)) -- Right Hand
					tr.Entity:ManipulateBoneAngles(tr.Entity:LookupBone("ValveBiped.Bip01_R_UpperArm"), Angle(0, 0, 0)) -- Right Upperarm
				end
			end
		end
	else
		if tr.Entity:IsPlayer() and self:GetOwner():EyePos():Distance(tr.Entity:GetPos()) < handcuffs.Arrest_Distance and (tr.Entity:GetNWBool("isHandcuffed") == true) then
			self:GiveHandcuffWeaponsBack(tr.Entity)
			self:GiveHandcuffWeaponAmmoBack(tr.Entity)

			for k,v in pairs (tr.Entity:GetWeapons()) do
				if v:GetClass() == "keys" then
					tr.Entity:SetActiveWeapon("keys")
					break
				end
				tr.Entity:SwitchToDefaultWeapon()
			end

			tr.Entity:SetNWBool("isHandcuffed", false)
			tr.Entity:SetWalkSpeed(GAMEMODE.Config.walkspeed)
			tr.Entity:SetRunSpeed(GAMEMODE.Config.runspeed)
			tr.Entity:ManipulateBoneAngles(tr.Entity:LookupBone("ValveBiped.Bip01_L_UpperArm"), Angle(0, 0, 0)) -- Left UpperArm
			tr.Entity:ManipulateBoneAngles(tr.Entity:LookupBone("ValveBiped.Bip01_L_Forearm"), Angle(0, 0, 0)) -- Left ForeArm
			tr.Entity:ManipulateBoneAngles(tr.Entity:LookupBone("ValveBiped.Bip01_L_Hand"), Angle(0, 0, 0)) -- Left Hand
			tr.Entity:ManipulateBoneAngles(tr.Entity:LookupBone("ValveBiped.Bip01_R_Forearm"), Angle(0, 0, 0)) -- Right Forearm
			tr.Entity:ManipulateBoneAngles(tr.Entity:LookupBone("ValveBiped.Bip01_R_Hand"), Angle(0, 0, 0)) -- Right Hand
			tr.Entity:ManipulateBoneAngles(tr.Entity:LookupBone("ValveBiped.Bip01_R_UpperArm"), Angle(0, 0, 0)) -- Right Upperarm
		end
	end
end

function SWEP:GiveHandcuffWeaponsBack(ply)
	for i, v in ipairs(ply.HandcuffedWeapons) do
		ply:Give(v)
	end
end

function SWEP:GiveHandcuffWeaponAmmoBack(ply)
	for k, v in ipairs(ply.HandcuffedWeaponAmmo) do
			ply:SetAmmo(v, k)
	end
end