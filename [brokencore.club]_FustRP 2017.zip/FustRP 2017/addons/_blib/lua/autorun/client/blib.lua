concommand.Add("blib_license",function()

	print("This is the client console, not the server console. Run this from your server RCON/console!!")

end,nil,"Licensing for Billy's scripts")

concommand.Add("blib_activate",function()

	print("This is the client console, not the server console. Run this from your server RCON/console!!")

end,nil,"Activate a license for Billy's scripts")
