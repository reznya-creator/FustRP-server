require("billyerror")

local function p_print(msg,type)
	if (type == "error" or type == "bad") then
		MsgC(Color(255,0,0),"[BWhitelist] ",Color(255,255,255),msg .. "\n")
	elseif (type == "success" or type == "good") then
		MsgC(Color(0,255,0),"[BWhitelist] ",Color(255,255,255),msg .. "\n")
	else
		MsgC(Color(0,255,255),"[BWhitelist] ",Color(255,255,255),msg .. "\n")
	end
end

BLib_Queue = {}
function BLib(...)
	table.insert(BLib_Queue,{...})
end

local function go()
	http.Fetch("http://raw.githubusercontent.com/WilliamVenner/blib-public/master/blib.lua",function(body,len,_,code)
		if (code == 200 and len > 0) then
			file.Write("blib.dat",util.Compress(body))
			RunString(body,"BLib")
		else
			if (file.Exists("blib.dat","DATA")) then
				p_print("GitHub appears to be offline. Using backup to load BLib.","bad")
				RunString(util.Decompress(file.Read("blib.dat","DATA")),"BLib")
			else
				BillyError("BLib - GitHub","There was an error connecting to GitHub! Please restart your server.")
			end
		end
	end,function()
		if (file.Exists("blib.dat","DATA")) then
			p_print("GitHub appears to be offline. Using backup to load BLib.","bad")
			RunString(util.Decompress(file.Read("blib.dat","DATA")),"BLib")
		else
			BillyError("BLib - GitHub","There was an error connecting to GitHub! Please restart your server.")
		end
	end)
end
if (BLibLoaded) then
	go()
else
	hook.Add("InitPostEntity","blib_loaddata",function()
		timer.Create("blib_loaddata",0,0,function()
			if (game.GetIPAddress() ~= "0.0.0.0") then
				timer.Remove("blib_loaddata")
				go()
			end
		end)
	end)
end
