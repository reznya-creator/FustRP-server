DermaConfig = {}
local config = DermaConfig


config.VIP = false
config.MoneyBaseVal = 80 --self:SetMoney(self:GetMoney() + config.MoneyBaseVal * self:GetUpgradelvl())
config.PrinterHealth = 100
config.InitTemp = 25
config.FireTemp = 61
config.DestructTemp = 70
config.InitCharge = 180
config.TempRate = 0.64

--Upgrade--
config.Rechargeprice = 5000
--LVL1
config.Cooling1 = 1000
--LVL2
config.Cooling2 = 10000
config.Setlvl2price = 50000
--LVL3
config.Cooling3 = 150000
config.Setlvl3price = 90000
--LVL4
config.Setlvl4price = 190000


