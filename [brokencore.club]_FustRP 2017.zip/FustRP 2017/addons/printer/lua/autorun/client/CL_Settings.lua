DermaConfig = {}
local config = DermaConfig

config.primary = Color(149,165,166)
config.primary_dark = Color(44,62,80)
config.primary_light = Color(207,216,220)
config.accent = Color(39,174,96)
config.primary_text = Color(33,33,33)
config.divider = Color(182,182,182)


--Temprature Gauge--
config.WhiteGauge = 50  -- while less than this
config.YellowGauge = 50 -- When greater than this
config.RedGauge = 55 -- When greater than thiS