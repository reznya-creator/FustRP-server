include("Shared.lua")
include("autorun/client/CL_Settings.lua")
local config = DermaConfig

surface.CreateFont("MainText", {font = "Tahoma", size = 30, weight = 1000, shadow = false, antialias = true})
surface.CreateFont("SmallText", {font = "Tahoma", size = 17, weight = 1000, shadow = false, antialias = true})
function ENT:Initialize()


--sound--
	self.sound = CreateSound(self, Sound("ambient/levels/labs/equipment_printer_loop1.wav"))
    self.sound:SetSoundLevel(52)
	self.sound:PlayEx(1, 100)
	

	
--Initail temperature display color--	
	self.TempColor = Color(255,255,255)
	
--initailizing spin vars--
	self.spin = 0
	self.spin2 = 0
	
end
--animation and sound zone--
function ENT:Think()
	
	--owner check--
    local owner = self:Getowning_ent()
    self.owner = (IsValid(owner) and owner:Nick()) or DarkRP.getPhrase("unknown")
	
	if self:Gettoggle() == true then
		if self:GetCharge() > 0 then
			self.sound:PlayEx(1, 100)
		end
	else
		if self.sound then
			self.sound:Stop()
		end
	end
--Refreshing parent and location for models preventing issues i encountered with models not staying in place--
	self.Angle = self:GetAngles()
	self.Pos = self:GetPos()
	
		--size matrix--
	local mat = Matrix()
	mat:Scale(Vector(0.1,0.1,0.1))
	
	local matC = Matrix()
	matC:Scale(Vector(0.18,0.18,0.18))
	
	if IsValid(self.S_Model) then
		self.S_Model:SetParent( self )
		self.S_Model:SetPos(self.Pos + self.Angle:Forward()*-0.5 + self.Angle:Right()*8 + self.Angle:Up() *7.6 )
		self.S_Model:SetAngles( self.Angle )
	else
		self.S_Model = ClientsideModel("models/phoenixprinters/DermaPrinterScreen.mdl", RENDER_GROUP_VIEW_MODEL_OPAQUE)
		self.S_Model:SetPos(self.Pos + self.Angle:Forward()*-0.5 + self.Angle:Right()*8 + self.Angle:Up() *7.6 )
		self.S_Model:SetAngles( self.Angle )
		self.S_Model:SetParent( self )
		
	end
	
	if IsValid(self.Sh1_Model) then
		self.Sh1_Model:SetParent( self )
		self.Sh1_Model:SetPos(self.Pos + self.Angle:Forward()*-9 + self.Angle:Right()*13 + self.Angle:Up() *0.5 )
		self.Sh1_Model:SetAngles( self.Angle )
	else
		self.Sh1_Model = ClientsideModel("models/phoenixprinters/dermaprintershroud.mdl", RENDER_GROUP_VIEW_MODEL_OPAQUE)
		self.Sh1_Model:SetPos(self.Pos + self.Angle:Forward()*-9 + self.Angle:Right()*13 + self.Angle:Up() *0.5 )
		self.Sh1_Model:SetAngles( self.Angle )
		self.Sh1_Model:EnableMatrix( "RenderMultiply", matC )
		self.Sh1_Model:SetParent( self )
		self.Sh1_Model:SetMaterial("hunter/myplastic")

		
	end
	
	if IsValid(self.Sh2_Model) then
		self.Sh2_Model:SetParent( self )
		self.Sh2_Model:SetPos(self.Pos + self.Angle:Forward()*9 + self.Angle:Right()*13 + self.Angle:Up() *0.5 )
		self.Sh2_Model:SetAngles( self.Angle )
	else
		self.Sh2_Model = ClientsideModel("models/phoenixprinters/dermaprintershroud.mdl", RENDER_GROUP_VIEW_MODEL_OPAQUE)
		self.Sh2_Model:SetPos(self.Pos + self.Angle:Forward()*9 + self.Angle:Right()*13 + self.Angle:Up() *0.5 )
		self.Sh2_Model:SetAngles( self.Angle )
		self.Sh2_Model:EnableMatrix( "RenderMultiply", matC )
		self.Sh2_Model:SetParent( self )
		self.Sh2_Model:SetMaterial("hunter/myplastic")
		
	end
	
	if !IsValid(self.C_Model) then 
		self.C_Model = ClientsideModel("models/XQM/cylinderx2large.mdl", RENDER_GROUP_VIEW_MODEL_OPAQUE)
		self.C_Model:SetPos(self.Pos + self.Angle:Forward()*11.5 + self.Angle:Right()*-5 + self.Angle:Up() *-4 )
		self.C_Model:SetAngles( self.Angle )
		self.C_Model:EnableMatrix( "RenderMultiply", mat )
		self.C_Model:SetParent( self )
		self.C_Model:SetMaterial("phoenix_storms/officewindow_1-1.vmt")
		
	end
	
	if !IsValid(self.C2_Model) then 
		self.C2_Model = ClientsideModel("models/XQM/cylinderx2large.mdl", RENDER_GROUP_VIEW_MODEL_OPAQUE)
		self.C2_Model:SetPos(self.Pos + self.Angle:Forward()*11.5 + self.Angle:Right()*-5 + self.Angle:Up() *2 )
		self.C2_Model:SetAngles( self.Angle )
		self.C2_Model:EnableMatrix( "RenderMultiply", mat )
		self.C2_Model:SetParent( self )
		self.C2_Model:SetMaterial("phoenix_storms/officewindow_1-1.vmt")
		 
	end
	
	if !IsValid(self.B1_Model) then 
		self.B1_Model = ClientsideModel("models/phoenixprinters/dermaprinterblade.mdl", RENDER_GROUP_VIEW_MODEL_OPAQUE)
		self.B1_Model:SetPos(self.Pos + self.Angle:Forward()*9 + self.Angle:Right()*13 + self.Angle:Up() *0.5 )
		self.B1_Model:SetAngles( self.Angle )
		self.B1_Model:EnableMatrix( "RenderMultiply", matC )
		self.B1_Model:SetParent( self )
		self.B1_Model:SetMaterial("hunter/myplastic")
		
	end
	
	if !IsValid(self.B2_Model) then 
		self.B2_Model = ClientsideModel("models/phoenixprinters/dermaprinterblade.mdl", RENDER_GROUP_VIEW_MODEL_OPAQUE)
		self.B2_Model:SetPos(self.Pos + self.Angle:Forward()*-9 + self.Angle:Right()*13 + self.Angle:Up() *0.5 )
		self.B2_Model:SetAngles( self.Angle )
		self.B2_Model:EnableMatrix( "RenderMultiply", matC )
		self.B2_Model:SetParent( self )
		self.B2_Model:SetMaterial("hunter/myplastic")
		
	end

	--spin on off check and render distance--
	if(LocalPlayer():GetPos():Distance(self:GetPos()) < 500) then
		if self:Gettoggle() == true then
			self.spin = self.spin+1
			self.spin2 = self.spin2+10
		end
		self.S_Model:SetModel("models/phoenixprinters/DermaPrinterScreen.mdl")
		self.C_Model:SetModel("models/XQM/cylinderx2large.mdl")
		self.C2_Model:SetModel("models/XQM/cylinderx2large.mdl")
		self.Sh1_Model:SetModel("models/phoenixprinters/dermaprintershroud.mdl")
		self.Sh2_Model:SetModel("models/phoenixprinters/dermaprintershroud.mdl")
		self.B1_Model:SetModel("models/phoenixprinters/dermaprinterblade.mdl")
		self.B2_Model:SetModel("models/phoenixprinters/dermaprinterblade.mdl")
	else
		self.S_Model:SetModel("models/hunter/blocks/cube025x025x025.mdl")
		self.C_Model:SetModel("models/hunter/blocks/cube025x025x025.mdl")
		self.C2_Model:SetModel("models/hunter/blocks/cube025x025x025.mdl")
		self.Sh1_Model:SetModel("models/hunter/blocks/cube025x025x025.mdl")
		self.Sh2_Model:SetModel("models/hunter/blocks/cube025x025x025.mdl")
		self.B1_Model:SetModel("models/hunter/blocks/cube025x025x025.mdl")
		self.B2_Model:SetModel("models/hunter/blocks/cube025x025x025.mdl")
	end
	
	--creating seperate angles for the Rollers(C-C2) to spin--
	local AngleC = self:GetAngles()
	AngleC:RotateAroundAxis(AngleC:Forward(), self.spin*-1)
	AngleC:RotateAroundAxis(AngleC:Right(), 0)
	AngleC:RotateAroundAxis(AngleC:Up(), 0)
	self.C_Model:SetParent( self )
	self.C_Model:SetPos(self.Pos + self.Angle:Forward()*11.5 + self.Angle:Right()*-5 + self.Angle:Up() *-4 )
	self.C_Model:SetAngles( AngleC )
	
	local AngleC2 = self:GetAngles()
	AngleC2:RotateAroundAxis(AngleC2:Forward(), self.spin)
	AngleC2:RotateAroundAxis(AngleC2:Right(), 0)
	AngleC2:RotateAroundAxis(AngleC2:Up(), 0)
	self.C2_Model:SetParent( self )
	self.C2_Model:SetPos(self.Pos + self.Angle:Forward()*11.5 + self.Angle:Right()*-5 + self.Angle:Up() *2 )
	self.C2_Model:SetAngles( AngleC2 )
	
	--creating seperate angle for the fan(B1-B2) to spin--
	local AngleB = self:GetAngles()
	AngleB:RotateAroundAxis(AngleB:Forward(), 0)
	AngleB:RotateAroundAxis(AngleB:Right(), self.spin2)
	AngleB:RotateAroundAxis(AngleB:Up(), 0)
	self.B1_Model:SetParent( self )
	self.B1_Model:SetPos(self.Pos + self.Angle:Forward()*9 + self.Angle:Right()*13 + self.Angle:Up() *0.5 )
	self.B1_Model:SetAngles( AngleB )
	self.B2_Model:SetParent( self )
	self.B2_Model:SetPos(self.Pos + self.Angle:Forward()*-9 + self.Angle:Right()*13 + self.Angle:Up() *0.5 )
	self.B2_Model:SetAngles( AngleB )
end

function ENT:OnRemove()

	--stopping sound on remove and deleting external models--
	if self.sound then
		self.sound:Stop()
	end
	self.C_Model:Remove()
	self.C2_Model:Remove()
	self.S_Model:Remove()
	self.Sh1_Model:Remove()
	self.Sh2_Model:Remove()
	self.B1_Model:Remove()
	self.B2_Model:Remove()
end

function ENT:Draw()

	--color vars tanslated into local vars--
	local MR = self:GetMainColorR()
	local MG = self:GetMainColorG()
	local MB = self:GetMainColorB()
	
	local BR = self:GetBgColorR()
	local BG = self:GetBgColorG()
	local BB = self:GetBgColorB()
	
	--temperature color change--
	if self:GetPTemp() > config.YellowGauge then 
		self.TempColor = Color(237,221,93)
	end
	
	if self:GetPTemp() > config.RedGauge then 
		self.TempColor = Color(235,0,0)
	end
	
	if self:GetPTemp() < config.WhiteGauge then 
		self.TempColor = Color(255,255,255)
	end
	--charge value--
	local Charge = self:GetCharge()
	
	
	
	self.Angle = self:GetAngles()
	self.Pos = self:GetPos()
	
	--Cam3D2D Panal top and display--
	self.Angle:RotateAroundAxis(self.Angle:Up(), 180)
	if(EyePos():Distance(self.S_Model:GetPos())<2000)then self.Entity:DrawModel()
	cam.Start3D2D(self.Pos + self.Angle:Up() *8.25 , self.Angle , 0.108)
	
	draw.RoundedBox(0,-125,-90,250,170,Color(BR,BG,BB)) 
	draw.RoundedBox(0,-97,17,200,50,Color(MR,MG,MB))
	draw.RoundedBox(5,-87,22,180,40,Color(255,255,255))
	draw.DrawText( self.owner:sub(1,13), "HUDNumber5", 3, 25, Color(0,0,0),1)
	draw.RoundedBox(0,-97,-30,97,40,Color(MR,MG,MB))
	draw.RoundedBox(0,6,-30,97,40,Color(MR,MG,MB))
	draw.RoundedBox(0,-97,-77,200,40,Color(MR,MG,MB))
	draw.RoundedBox(0,-87,-72,Charge,30,Color(0,221,0))
	draw.TexturedQuad{texture = surface.GetTextureID "gui/gradient_up",color = Color(0, 115, 0, 255),x = -87,y = -72,w = Charge,h = 30}
	surface.SetDrawColor( 255, 255, 255, 255 ) 
	surface.SetMaterial( Material( "PhoenixPrinters/money.png", "noclamp smooth" ) )
	surface.DrawTexturedRect( -95, -30, 40, 40 ) 
	surface.SetDrawColor( 255, 255, 255, 255 ) 
	surface.SetMaterial( Material( "PhoenixPrinters/snow.png", "noclamp smooth" ) )
	surface.DrawTexturedRect( 10, -30, 40, 40 ) 
	draw.RoundedBox(5,-53,-28,50,35,Color(150,150,150))
	draw.RoundedBox(5,50,-28,50,35,Color(150,150,150))
	draw.DrawText( math.floor(self:GetPTemp()).."°C", "Trebuchet24", 75, -23, self.TempColor,1)
	draw.DrawText("lvl"..self:GetUpgradelvl(), "Trebuchet24", -28, -23, Color(255,255,255),1)
	cam.End3D2D() 
	
	--display money value--
	local money = self:GetMoney()
	
	--Cam3D2D Panal Front--
	self.Angle:RotateAroundAxis(self.Angle:Forward(), 90)
	cam.Start3D2D(self.Pos + self.Angle:Up() *18.50 , self.Angle , 0.1)
	draw.DrawText( "$"..money, "Trebuchet24", 77, -48, Color(255,255,255),1)
	cam.End3D2D() 
	end  
end

--Net activation derma panel--
net.Receive("ActiveP",function()

	--Getting Printer entity--
	printer = net.ReadEntity()
	if IsValid(Frame) then 
		Frame:Remove()
	end
	--draw window--
	Frame = vgui.Create("DFrame")
	Frame:SetPos( ScrW()/2-300, ScrH()/2-200 )
	Frame:SetSize( 600, 400 )
	Frame:SetTitle( "Printer Options" )
	Frame:SetVisible( true )
	Frame:ShowCloseButton( false )
	Frame:MakePopup()
	Frame.Paint = function(self, w, h)
	
	--draw boxes, textures etc..--
	draw.RoundedBox(0,0,0,w,h, config.primary_dark)                                      --BackGround ~DJ
	draw.RoundedBox(0,0,0,w,25,config.divider)                                      --Header Colour ~DJ
	draw.RoundedBox(5,15,340,50,50,config.primary)                             --Avatar BackPlate ~DJ    
	draw.RoundedBox(5,60,280,180,50,config.primary)                            --Charge Bar BackPlate ~DJ    
	draw.RoundedBox(5,55,285,printer:GetCharge(),40,config.accent)                  --Printer Charge Bar ~DJ
	draw.DrawText( "Owner:", "MainText", 70, 340, config.primary_text,0)       --Owner Text ~DJ
	draw.DrawText( printer.owner, "MainText", 70, 360, config.primary_text,0)  --Player Name Text ~DJ
	draw.RoundedBox(5,255,40,320,220,config.primary) -- Color mixer background ~DJ
	draw.RoundedBox(5,475,340,100,220,printer.TempColor)  --Temp Border ~ DJ
	draw.RoundedBox(5,480,345,90,210,config.primary)  --Temp BackPlate ~DJ
	draw.DrawText( math.floor(printer:GetPTemp()).."°C", "MainText", 525, 355, config.primary_text,1) --Temp Text ~DJ
	
	--forces user out if printer gets stolen and someone else uses it and if it explodes--
	if printer:GetDestroyed() == true then 
		Frame:Close()
	end
	
	--closes menu on new activator
	if printer:GetActivator() == LocalPlayer() then
		
	else
	Frame:Close()
	end
	
	end
	
	--exit button--
	local ButtonX = vgui.Create("DButton", Frame)
	ButtonX:SetText("X")
	ButtonX:SetPos( 550, 0 )				
	ButtonX:SetSize( 40, 20 )				
	ButtonX.DoClick = function()
		Frame:Close()
	end	
	ButtonX.Paint = function(self, w, h)
		draw.RoundedBox(0,0,0,w,h,config.accent)
	end
	
	--avatar image--
	local Avatar = vgui.Create( "AvatarImage", Frame )
	Avatar:SetSize( 40, 40 )
	Avatar:SetPos( 20, 345 )
	Avatar:SetPlayer( printer:Getowning_ent(), 64 )
	
	--a gradient :P--
	local grad = vgui.Create("DButton", Frame)
	grad:SetText("")
	grad:SetPos( 20, 345 )				
	grad:SetSize( 40, 40 )				
	grad.Paint = function(self, w, h)
		draw.TexturedQuad{texture = surface.GetTextureID "gui/gradient_up",color = Color(155, 155, 155, 100),x = 0,y = 0,w = w,h = h}
	end
	
	--Recharge button--
	local Rechargeb = vgui.Create("DButton", Frame)
	Rechargeb:SetText("")
	Rechargeb:SetPos( 15, 40 )				
	Rechargeb:SetSize( 200, 50 )				
	Rechargeb.DoClick = function()	
	
		--netsend--
		net.Start("RechargeP")
		net.WriteEntity(printer)
		net.SendToServer()
		
	end	
	Rechargeb.Paint = function(self, w, h)
	
		--paint--
		draw.RoundedBox(5,0,0,w,h,config.primary)
		
		--hover--
		if Rechargeb:IsHovered() == true then
			draw.DrawText( "$"..printer:GetRechargeprice(), "MainText", 100, 11, config.primary_text,1)
		else
			draw.DrawText( "Перезарядка", "MainText", 100, 11, config.primary_text,1)
		end
		
	end
	
	--cooling upgrade button--
	local Coolingb = vgui.Create("DButton", Frame)
	Coolingb:SetText("")
	Coolingb:SetPos( 15, 100 )				
	Coolingb:SetSize( 200, 50 )				
	Coolingb.DoClick = function()	
	
		--netsend--
		net.Start("CoolingP")
		net.WriteEntity(printer)
		net.SendToServer()
		
	end	
	Coolingb.Paint = function(self, w, h)
	
		--cooling display price ajustment--
		if printer:GetCoolinglvl() == 4 then
			Coolingprice = "N/A"
		end
		if printer:GetCoolinglvl() == 3 then
			Coolingprice  = "$"..printer:GetCooling3price()
		end
		if printer:GetCoolinglvl() == 2 then
			Coolingprice  = "$"..printer:GetCooling2price()
		end
		if printer:GetCoolinglvl() == 1 then
			Coolingprice = "$"..printer:GetCooling1price()
		end
		
		--paint--
		draw.RoundedBox(5,0,0,w,h,config.primary)
		
		--hover
		if Coolingb:IsHovered() == true then
		
			draw.DrawText( Coolingprice, "MainText", 100, 11, config.primary_text,1)
			
		else
		
			draw.DrawText( "Урвень Охлаждение", "MainText", 100, 11, config.primary_text,1)
			
		end
	end
	
	--amount upgrade button--
	local Amountb = vgui.Create("DButton", Frame)
	Amountb:SetText("")
	Amountb:SetPos( 15, 160 )				
	Amountb:SetSize( 200, 50 )	
	Amountb.DoClick = function()
	
		--netsend--
		net.Start("UpgradeP")
		net.WriteEntity(printer)
		net.SendToServer()
		
	end	
	Amountb.Paint = function(self, w, h)
	
	--amount upgrade display price ajustment--
		if printer:GetUpgradelvl() == 4 then
			lvlprice = "N/A"
		end
		if printer:GetUpgradelvl() == 3 then
			lvlprice = "$"..printer:Getlvl4price()
		end
		if printer:GetUpgradelvl() == 2 then
			lvlprice = "$"..printer:Getlvl3price()
		end
		if printer:GetUpgradelvl() == 1 then
			lvlprice = "$"..printer:Getlvl2price()
		end
		
		--paint--
		draw.RoundedBox(5,0,0,w,h,config.primary)
		
		--hover--
		if Amountb:IsHovered() == true then
			draw.DrawText( lvlprice, "MainText", 100, 11, config.primary_text,1)
		else
			draw.DrawText( "Улучшение", "MainText", 100, 11, config.primary_text,1)
		end
		
	end
	
	--withdraw button--
	local withdrawb = vgui.Create("DButton", Frame)
	withdrawb:SetText("")
	withdrawb:SetPos( 15, 220 )				
	withdrawb:SetSize( 200, 50 )				
	withdrawb.DoClick = function()
	
		--netsend--
		net.Start("withdrawp")
		net.WriteEntity(printer)
		net.SendToServer()
		
	end	
	withdrawb.Paint = function(self, w, h)
	
	--paint--
	draw.RoundedBox(5,0,0,w,h,config.primary)

    --hover--
		if withdrawb:IsHovered() == true then
			draw.DrawText( "$"..printer:GetMoney(), "MainText", 100, 11, config.primary_text,1)
		else
			draw.DrawText( "Снять деньги", "MainText", 100, 11, config.primary_text,1)
		end
	end
	
	--on/off button--
	local ToggleOnOff = vgui.Create("DButton", Frame)
	ToggleOnOff:SetText("")
	ToggleOnOff:SetPos( 15, 280 )				
	ToggleOnOff:SetSize( 50, 50 )				
	ToggleOnOff.DoClick = function()	
		
		--netsend--
		net.Start("Togglep")
		net.WriteEntity(printer)
		net.SendToServer()
	end
	
	ToggleOnOff.Paint = function(self, w, h)
	
		--paint--
		draw.RoundedBox(5,0,0,w,h,config.primary)
		
		--on/off button texture--
		if printer:Gettoggle() == true then
			surface.SetDrawColor( 255, 255, 255, 255 ) 
			surface.SetMaterial( Material( "PhoenixPrinters/PrinterOn.png", "noclamp smooth" ) )
			surface.DrawTexturedRect( 10, 10, 30, 30 ) 
		else
			surface.SetDrawColor( 200, 200, 200, 255 ) 
			surface.SetMaterial( Material( "PhoenixPrinters/PrinterOff.png", "noclamp smooth" ) )
			surface.DrawTexturedRect( 10, 10, 30, 30 ) 
		end
		
	end

	--color mixer--
	local Mixer = vgui.Create( "DColorMixer", Frame )
	Mixer:SetPos(265,50)
	Mixer:SetSize(300,200)
	Mixer:SetPalette( true ) 		
	Mixer:SetAlphaBar( false ) 	
	Mixer:SetWangs( true )			
	Mixer:SetColor( Color( 255, 255, 255 ) )	
	
	--printer color change button--
	local ColorA = vgui.Create("DButton", Frame)
	ColorA:SetText("")
	ColorA:SetPos( 255, 280 )				
	ColorA:SetSize( 100, 50 )				
	ColorA.DoClick = function()	
	
		--netsend--
		net.Start("ColorP")
		net.WriteEntity(printer)
		local color = Mixer:GetColor()
		net.WriteColor(Color(color.r,color.g,color.b))
		net.SendToServer()
		
	end
	ColorA.Paint = function(self, w, h)
	
		--paint--
		draw.RoundedBox(5,0,0,w,h,config.primary)
		draw.DrawText( " Set\nPrinter Color", "SmallText", 50, 9, config.primary_text, 1)
		
	end
	
	--Main color button--
	local ColorB = vgui.Create("DButton", Frame)
	ColorB:SetText("")
	ColorB:SetPos( 365, 280 )				
	ColorB:SetSize( 100, 50 )				
	ColorB.DoClick = function()	
	
		--sets printer main color--
		local color = Mixer:GetColor()
		printer:SetMainColorR(color.r)
		printer:SetMainColorG(color.g)
		printer:SetMainColorB(color.b)
		
	end
	ColorB.Paint = function(self, w, h)
	
		--paint--
		draw.RoundedBox(5,0,0,w,h,config.primary)
		draw.DrawText( " Set\nMain Color", "SmallText", 50, 9, config.primary_text, 1)
		
	end
	
	--color background button--
	local ColorC = vgui.Create("DButton", Frame)
	ColorC:SetText("")
	ColorC:SetPos( 475, 280 )				
	ColorC:SetSize( 100, 50 )				
	ColorC.DoClick = function()	
	local color = Mixer:GetColor()
	
		--sets color background--
		printer:SetBgColorR(color.r)
		printer:SetBgColorG(color.g)
		printer:SetBgColorB(color.b)
		
	end
	ColorC.Paint = function(self, w, h)
	
		--paint--
		draw.RoundedBox(5,0,0,w,h,config.primary)
		draw.DrawText( " Set\nBG Color", "SmallText", 50, 9, config.primary_text, 1)
		
	end


 
end)